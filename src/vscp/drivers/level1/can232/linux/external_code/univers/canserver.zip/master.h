#ifndef __MASTER_H
#define __MASTER_H
#include <pthread.h>
#include "candev.h"

#define z_max(a,b) (a)>(b)?(a):(b)
#define z_min(a,b) (a)<(b)?(a):(b)


int z_hextoi(char c);
int z_itohex(int i);
long z_lHexToLong(char *p);
char *pIntToHex( char *p, unsigned int n, int nNibbles);
char *pIntToDec( char *p, unsigned int n, unsigned int nMaxDec=1000000000);

#define SOCKET_FOR_CANSRVTSK_1 9009
#define SOCKET_FOR_CANSRVTSK_2 9002
#define SOCKET_FOR_CANSRVTSK_3 9003
#define SOCKET_FOR_CANSRVTSK_4 9004


#define SERIALPORT_CAN232_1 6        // /dev/ttyS6
#define SERIALPORT_CAN232_2 5          // /dev/ttyS5 
#define SERIALPORT_CAN232_3 3         // /dev/ttyS3
#define SERIALPORT_CAN232_4 1         ///dev/ttyS1


#include <semaphore.h>

#define TASK_FREE_RUNNING_MODE 1
#define TASK_YIELD_MODE       2
#define TASK_SUSPEND_MODE     3
#define TASK_PERIODIC_MODE    4
#define TASK_SLEEP_MODE       5


#define MAXARGS 20

struct EMPTY_TASK_STR 
{
  unsigned int nMode;
  unsigned short nNr;
  double rFreq;
  double rSleep;
  unsigned int nPriority;
  unsigned int nStackSize;
  unsigned int nMessageSize;
  unsigned int nSchedPriority;
  char *pBinaryName;
  char acName[20];
  short nVerbose;
  short nDebug; 
  struct EMPTY_TASK_STR *pMe;
  struct EMPTY_TASK_STR *pMaster;
  unsigned long ulMaster;
  unsigned long ulName;
  //RTIME rtPeriod;
  struct sched_param sSched;
  unsigned long ulEpoch;
  unsigned int unQuitSem;
  //SEM *pQuitSem;
  char acMyIpcName[32];
  pid_t pidMyIpc;

  char acProxyName[32];
  pid_t pidProxy;
  int nProxyPrio;
  int nProxyBuffLen;
  void *pProxyBuff;
  int (*nProceed)(struct EMPTY_TASK_STR *p,void *);
  int (*nInitCodeInRealTime)(struct EMPTY_TASK_STR *p,void *);
  int (*nCleanupCodeInRealTime)(struct EMPTY_TASK_STR *p, void *);
  int (*nInitCodeBeforeRealTime)(struct EMPTY_TASK_STR *p,void *);
  int (*nCleanupCodeAfterRealTime)(struct EMPTY_TASK_STR *p, void *);
  void *pYourPtr;
  short bStartTask;
  char *pLogFileName;
  int nLogSocket;
  char *pExtraArg[MAXARGS];
  short nExtraArgs;
  short  nThreads;
  short  nSleepBeforeTerm;
  double rLastTime;
  int nSocketPort;
  int nTwinThreadNr;
};

struct MASTER_STR 
{
  long lStartSec;
  char acThreadName[100][20];
  pthread_t *pThread[100];
  struct EMPTY_TASK_STR *pTask[100];
  int nThreads;
  bool bDebug;
  bool bVerbose;
};
int task_proceed( struct EMPTY_TASK_STR  *pTask);
void StartTasks( void);


#endif







