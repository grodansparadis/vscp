#ifndef __CANSSV_H
#define __CANSSV_H
#include "com.h"
//#include "canmsg.h"
#include "can4linux.h"

#define SSV_CAN_MSG_LENGTH 8

struct canmsg_ssv_t {
        short           flags;
        int             cob;
        unsigned long   id;
        unsigned long   timestamp;
        unsigned int    length;
        char            data[CAN_MSG_LENGTH];
};

/* Definitions to use for canmsg_t flags */
#define SSV_MSG_RTR (1<<0)
#define SSV_MSG_OVR (1<<1)
#define SSV_MSG_EXT (1<<2)



#define POLLALL_FIFO_SIZE 15
#define SERIALPORT_CAN232_1 6

class Ccanssv
{
  bool bIsOpen;
  bool bDebug;
  
  bool bInitOk;
  bool bWorking;

  int fd;
  
  canmsg_t sPollCanMsg;
  canmsg_t sPollAllCanMsg[POLLALL_FIFO_SIZE];
  int nPolled;
  
  long lPollCnt;
  long lSession;
  long lSendCnt;
  long lSendRawCnt;
  long lErrorCnt;
  
  int nSyncErrorCnt;
  
  unsigned char ucStatusFlag;
    
  
  int nErrorAtBit[8];
  
  void MarkErrors(int nFlag);

  sem_t sLock;
  
 public:
  Ccanssv(int nDevice=0, int nCanRate=250000);
  Ccanssv(char *pDevice,int nCanRate=250000);
  ~Ccanssv();
  bool bInit( char *pDeviceName, int nCanRate);
  bool bGetIfInitOk( void);
  unsigned char ucGetStoredStatus( void);
  bool bSetCode( int n);
  bool bSetMask( int n);
  bool bSetCodeMask(int nCode, int nMask);
  int nStatusFlag(int nShow=0);
  int nVersion( void);
  int bSetup( int nRate);
  char *pStatusText(int nShow=0);
  bool bOpen( void);
  bool bClose( void);
  bool bSendLine( char *p);
  bool bSend( int id,int nLen,unsigned char *p);
  bool bSendCanMsg( canmsg_t *pMsg);
  canmsg_t *pPollMsg(canmsg_t *pMsg=0);
  canmsg_t *pPollMsgs(int *pnPoll=0,canmsg_t *pMsgs=0);
  char *pPoll(char *p=NULL);
  char *pPollAll(char *p=NULL);
  bool bGetIsOpen( void);
};

#endif
