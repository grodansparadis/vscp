#include "master.h"


class Cemptytask
{
  struct EMPTY_TASK_STR *psTask;

 public:
  Cemptytask( struct EMPTY_TASK_STR *pTask=0);
  ~Cemptytask( void);
  int nProceed( struct EMPTY_TASK_STR *pTask=0);
  void Init( struct EMPTY_TASK_STR *pTask=0); 
  struct EMPTY_TASK_STR  *psGetTaskStrPtr( void);
};
