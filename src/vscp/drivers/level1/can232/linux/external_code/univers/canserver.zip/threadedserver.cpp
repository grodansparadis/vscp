/*  Make the necessary includes and set up the variables.  */
//testserver.cpp
#include <string.h>
#include "threadedserver.h"



////////////////////////////////////////////////////////////
// Server voids
////////////////////////////////////////////////////////////

CServer::CServer(int nPort, char *pText, bool bVerbose) // On Create
{ 
  this->bVerbose=bVerbose;
  this->pText = new char[strlen(pText)+10];
  strcpy(this->pText,pText);
  if(pText && bVerbose)
    printf("%s:Creating a threaded server on socket %d\n",pText,nPort);
  init(nPort);
}

void CServer::init( int nPort)
{

  //  printf("\nOpens port socket:%d\n", nPort);
  this->nPort = nPort;

  /*  Remove any old socket and create an unnamed socket for the server.  */
  
  server_sockfd = socket(AF_INET, SOCK_STREAM, 0);

  /*  Name the socket.  */
  
  server_address.sin_family = AF_INET;
  server_address.sin_addr.s_addr = htonl(INADDR_ANY);
  server_address.sin_port = htons(nPort);
  server_len = sizeof(server_address);
  bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
  
  /*  Create a connection queue and wait for clients.  */
  
  listen(server_sockfd, 5);
}


int CClientHandler::nGetNetAddr( void)
{
  return client_address.sin_addr.s_addr;
}

unsigned short int CClientHandler::nGetPort( void)
{
  return client_address.sin_port;
}

void CClientHandler::PrintAddrPort( void)
{
  int nPort = nGetPort();
  int nAddr = nGetNetAddr();
  int n3 = nAddr&0xff;
  int n2 = (nAddr>>8)&0xff;
  int n1 = (nAddr>>16)&0xff;
  int n0 = (nAddr>>24)&0xff;
  printf("%d.%d.%d.%d:%d",n3,n2,n1,n0,nPort);
}


CClientHandler* CServer::bAccept( void)
{
  //  printf("server waiting for connection\n");
  struct sockaddr_in client_address;
  socklen_t client_len = sizeof(client_address);
  int client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address, &client_len);
  if (client_sockfd >= 0){
    CClientHandler* newClient = new CClientHandler(client_sockfd);
    newClient->SetData(client_address,client_len);
    /*  We can now read/write to client on client_sockfd.  */
    if(bVerbose){
      printf("%sA new client connected from ",pText);
      newClient->PrintAddrPort();
      printf("\n");
    }
    return newClient;
  }
  return NULL;
}

CClientHandler CServer::oAccept( void)
{
  
  if(bVerbose)
    printf("%sSocket server waiting for connection\n",pText);
  struct sockaddr_in client_address;
  socklen_t client_len = sizeof(client_address);
  int client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address, &client_len);
  CClientHandler newClient(client_sockfd);
  newClient.SetData(client_address,client_len);
    /*  We can now read/write to client on client_sockfd.  */
  if(bVerbose){
    printf("%sA new client connected from ",pText);
    newClient.PrintAddrPort();
    printf("\n");
  }
  return newClient;
}

CServer::~CServer() //destructor
{
  if (server_sockfd>=0)
    close(server_sockfd);
  if(pText)
    delete pText;
}


////////////////////////////////////////////////////////////
// Client voids
////////////////////////////////////////////////////////////

CClientHandler::CClientHandler(int sockfd) //Creator
{ 
  client_sockfd = sockfd;
}


CClientHandler::~CClientHandler() //destructor
{
  if (client_sockfd>=0)
  	close(client_sockfd);
}

bool CClientHandler::bIsValid( void)
{
  return client_sockfd>=0;
}


int CClientHandler::nRead( void)
{
  return nReadChar();
}

int CClientHandler::nReadChar(void) //read byte form socket
{
  unsigned char inmessage;
  int n;
  n=read(client_sockfd, &inmessage, 1);
  return (n>0)? ((int)inmessage)&0xff:-1;
}

int CClientHandler::nGetLine( char *p, int nMax)
{
  int n=0;
  for (n=0;p && ((n< nMax) || (nMax==0));n++){
    int c;
    p[n]=0x00;
    c = nReadChar();
    if((c==0x0d)||(c==0x0a)){
      break;
    }
    else if (c<0){
      n=-1;
      break;
    }
    p[n]=c;
  }
  //  printf("Break");
  return n;
}


int CClientHandler::nGetStr( char *p, int nMax)
{
  return p ? nGetUntil(p,nMax,0x00):0;
}


int CClientHandler::nGetUntil( char *p, int nMax,int cEnd)
{
  int n=0;
  for (n=0;p && ((n< nMax) || (nMax==0));n++){
    int c;
    p[n]=0x00;
    c = nReadChar();
    if(c==cEnd){
      break;
    }
    else if (c<0){
      n=-1;
      break;
    }
    p[n]=c;
  }
  return n;
}

int CClientHandler::nRead(char *pMessage, int nMsglenght) //read string from socket
{
  int n=0;
  if(pMessage){
    char c;
    if (nMsglenght==0)
      while((read(client_sockfd, &c, 1)==1)&&(c != '\0'))
	{
	  pMessage[n++]=c;
	  pMessage[n]=0x00;
	}
    else 
      n=read(client_sockfd, pMessage, nMsglenght);
  }
  return n;  

}


int CClientHandler::nWriteStr( char *p)
{
  return p ? nWrite(p,strlen(p)+1):0;
}


int CClientHandler::nWriteLine( char *p)
{
  int nRet=0;
  if(p){
    nRet =nWrite(p);
    if(nRet>=0){
      nRet+=nWrite("\n",1);
    }
  }
  return nRet;
}

int CClientHandler::nWrite(char *p)
{
  return p ? nWrite(p,strlen(p)):0;
}


int CClientHandler::nPutLine( char *p)
{
  return nWriteLine(p);
}


int CClientHandler::nWrite( char c)
{
  return write(client_sockfd, &c, 1);
}


int CClientHandler::nWriteChar(char message) //write a byte to socket
{
  return write(client_sockfd, &message, 1);
}

int CClientHandler::nWrite(char *pMessage, int nMsglenght) //write a string to socket
{ 
  return pMessage ? write(client_sockfd, pMessage, nMsglenght):0;
}

















