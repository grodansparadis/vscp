#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "com.h"
//#include <semaphore.h>


// Serialport number 1, nPortIn = 0, 
// Serialport number 2, nPortIn = 1

Csercom::Csercom(int nPortIn, int nBaudInput, int nBaudOutput)
{
   nPort = nPortIn;
   nInBaud = nBaudInput;
   nOutBaud = nBaudOutput;
   bLog = 0;
   bReadLog = 0;
   bPortIsOpen = 0;
   pfLog = 0;
   pfReadLog = 0;
   bInit();
}

Csercom::Csercom(char *pcLogFileName,int nPortIn, int nBaudInput, int nBaudOutput)
{
   nPort = nPortIn;
   nInBaud = nBaudInput;
   nOutBaud = nBaudOutput;
   bLog = 0;
   bReadLog = 0;
   bPortIsOpen = 0;
   pfLog = 0;
   pfReadLog = 0;
   bInit();
   vLoggingOn( pcLogFileName);
}

Csercom::Csercom( char *pcReadFromLog)
{
  bReadFromLogOn( pcReadFromLog);
}


Csercom::~Csercom()
{
  bClose();
  vLoggingOff();
}



void Csercom::NonBlockingMode( void)
{
  int  flags;
  /* printf("read_HEAD %i\n",fd); */

  flags = fcntl(nFileDes, F_GETFL);
  flags |= O_NONBLOCK; /* Non blocking  mode */
  fcntl(nFileDes,F_SETFL,flags);
}

void Csercom::BlockingMode( void)
{
  int  flags;
  flags = fcntl(nFileDes, F_GETFL);
  flags &= ~O_NONBLOCK; /* Blocking  mode */
  fcntl(nFileDes,F_SETFL,flags);
}

bool Csercom::bReadFromLogOn( char *pc)
{
  if(pc){
    if ( bReadLog)
      vReadFromLogOff();
    pfReadLog = fopen( pc, "rb");
    bReadLog = (pfReadLog != 0);
    nArrayIndex = 0;
    //  nReadNextLineFromLog();
    rLogOpenTime = rGetSystemTime();
    nReadNextLineFromLog();
    vWaitAccordingToLogOn();
    puts(cArray);
  }
  return bReadLog; 
}


void Csercom::vReadFromLogOff( void)
{
  if ( pfReadLog)
    fclose( pfReadLog); 
  bReadLog = 0;
}


void Csercom::vWaitAccordingToLogOn( void)
{
  bWaitAccordingToLog = 1;
}

void Csercom::vWaitAccordingToLogOff( void)
{
  bWaitAccordingToLog = 0;
}

void Csercom::vWaitAccordingToLog( void)
{
  double rTime = rGetSystemTime()-rLogOpenTime;
  double rTimeInLog = sLog.rTime;
  //  printf("%f %f\n",rTime,rTimeInLog);
  if ( rTimeInLog > rTime){
    unsigned int unWait;
    unWait =(unsigned int) (1000000.0*(rTimeInLog-rTime));
    
    //    printf("%ld\n",unWait);
    
    usleep(unWait);
  }
}

void Csercom::vLoggingOn( char *pc)
{
  char cMsg[200];

  if(pc){
    if ( bLog)
      vLoggingOff();
    pfLog = fopen( pc, "wb");
    bLog = (pfLog != 0);
    rLogOpenTime = rGetSystemTime();
    sprintf( cMsg, "%f,LogFile:%s\n",rLogOpenTime,pc);
    printf("%s",cMsg);
    vStoreLogData( cMsg, strlen( cMsg)+1);
  }
  return;
}


void Csercom::vLoggingOff()
{
  if ( pfLog)
    fclose( pfLog); 
  bLog = 0;
  pfLog = 0;
}


bool Csercom::bClose( void)
{
  int n = close( nFileDes);
  bPortIsOpen = 0;
  return !n;
}


int Csercom::nPutLine( char *p)
{
  return nPuts(p);
}

int Csercom::nPuts( char *ac)
{
  int nLen=0;
  if(ac){
    nLen = nWrite(ac);
    nLen += nWrite((char)0x0d);
  }
  return nLen;
}


bool Csercom::bInit( void)
{
  char acName[32];
  oLock232.off();
  oLock232.wait();
  bLog = 0;
  pfLog = 0;
  sprintf( &acName[0], "/dev/ttyS%d%c",nPort,0);
  //printf("Opens serial port :%s\n",acName);
/* Open the file descriptor and associated input/output stream */
    nFileDes = open( acName, O_RDWR| O_NOCTTY);
    if (nFileDes < 0) {
      fprintf(stdout,"Could not open serial port /dev/ttyS%d\n",nPort);
      fflush(stdout);
      exit(-1);
    }
    if (!bSetBaudrate( nInBaud, nOutBaud)){
      fprintf(stdout,"Not possible to set baudrate");
      exit(-1);
    }
/* turn on blocking mode */
    BlockingMode();
    bPortIsOpen = !0;
    //    puts("bInit ok");
    oLock232.post();
    return !0;
}

double Csercom::rGetSystemTime( void)
{
  struct timeval tm;
  gettimeofday( &tm, NULL); 
  return tm.tv_sec+tm.tv_usec*(1.0/1000000.0);
}

char Csercom::cRead( void)
{
  return nRead();
}


int Csercom::nReadByte( void)
{
  unsigned char nData[1];
  int nStatus;
  //  oLock232.wait();
  if ( bReadLog)
    nStatus = nReadDataFromLog((char*)&nData[0],1);
  else
    nStatus=read(nFileDes,&nData[0],1);
  if ( bLog)
    vStoreLogData((char *) &nData[0], 1);
  //oLock232.post();
  return (nStatus==1) ? nData[0]:-1;
}


int Csercom::nGetDes( void)
{
  return nFileDes;
}


int Csercom::nWrite( char c)
{
  return nWrite(&c,1);
}

int Csercom::nWrite( char *pac, int n)
{
 int nRet=0;
 oLock232.wait();
 if(pac){
   if ( n==0)
     n=strlen(pac);
   nRet = write(nFileDes,pac,n);
 }
 oLock232.post();
 return nRet;
}

int Csercom::nReadChar( void)
{
  return nRead();
}


int Csercom::nRead( void)
{
  char c;
  int n;
  n=nRead(&c,1);
  return (n==1) ? ((int)c)&0xff:-1;
}


int Csercom::nRead( char *pc=0, int nLength=1)
{
  int nRes=0;
  //  printf("Read:%d\n",nLength);
  
  if ( pc){
    oLock232.wait();
    if ( bReadLog)
      nRes = nReadDataFromLog( pc, nLength);
    else 
      nRes = read( nFileDes, pc, nLength); /* read data packet */
    if(nRes<nLength)
      pc[nRes]=0;
    if ( bLog)
      vStoreLogData( pc, nRes);
    oLock232.post();
  }
  return nRes;
}



int Csercom::nReadDataFromLog( char *pc, int nLength )
{
  int i=0;
  if(pc){
    if ( bWaitAccordingToLog)
      vWaitAccordingToLog();
    while ( i < nLength){
      if ( nArrayIndex+nLength<= sLog.nSize){
	for ( ;i<nLength;i++)
	  pc[i]=cArray[nArrayIndex+i];
	nArrayIndex +=nLength;
	if ( nArrayIndex==sLog.nSize)
	  nReadNextLineFromLog();
      }
      else {
	for (;nArrayIndex+i<sLog.nSize;i++)
	  pc[i]=cArray[nArrayIndex+i];
	nReadNextLineFromLog();
      }
    }
  }
  return i;
}



int Csercom::nReadNextLineFromLog(void)
{
  //printf(":");
  int nRes = 0;
  nArrayIndex =0;
  if ( pfReadLog){
    nRes = fread( &sLog,1,sizeof( LOGSTR), pfReadLog);
    if ((nRes == sizeof( LOGSTR)) && sLog.nSize < SERCOM_MAXSIZEOFARRAY){
      nRes = fread( cArray,1, sLog.nSize, pfReadLog);
    }
    else 
      nRes = 0;
  }
  return nRes;
}

void Csercom::vStoreLogData( char *pc, int nLength)
{
  if ( pc && pfLog && bLog){
    sLog.rTime = rGetSystemTime()-rLogOpenTime;
    sLog.nSize = nLength;
    fwrite( &sLog,1,sizeof( LOGSTR), pfLog);
    fwrite( pc,1, nLength, pfLog);
    fflush( pfLog);
    printf("+");
  }
}


bool Csercom::bWaitByte( char n)
{
  int nDta;
  int nEOF;
  nEOF = 100;
  do {
    nDta = nReadByte();
    if ( nDta == EOF){
      nEOF--;
    }
  }
  while ((n != nDta) && nEOF);
  if (!nEOF)
    printf("#");
 return nEOF!=0;
}

bool Csercom::bSendChar( char cData)
{
  return bSendByte(cData);
}


bool Csercom::bSendByte( char cData)
{
  vStoreLogData(&cData,1);
  oLock232.wait();
  int nRet = write(nFileDes,&cData,1);
  oLock232.post();
  return nRet;
  
  //  return fputc( nData, poStream) != EOF; 
}



bool Csercom::bSetBaudrate( int nBaudIn, int nBaudOut)
{
  if ( nBaudOut <= 0 )
    nBaudOut = nBaudIn;

  switch (nBaudIn)
    {
    case 0:
      nInBaud=B0;
      break;

    case 50:
      nInBaud=B50;
      break;

    case 75:
      nInBaud=B75;
      break;


    case 110:
      nInBaud=B110;
      break;

    case 134:
      nInBaud=B134;
      break;

    case 150:
      nInBaud=B150;
      break;

    case 200:
      nInBaud=B200;
      break;

    case 300:
      nInBaud=B300;
      break;

    case 600:
      nInBaud=B600;
      break;

    case 1200:
      nInBaud=B1200;
      break;

    case 2400:
      nInBaud=B2400;
      break;

    case 4800:
      nInBaud=B4800;
      break;

    case 9600:
      nInBaud=B9600;
      break;

    case 19200:
      nInBaud=B19200;
      break;

    case 38400:
      nInBaud=B38400;
      break;

    case 57600:
      nInBaud=B57600;
      break;

    case 115200:
      nInBaud=B115200;
      break;

    case 230400:
      nInBaud=B230400;
      break;

    default:
      nInBaud=B9600;
      break;

      
    }
  switch (nBaudOut)
    {
    case 0:
      nOutBaud=B0;
      break;

    case 50:
      nOutBaud=B50;
      break;

    case 75:
      nOutBaud=B75;
      break;


    case 110:
      nOutBaud=B110;
      break;

    case 134:
      nOutBaud=B134;
      break;

    case 150:
      nOutBaud=B150;
      break;

    case 200:
      nOutBaud=B200;
      break;

    case 300:
      nOutBaud=B300;
      break;

    case 600:
      nOutBaud=B600;
      break;

    case 1200:
      nOutBaud=B1200;
      break;

    case 2400:
      nOutBaud=B2400;
      break;

    case 4800:
      nOutBaud=B4800;
      break;

    case 9600:
      nOutBaud=B9600;
      break;

    case 19200:
      nOutBaud=B19200;
      break;

    case 38400:
      nOutBaud=B38400;
      break;

    case 57600:
      nOutBaud=B57600;
      break;

    case 115200:
      nOutBaud=B115200;
      break;

    case 230400:
      nOutBaud=B230400;
      break;

    default:
      if ( nBaudOut < 0)
	nOutBaud = nInBaud;
      else 
	nOutBaud=B9600;
      break;

      
    }
  struct termios newio; 
  memset(&newio,0, sizeof(newio)); /* Clears termios struct  */   
  
  /* Set the terminal input stream into raw mode, and disable all special 
     characters. Also set input to one byte at a time, blocking */
  newio.c_cflag = CS8 | CLOCAL | CREAD; 
 
  /*
    Ignore bytes with parity errors and make terminal raw and dumb.
  */
   newio.c_iflag = IGNPAR; 
  
  /*
    Raw output.
  */
   newio.c_oflag = 0; 
 
  /*
    Don't echo characters because if you connect to a host it or your
    modem will echo characters for you. Don't generate signals.
  */
   newio.c_lflag = 0; 
  

   newio.c_cc[VTIME] = 0;  /* No timeout  */
   newio.c_cc[VMIN]  = 1;   /* read one char at a time  */



  if (cfsetispeed(&newio, nInBaud) == -1) {
    printf("Error setting serial input baud rate\n");
    return 0;
  }
  
  if (cfsetospeed(&newio, nOutBaud) == -1) {
    printf("Error setting serial output baud rate\n");
    return 0;
  }
  tcflush(nFileDes, TCIFLUSH);
  if (tcsetattr( nFileDes, TCSANOW, &newio) == -1) {
    printf("Error setting terminal attributes\n");
    return 0;
  }
  return !0;
}


bool Csercom::bSetStopBits( int n)
{
  nStopBits = n;
  return 1;	
}


bool Csercom::bSetBits( int n)
{
  nBits = n;
  return 1;
}

int Csercom::nGets(char *p, int nMax)
{
  return nGetByteArr(p,nMax,0x0d);
}

int Csercom::nReadLine(char *p, int nMax)
{
  return nGetByteArr(p,nMax,0x0d);
}


int Csercom::nGetByteArr( char *p, int nMax, int cTermByte)
{
  int b=0;
  int n=0;
  if(p){
    for ( n=0;n < nMax && b>=0;n++){	
      b = nReadChar();
      if ( p && b>=0)
	*(p++)= b;
      if ( b ==cTermByte)
	break;
      if(0){
	putchar(b);
	fflush(stdout);
      }
    }
    *p=0x00;
  }
  return n;
}
