#include "canmsglist.h"
#include <string.h>

Scanmsglist::Scanmsglist( Ccanmsg & oMsg, struct Scanmsglist *pNext, struct Scanmsglist *pPrev)
{
  this->pNext = pNext;
  this->pPrev = pPrev;
  this->pMsg = new Ccanmsg( oMsg);
}

Scanmsglist::Scanmsglist( canmsg_t *psMsg,struct Scanmsglist *pNext, struct Scanmsglist *pPrev, int nIndex)
{
  this->pNext = pNext;
  this->pPrev = pPrev;
  this->pMsg = new Ccanmsg( psMsg, nIndex);
}

Scanmsglist::~Scanmsglist()
{
  if(pMsg)
    delete pMsg;
}


Ccanmsglist::Ccanmsglist()
{
  nMaxLength=0;
  nLength=0;
  pPtr=0;
  pHead=0;
  pTail=0;
}

Ccanmsglist::Ccanmsglist(Ccanmsg &oMsg, int nInMaxLength)
{
  nMaxLength=nInMaxLength;
  nLength=0;
  nIndex = 0;
  pHead=0;
  pTail=0;
  pPtr=0;
  nInsertHead( oMsg);
}

Ccanmsglist::Ccanmsglist( canmsg_t *psMsg, int nInMaxLength, int nIndex)
{
  nMaxLength=nInMaxLength;
  nLength=0;
  pHead=0;
  pTail=0;
  pPtr=0;
  nInsertHead( psMsg, nIndex);
}

Ccanmsglist::~Ccanmsglist()
{
}
 
int Ccanmsglist::nGetIndex( void)
{
  return nIndex;
}

int Ccanmsglist::nInsertHead( canmsg_t  *psMsg, int nMsgIndex)
{
  Ccanmsg oMsg(psMsg, nMsgIndex);
  return nInsertHead( oMsg);
}

int Ccanmsglist::nInsertHead( Ccanmsg & oMsg)
{
  Scanmsglist *pElem = new struct Scanmsglist( oMsg,pHead,0);
  if(nLength>0){
    pHead->pPrev = pElem;
    pHead = pElem;
  }
  else {
    pHead = pElem;
    pTail = pElem;
  }
  nLength++;
  nIndex++;
  if(nMaxLength && (nLength>nMaxLength))
    nDeleteTail();
  return nLength;
}


int Ccanmsglist::nDeleteTail(void)
{
  pPopTail();
  return nLength;
}
 

canmsg_t * Ccanmsglist::pPopTail(canmsg_t *pMsg)
{
  Scanmsglist *pElem=pTail;
  if( nLength>0 && pMsg)
    memcpy(pMsg,pElem->pMsg,sizeof(canmsg_t));
  else
    pMsg=0;
  if(pTail==pHead){
    pTail=0;
    pHead =0;
    pPtr = 0;
    nLength=0;
  }
  else if(nLength){
    pTail = pTail->pPrev;
    pTail->pNext=0;
    nLength--;
  }
  delete pElem;
  return pMsg;
}

Ccanmsg * Ccanmsglist::pPtrHead( void)
{
  return pHead ? pHead->pMsg:0;
}


Ccanmsg * Ccanmsglist::pPtrTail(void)
{
  return pTail ? pTail->pMsg:0;
}

int Ccanmsglist::nGetLength( void)
{
  return nLength;
}

Ccanmsg * Ccanmsglist::pGetPtr(void)
{
  return pPtr ? pPtr->pMsg:0;
}

Ccanmsg * Ccanmsglist::pPtrAndNext(void)
{
  if(!pPtr && pHead){
    pPtr = pHead;
  }
  Ccanmsg *p = pPtr ? pPtr->pMsg:0;
  pPtr = pPtr ? pPtr->pNext:0;
  return p;
}


Ccanmsg * Ccanmsglist::pPtrAndPrev(void)
{
  if(!pPtr && pTail){
    pPtr = pTail;
  }
  Ccanmsg *p = pPtr ? pPtr->pMsg:0;
  pPtr = pPtr ? pPtr->pPrev:0;
  return p;
}

Ccanmsg * Ccanmsglist::pPtrGotoHead(void)
{
  Ccanmsg *p = pHead  ? pHead->pMsg:0;
  pPtr=pHead;
  return p;
}


Ccanmsg * Ccanmsglist::pPtrGotoTail(void)
{
  Ccanmsg *p = pTail  ? pHead->pMsg:0;
  pPtr=pTail;
  return p;
}
  
