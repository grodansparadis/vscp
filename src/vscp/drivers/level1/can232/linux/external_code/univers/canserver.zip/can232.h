#ifndef __CAN232_H
#define __CAN232_H
#include "com.h"
#include "canmsg.h"
#include "semaphore.h"

#define SIZE_POLLALLBUFFER 500
#define SIZE_POLLBUFFER 100
#define CAN232_POLLALL_FIFO_SIZE 32
#define SERIALPORT_CAN232_1 6

class Ccan232
{
    class Csercom *pCom;
    
    bool bVerbose;

    bool bIsOpen;
    bool bDebug;

    bool bInitOk;
    bool bWorking;

    canmsg_t sPollCanMsg;
    canmsg_t sPollAllCanMsg[CAN232_POLLALL_FIFO_SIZE];
    int nPolled;

    Csemaphore *poSem;

    struct {
      int nPolled;
      Ccanmsg *poa[CAN232_POLLALL_FIFO_SIZE];
    } sPollCcanmsgStr;
    
    

    char acStatus[500];
    char acFlag[20];
    char acPoll[SIZE_POLLBUFFER];
    char acPollAll[SIZE_POLLALLBUFFER];
    char acReadAndClear[200];
    long lPollCnt;
    long lPolledMsgCnt;
    long lSession;
    long lSendCnt;
    long lSendRawCnt;
    long lErrorCnt;
    long lFormatError;
    long lErrorNoPoll;

    int nSyncErrorCnt;

    unsigned char ucStatusFlag;
 
    char *pStatusText;

    //sem_t sLock232;

    int nErrorAtBit[8];

    // canmsg_t asTmpMsgs[11];

    void MarkErrors(int nFlag);
    int hextoi( char c);
    char tohex(int n);
    int nCmdWaitHead( char *p, char cCmd, char *pHead, int nWaitMircoSeconds=500);
    int nCmdWaitHead( char *p, char *pCmd, char *pHead, int nWaitMircoSeconds=500);
    int nReadAndClearBuffer(char *p=0);
    bool bNrCR( int n=3);
    bool bIsHex( char c);
 
 public:
    Ccan232(int nPort=0, int nCanRate=250000);
    Ccan232(int nPort=0, int nBaudRate=115200,int nCanRate=250000);
    ~Ccan232();
    char *pGetStatusText( char *p=0);
    bool bInit( int nPort, int nBaud, int nCanRate);
    bool bGetIfInitOk( void);
    unsigned char ucGetStoredStatus( void);
    bool bSetCode( int n);
    bool bSetMask( int n);
    int nStatusFlag(int nShow=0);
    int nVersion( void);
    int bSetup( int nRate=115200);
    char *pStatusFlagText(int nShow=0);
    bool bOpen( void);
    bool bClose( void);
    bool bUart( int nBaud);
    bool bSendLine( char *p);
    bool bSend( int nId,int nLen,unsigned char *pData);
    bool bSendCanMsg( canmsg_t *pMsg);
    bool bSend( canmsg_t *pMsg, int nNumbers=1);
    bool bSend11( int nId,int nLen,unsigned char *p);
    bool bSend29( int nId, int nLen, unsigned char *p);
    canmsg_t *pPollMsg(canmsg_t *pMsg=0);
    canmsg_t *pPollMsgs(int *pnPolledMessages,canmsg_t *pMsgs=0);
    Ccanmsg **paoPollCanMsgsObjs( int *pnPolled, Ccanmsg **poMsgs=0);
    char *pPoll(char *p=NULL);
    char *pPollAll(char *p=NULL, int nMaxLength=SIZE_POLLALLBUFFER);
    bool bGetIsOpen( void);
    bool bSyncCan232( void);
};

#endif
