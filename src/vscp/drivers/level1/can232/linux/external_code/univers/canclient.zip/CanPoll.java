import java.lang.*;
import java.util.*;

public class CanPoll
{


    public static void main(String asArgs[])
    {
	if (asArgs.length<3){
	    System.out.println("Usage: java CanPoll <index> <numbers>");
	}
	else {		
	    int nIndex = Integer.valueOf(asArgs[1]).intValue();
	    int nNumbers= Integer.valueOf(asArgs[2]).intValue();
	    CanClient oCanClient = new CanClient( asArgs[0],9009);
	    if(oCanClient.bIsConnected()){
		CanMsg ao[]=oCanClient.aoPoll(nIndex,nNumbers);
		for (int n=0;n<ao.length;n++)
		    if(ao[n]!=null)
			System.out.println("POLLED:"+ao[n].toText());

		oCanClient.disconnect();
	    }
	    else{
		System.out.println("Unable to connect to server "+asArgs[0]);
	    }
	}

	return;
    }
}
