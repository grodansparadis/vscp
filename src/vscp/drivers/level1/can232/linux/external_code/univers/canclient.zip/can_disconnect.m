function can_disconnect(can)
     can.disconnect
