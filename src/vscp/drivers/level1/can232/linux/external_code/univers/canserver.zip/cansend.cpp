#include <stdio.h>
#include <stdlib.h>
#include "can232.h"
#include <time.h>
#include <string.h>
#include "tokenizer.h"



int main( int argc, char *argv[])
{
  if(argc>1){
    Ctokenizer *poToken = new Ctokenizer(argc, argv);
    int nToken = poToken->nFindToken("-s");
    int nSerialDevice = nToken>=0 ? poToken->nToInt(nToken+1):0;
    nToken = poToken->nFindToken("-b");
    int nBaud =  nToken>=0 ? poToken->nToInt(nToken+1):115200;
    nToken = poToken->nFindToken("-c");
    int nSpeed =  nToken>=0 ? poToken->nToInt(nToken+1):250000;
    int nServer = poToken->nFindToken("-s");
    nToken = poToken->nFindToken("-i");
    int nId =  nToken>=0 ? poToken->nToInt(nToken+1):0;
    printf("Sending on /dev/ttyS%d Baudrate=%d Speed=%d\n",nSerialDevice,nBaud,nSpeed);
    
    if(nServer<0){
      class Ccan232 *poCan = new Ccan232( nSerialDevice, nBaud, nSpeed);
      if (poCan && poCan->bOpen()){
	canmsg_t sMsg;
	sMsg.id = nId;
	nToken = poToken->nFindToken("-d");
	for (int n=0;(n<8) && ((n+nToken+2)<poToken->nGetTokens());n++){
	  sMsg.data[n]=(unsigned char)poToken->lHexToLong(n+nToken+1);
	  sMsg.length=n+1;
	}
	bool bRet=poCan->bSend(&sMsg);
	if( bRet){
	  Ccanmsg *po= new Ccanmsg(&sMsg);
	  printf("Sent:%s\n",po->pToText());
	  delete po;
	}
      }
      delete poCan;
    }
    else {
    }
  }
  else {
    
  }
  return 1;
}
