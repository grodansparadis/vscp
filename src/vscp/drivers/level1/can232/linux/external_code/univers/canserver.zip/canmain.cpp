#include <stdio.h>
#include <stdlib.h>
#include "can232.h"
#include <time.h>
#include <string.h>
#include "master.h"
#include "emptytask.h"

static pthread_t cansrv_thread;
static pthread_t can_thread;

extern void *cansrv_task(void*);
extern void *cansrvtx_task(void*);
extern void *can_task( void*);
extern struct MASTER_STR sMaster;


int main( int argc, char *argv[])
{
  if(argc<3){
    printf("CANSERVER, Written by Sven R�nnb�ck sr@sm.luth.se.\nCompiled %s %s\n",__DATE__,__TIME__);
    printf("Usage: canserver <serialdevice> <canspeed>\n");
    printf("<serialdevice> use serial port:  0 == /dev/ttys0,   X=/dev/ttySX,  default 0\n");
    printf("<canspeed>        Use canbus rate :  Default rate 250K\n");
    exit(0);
  }
  printf("Using oprions\n");
  printf("Serial device   :/dev/ttys%s\n",argv[1]);
  printf("CAN bus speed   :%s\n",argv[2]);
  Cemptytask *poCanTsk;
  Cemptytask *poCanSrvTsk;
  struct MASTER_STR *p=&sMaster;
  for (int n=0;n<1;n++){
    poCanTsk = new Cemptytask();
    poCanSrvTsk = new Cemptytask();
    poCanTsk->psGetTaskStrPtr()->pExtraArg[0]=argv[1];
    poCanTsk->psGetTaskStrPtr()->pExtraArg[1]=argv[2];
    if (pthread_create(&can_thread, NULL,can_task,poCanTsk->psGetTaskStrPtr())) { 
      printf("ERROR IN CREATING CANTSK\n");
      exit(1);
    }       
    p->pTask[p->nThreads] = poCanTsk->psGetTaskStrPtr();
    p->pThread[p->nThreads++] = &can_thread;
    
    if (pthread_create(&cansrv_thread, NULL,cansrv_task,poCanSrvTsk->psGetTaskStrPtr())) { 
      printf("ERROR IN CREATING CANSRVTSK\n");
     exit(1);
    }       
    p->pTask[p->nThreads] = poCanSrvTsk->psGetTaskStrPtr();
    p->pThread[p->nThreads++]= &cansrv_thread;
  }
  sleep(1);
  if(1>0){
    Ccandev *poDev;
    do {
      sleep(1);
      poDev= CAN_pGetDevicePtr(0);
    }while(poDev==0);
    if(poDev){
      Ccanmsgdb *poDB = poDev->pGetDBPtr();
      for (int n=0;n<10000;n++){
	sleep(10);
	puts(poDB->pGetStatusText());
	
      }
    }
    delete poDev;
  }

  return 1;
}
