#ifndef __CINTEGER_H
#define __CINTEGER_H

class Cinteger
{
  long int nLocal;
  int nBits;
  bool bLeadingZeros;
  char *pcToDec;
  char *pcToHex;

 public:
  Cinteger();
  ~Cinteger();
  Cinteger( char *p);
  Cinteger( int nNumber,int nBits=64);
  void set(long int n, int nBits=64);
  Cinteger *pSet(long int n, int nBits=64);
  char *pToDec(int nDecTals=10,char *p=0);
  char *pToHex(int nNibbles=8,char *p=0);
  int nHexAscToInt(char c);
  char cIntToHexAsc(int n);
  long lHexStrToLong( char *p);
  long lDecStrToLong( char *p);
  int nGetValue(void);
};

#endif

