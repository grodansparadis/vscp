#ifndef __TOKENIZER_H
#define __TOKENIZER_H

class Ctokenizer
{
  char *pText;
  int nTextSize;
  int nTextAllocSize;

  int nTokens;
  char **apToken;
  int nTokenAllocSize;

   int nLines;
  int *pnLineArg;
   int nLineArgAllocSize;
  
  int hextoi(char c);

public:
  Ctokenizer(int nArgc, char *pArgv[]);
  Ctokenizer( char *p);
  Ctokenizer(void);
  ~Ctokenizer(void);
  void init(void);
  bool bIsSpace(char c);
  int nFindToken(char *pTok, int nOffset=0);
  void Tokenize( char *pText);
  void TokenizeFile( char *pFile);
  int nToInt( int nToken);
  long lToLong( int nToken);
  double rToDouble(int nToken);
  bool bToBool( int nToken);
  int nGetToken( int nToken);
  long lHexToLong( int nToken);
  long lHexToLong( char *p);
  char *pGetToken( int nToken);
  char *pGetLineToken(int unLine,int nToken);
  int nGetLineTokens( int nLine);
  int nGetLines( void);
  int nGetTokens( void);
  bool bEqual(int nToken,char *p);
  void Show(void);
};

#endif

