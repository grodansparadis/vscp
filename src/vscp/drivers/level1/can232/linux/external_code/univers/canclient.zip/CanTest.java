import java.io.*;
import java.net.*;
import java.util.*;

public class CanTest
{
    static CanClient oCan = null;
    static BoreCan oBore = null;


    public static void main(String args []) 
    {
	

	oCan = new CanClient("130.240.2.40",9009);
	//testCan();


	oBore = new BoreCan("130.240.2.40",9009,40);
	testBore();
	

	oBore.disconnect();
	oCan.disconnect();
	

    }

    public static void testBore()
    {
	//	oBore.bDriveDirectCan( 150, -150);//OK
	//oBore.bDriveCan(0x100,0); //OK
	//MotorCount oMotorCount = oBore.oGetMotorCount();
	while(1>0){
	    MotorCount oMotorCount = oBore.oGetNDCMotorCount();
	    testMotor(oMotorCount);	
	    oMotorCount = oBore.oGetEncoderValues();
	    testMotor(oMotorCount);	
	}
    }
    

    public static void testMotor(MotorCount oMotorCount){

	int mLeft = oMotorCount.nGetLeft();
	int mRight = oMotorCount.nGetRight();
	boolean bNDC = oMotorCount.bIsNDC();
	System.out.println("NDC:"+bNDC+" right engine: "+mRight+" left engine: "+mLeft);
	
    }
    
    

    public static void testCan()
    {
      
	{
	    System.out.println("\nFifo index:"+oCan.nGetFifoIndex());
	    CanMsg aoCan[] = oCan.aoListCanIds();
	    if(1<0){
		for ( int n=0;n<aoCan.length;n++){
		    System.out.println("Id "+n+"|"+aoCan[n].toString());
		}
	    }

	}
	/*
	aoCan = oCan.aoGetIdList(144,100);
	for ( int n=0;n<aoCan.length;n++){
	    System.out.println("Id "+n+"|"+aoCan[n].toString());
	}
	*/
    }

}
