#include <string.h>
#include <sys/time.h>
#include "candev.h"


Ccanwait_node::Ccanwait_node(int nId, int nStartIndex, int nMilliSecToTimeOut, bool bDebugInput)
{
  this->poSemClient = new Csemaphore(0);
  this->bInUse = false;
  this->nId = nId;
  this->nMilliSecToTimeOut = nMilliSecToTimeOut;
  this->nStartIndex = nStartIndex;
  this->nIndex= nStartIndex;
  this->bDebug = bDebugInput;
}

Ccanwait_node::~Ccanwait_node()
{
  if(bDebug)
    printf("CANWAIT_NODE:Erasing node\n");
  delete poSemClient;
}

bool Ccanwait_node::bActive( void)
{
  return bInUse;
}

int  Ccanwait_node::nGetId( void)
{
  return nId;
}

int  Ccanwait_node::nGetIndex( void)
{
  return nIndex;
}

int  Ccanwait_node::nIncIndex( void)
{
  return ++nIndex;
}



bool Ccanwait_node::bWait( bool bByTime)
{
  bInUse = true;
  if(!bByTime)
    poSemClient->wait();
  else 
    usleep(nMilliSecToTimeOut*1000);
  return bByTime;
}

bool Ccanwait_node::bRelease( bool b)
{
  bInUse = false;
  if(!b){
    nIndex = 0;
    nMilliSecToTimeOut = -1;
  }
  poSemClient->post();
  return true;
}

bool Ccanwait_node::bTimeOut( void)
{
  return oTime.bAlarmMilli(nMilliSecToTimeOut);
}


Ccanwait::Ccanwait( Ccanmsgdb *pDB, bool bDebugInput)
{
  this->pDB = pDB;
  poWaitFunLock = new Csemaphore(1);
  poWaitLock = new Csemaphore(0);
  poLock = new Csemaphore(1);
  pIdList = new Clinkedlist(50,0);
  pIndexList = new Clinkedlist(50,0);

  bDebug=false;
  bVerbose=false;
  if(bDebugInput){
    bDebug = true;
    bVerbose=true;
  }
}

Ccanwait::~Ccanwait( )
{
  delete pIdList;
  delete pIndexList;
  delete poWaitFunLock;
  delete poWaitLock;
  delete poLock;
}



int Ccanwait::nWaitCanId(int nId, int nStartIndex, int nMilliSecToTimeOut=0)
{
  poLock->wait();
  Ccanwait_node *pCanWait = new Ccanwait_node(nId,nStartIndex,nMilliSecToTimeOut, bDebug);
  pIdList->nInsertHead((void*)pCanWait);
  if(bDebug)
    printf("CANWAIT:nWaitCanId @lock A\t");
  poLock->post();

  if(bDebug)
    printf("CANWAIT:Waiting for clientrelease, nId=%X  Mem=%X\n",(unsigned)nId,(unsigned)pCanWait);
  pCanWait->bWait();
  if(bDebug)
    printf("CANWAIT:Client released, nId=%X\n",nId);
  
  poLock->wait();
  //sem_wait(&pCanWait->sLock);
  
  if(1>0){
    ////////////////////////////////////////////////////////////////
    // Delete node from wait id list
    ////////////////////////////////////////////////////////////////
    Ccanwait_node *p=(Ccanwait_node *)pIdList->pStepPtrGotoHead();
    for (int nNode=0;nNode<pIdList->nGetLength();nNode++){
      p=(Ccanwait_node *)pIdList->pGetAtStepPtr();   
      if (p==pCanWait){
	p=(Ccanwait_node *)pIdList->pPopAtStepPtr();
	if(bDebug)
	  printf("CANWAIT:Popping node %X  list length:%d\n",(unsigned)p,pIdList->nGetLength());
	break;
      }
      else {
	if(bDebug)
	  printf("<searching:%d>",++nNode);
      }
      pIdList->pStepPtrNext();
    }
    
  }
 
  //sem_post(&pCanWait->sLock);
  int nIndex = pCanWait->nGetIndex();
  delete pCanWait;
  poLock->post();
  if(bDebug)
    printf("CANWAIT:Client exit fourd nId=%X at nIndex=%d, nStartIndex=%d\n",nId,nIndex, nStartIndex);
  return nIndex;
}


int Ccanwait::nWaitCanIndex( int nIndex)
{
  poWaitFunLock->wait();
  poLock->wait();
  int nFifoIndex = pDB->nGetFifoIndex();
  if(nIndex > nFifoIndex){
    nWaitIndex = nIndex;
    poLock->post();
    poWaitLock->wait();
  }
  else {
    if(!nIndex)
      nIndex = nFifoIndex;
    else if((nFifoIndex - nIndex) >= MAX_CANRXMSGS)
      nIndex = 0;
    poLock->post();
  }
  poWaitFunLock->post();
  return nIndex;
}

int Ccanwait::nReleaseIdLock( int nMaxIndex)
{
  int nReleased=0;
  int nListLength = pIdList->nGetLength();
  //printf("CANWAIT:ReleaseID enter 1\t");
  poLock->wait();
  /*

  CAN ID RELEASE OF WAIT NODE

  */
  if( nListLength>0){
    if(1>0){
      Ccanwait_node *pNode=(Ccanwait_node *)pIdList->pStepPtrGotoHead();
      for(int nNode=0;(nNode < nListLength) && (pNode=(Ccanwait_node *)pIdList->pGetPtrAndStepNext());nNode++){
	//      sem_wait(&pId->sLock);
	if(pNode->bActive()){
	  for(;(pNode->nGetIndex()<=nMaxIndex);pNode->nIncIndex()){
	    int nMsgId = pDB->nGetFifoCanIdByIndex( pNode->nGetIndex());
	    if(bDebug)
	      printf("CANWAIT:Trying to ReleaseLock on Id,Index=%d, ID=%X, Lock ID=%X\n",pNode->nGetIndex(),(unsigned) nMsgId,(unsigned)pNode->nGetId());
	    if( nMsgId==pNode->nGetId()){
	      pNode->bRelease();
	      nReleased++;
	      if(bDebug){
		printf("CANWAIT:Received ID=%X, Released lock on ID=%X, Index=%d  Mem=%X\n",(unsigned)nMsgId,pNode->nGetId(), pNode->nGetIndex(), (unsigned)pNode);
		//sleep(1);
	      }
	      break;
	    }
	  }
	}
	//  sem_post(&pNode->sLock);
      }
    }
    /*

    TIMEOUT RELEASE OF NODE 
    indicated by setting pNode->nIndex=0 and pNode->nMilliSecToTimeout<0
    */
    if (1>0){
      // timeout node, thing
      Ccanwait_node *pNode=(Ccanwait_node *)pIdList->pStepPtrGotoHead();
      for(int nNode=0;(nNode<nListLength) && (pNode=(Ccanwait_node *)pIdList->pGetPtrAndStepNext());nNode++){
	
	if(pNode->bActive()){
	  if(bDebug)
	    printf("CANWAIT:DEC TIME ID=0x%X,Index=%d\n",(unsigned)pNode->nGetId(),  pNode->nGetIndex());
	  if(pNode->bTimeOut()){
	    pNode->bRelease(false);;
	    nReleased++;
	    if(bDebug){
	      printf("CANWAIT:Released lock cause of timeof on ID=0x%X, Mem=0x%X\n",(unsigned)pNode->nGetId(),(unsigned) pNode);
	      //  sleep(1);
	    }
	  }
	  if(bDebug){
	    //printf("CANWAIT:<%d MilliSec left for Id=%X>\n",pNode->nTimeLeft(),(unsigned) pNode->nGetId()); 
	  }
	}
	else {
	  if(bDebug)
	    printf("CANWAIT:<node %d:not in use>", nNode);
	}
      }
    }
  }
  poLock->post();
  if(bDebug && nListLength>0)
    printf("CANWAIT:ReleaseID exit MaxIndex=%d\n",nMaxIndex);
  return nReleased;
}


int Ccanwait::nReleaseIndexLock( int nIndex)
{
  if(poWaitLock->nGetValue()==0){
    poLock->wait();
    if(!nIndex)
      nIndex = pDB->nGetFifoIndex();
    if(nIndex>=nWaitIndex && nWaitIndex>0){
      nWaitIndex=0;
      poWaitLock->post();
      if(bDebug)
	printf("CANDEV_nReleaeWaitIndexLock:Released wait lock at %d\n",nIndex);
    }
    poLock->post();
  }
  return nIndex;
}

//////////////////////////////////////////////////////////////////////////////
//
//                Ccandev
//
/////////////////////////////////////////////////////////////////////////////

Ccandev::Ccandev(int nSerialPort, int nCanRate, bool bDebug)
{
  this->bDebug =bDebug;
  int nRet=nInit(nSerialPort,nCanRate);
  if(bDebug)
    printf("CANDEV:Exit creator, nInit()==%d\n",nRet);
}

Ccandev::~Ccandev()
{
  // oLock.wait();
  if ( poCan)
    delete poCan;
  if ( pDB)
    delete pDB;
  if ( pTxDB)
    delete pTxDB;
  if( pWait)
    delete pWait;
  //oLock.post();
  //sem_destroy(&sLock);
}

bool Ccandev::bWorking( void)
{
  bool bRet=0;
  //oLock.wait();
  bRet=poCan->bGetIfInitOk();
  //oLock.post();
  return bRet;
}


int Ccandev::nMsgsInTxDBSend( int nLoop)
{
  int nRet=0;
  canmsg_t *pMsg;
  canmsg_t sMsg;
  do {
    pMsg=pTxDB->pCheckIfSend(&sMsg);
    if(pMsg){
      if(bDebug)
	printf("CANDEV:nMsgInYxDBSend\tSending %X\tAAA",(unsigned)pMsg);
      nRet += poCan->bSendCanMsg(pMsg) ? 1:0;
      if(bDebug)
	printf("BBB nRet=%d\n",nRet);
      
    }
  } while(pMsg && --nLoop>0);
  //oLock.post();
  return nRet;
}

int Ccandev::nCanMsgTxDBInsert(canmsg_t *pMsg,long lMilliSecDuration, long lMilliSecStep)
{
  int nRet=-1;
  //oLock.wait();
  nRet=pTxDB->nInsert(pMsg,lMilliSecDuration*1000, lMilliSecStep*1000);
  //oLock.post();
  return nRet;
}

int Ccandev::nInit( int nDevice, int nCanRate)
{
  // sem_init(&sLock,0,1);
  //oLock.wait();
  pDB=new Ccanmsgdb(2000,true,false);
  pTxDB = new Ccantxdb();
  pWait = new Ccanwait( pDB);
  if( bDebug)
    printf("CANDEV_nInit:Opens candevice %d\n",nDevice);
  lLoop=0;
  unErrors=0;

  nDevice = (nDevice>=0) ? nDevice:SERIALPORT_CAN232_1;
  //nDevice = 6;
  poCan = new Ccan232( nDevice,115200,nCanRate);
  //poCan->bOpen();
  //poCan = new Ccanssv( 0, nCanRate);
  //oLock.post();
  if( bDebug)
    printf("CANDEV_nInit:Exit, init=%s\n",poCan->bGetIfInitOk()?"OK":"FALSE");
  return poCan->bGetIfInitOk() && pDB && pTxDB && pWait;
}

int Ccandev::nGetMaxMsgIndex( int *punErrors)
{
  int nIndex=0;
  if(bDebug)
    printf("CANDEV:get FIFO index pDB=%X  beforelock\t",(unsigned) pDB);
  if(pDB){
    //oLock.wait();
    nIndex = pDB->nGetFifoIndex();
    if(bDebug)
      printf("CANDEV:get FIFO index=%d  afterlock\n",nIndex);
    if(punErrors)
      *punErrors=unErrors;
    //oLock.post();
  }
  return nIndex;
}


bool Ccandev::bOpen( void)
{
  bool bRet=0;
  if( bDebug)
    printf("CANDEV:OPEN ENTER\n");
  //oLock.wait();
  bRet=poCan->bOpen();
  if(!bRet){
    printf("CANDEV_bOpen:Unable to open device\n");
  }
  //oLock.post();
  if( bDebug)
    printf("CANDEV:OPEN EXIT\n");
  return bRet;
}

bool Ccandev::bClose( void)
{
  bool bRet=false;
  //oLock.wait();
  bRet=poCan->bClose();
  //oLock.post();
  return bRet;
}


bool Ccandev::bSetCodeMask(int nCode, int nMask)
{
  bool bRet=true;
  //oLock.wait();
  //  bRet=poCan->bClose();
  bRet &=poCan->bSetMask(nMask);
  bRet &=poCan->bSetCode(nCode);
  //  bRet=poCan->bClose();
  //oLock.post();
  return bRet;
}


bool Ccandev::bSend( int nId, int nLen,unsigned char *pData)
{
  bool bRet=0;
  if((pData && (nLen>=0))||((!nLen)&&(!pData))){
    //oLock.wait();
    if(bDebug){
      printf("Ccandev::bSend| CanId:%X length:%d DriveId:%s,DRIVEID:%X\n",nId,nLen, nId==CAN_DRIVEID ? "OK":"FALSE",CAN_DRIVEID);
    }
    bRet=poCan->bSend(nId,nLen,pData);
    if(bDebug){
      printf("CANDEV:bSend end\n");
    }
    //oLock.post();
  }
  return bRet;
}



bool Ccandev::bSend( Ccanmsg *poMsg)
{
  bool bRet=0;
  if(poMsg){
    canmsg_t sMsg;
    poMsg->CopyTo( &sMsg);
    bRet=bSend(&sMsg);
  }
  return bRet;
}

bool Ccandev::bSend( canmsg_t *pMsg)
{
  bool bRet=0;
  if(pMsg){
    //oLock.wait();
    bRet=poCan->bSend(pMsg);
    //oLock.post();
  }
  return bRet;
}

int Ccandev::nSend( canmsg_t *pMsg,int nId)
{
  int nIndex=0;
  if(pMsg){
    bool bRet=bSend(pMsg);
    if(bRet){
      nIndex = nWaitCanId( nId);
      nIndex= nGetCanMsg( pMsg, nIndex);
    }
  }
  return nIndex;
}

int Ccandev::nWaitCanCodeMask( int nCode, int nMask)
{
  int nRet=0;
  nRet += poCan->bSetMask(nMask) ? 1:0;
  nRet += poCan->bSetCode(nCode) ? 1:0;
  int nIndex = pDB->nGetFifoIndex();  
  return nIndex;
}


int Ccandev::nReleaseWaitLocks(void)
{
  int nIndex = pDB->nGetFifoIndex();
  nReleaseWaitIndexLock( nIndex);
  nReleaseIdLock( nIndex);
  return 1;
}

 
int Ccandev::nInsertRxMsg( canmsg_t *pMsg)
{
  int nIndex=0;
  if(pMsg && pDB){
    //oLock.wait();
    nIndex = pDB->nInsert(pMsg);
    //oLock.post();
  }
  return nIndex;
}


/*
int Ccandev::nInsertRxMsg( char *pSrc, unsigned char ucFlag,double rTimeStamp)
{
  int nInsertedMsgs=0;
  if(pSrc){
    struct Scandev *pStr;
    pStr = (struct Scandev *) &sDevStr;
    oLock.wait();

    while(*pSrc && *pSrc!='A'){
      if(*pSrc=='T'){
	int nArrayPos;
	char *p;
	nArrayPos = unCnt&(MAX_CANRXMSGS-1);
	p=&aacMsg[nArrayPos][0];
	pSrc++;
	for(int n=0;n<30 && *pSrc && (*pSrc!=0x0d) && (*pSrc!='T')&&(*pSrc!='A');n++)
	  *(p++)=*(pSrc++);
	*p=0x00;
	if(0)
	  printf("%d:Message array:%s\n",unCnt,aacMsg[ nArrayPos]);
	if(ucFlag)
	  unErrors++;
	aucFlag[nArrayPos]=ucFlag;
	arTimeStamp[nArrayPos]=rTimeStamp;
	unCnt++;
	if(unCnt==unWaitCnt)
	  sem_post(&sWaitLock);           // release wait client
	nInsertedMsgs++;
      }
      if(*pSrc==0x0d)
	pSrc++;
    }
    oLock.post();
  }
  return nInsertedMsgs;
}
*/


int Ccandev::nSearchId( int nId, int nLowerIndex)
{
  int nIndex=0;
  canmsg_t sMsg,*pMsg;
  //oLock.wait();
  for (int n=pDB->nGetFifoIndex();n>=nLowerIndex;n--){
    pMsg =pDB->pGetCanMsgByIndex(n,&sMsg);
    if(pMsg){
      if(sMsg.id==(unsigned)nId){
	nIndex = n;
	break;
      }  
    }
  }
  //oLock.post();
  return nIndex;
}


// returns message index
int Ccandev::nWaitCanId(int nId, int nStartIndex, int nMilliSecToTimeOut)
{
 return pWait->nWaitCanId( nId,nStartIndex, nMilliSecToTimeOut);
}

int Ccandev::nReleaseIdLock( int nMaxIndex)
{
  return pWait->nReleaseIdLock( nMaxIndex);
}

// return nCanIndex
int Ccandev::nWaitCanIndex( int nIndex)
{
  return pWait->nWaitCanIndex( nIndex);
}

int Ccandev::nReleaseWaitIndexLock( int nIndex)
{
  return pWait->nReleaseIndexLock(nIndex);
}


//return index
int Ccandev::nGetCanMsg(canmsg_t *pCanMsg, int nIndex)
{
  if(pCanMsg){
    nIndex=nWaitCanIndex(nIndex);
    if(nIndex>0){
      //      oLock.wait();
      pCanMsg = pDB->pGetCanMsgByIndex(nIndex,pCanMsg);
      //memcpy(&pCanMsg[0], pDB->pGetFifoPtr(nIndex),sizeof(canmsg_t));
      //oLock.post();
    }
  }
  return pCanMsg ? nIndex:0;
}


char * Ccandev::pGetStatusText( char *p)
{
  return poCan->pGetStatusText(p);
}


Ccanmsg Ccandev::oGetCanMsg( int nIndex)
{
  canmsg_t sMsg, *pMsg;
  nIndex=nWaitCanIndex(nIndex);
  pMsg=pDB->pGetCanMsgByIndex( nIndex, &sMsg);
  Ccanmsg oCanMsg( pMsg,nIndex);
  return oCanMsg;
}


Ccanmsg * Ccandev::poGetCanMsg( int nIndex)
{
  Ccanmsg *poCanMsg=0;
  nIndex=nWaitCanIndex(nIndex);
  if(nIndex>0){
    poCanMsg=pDB->poGetCanMsgByIndex( nIndex);
  }
  return poCanMsg;
}




int Ccandev::nProceed( void)
{
  int nSent=0;
  int nFlag=0;
  int nPolled=0;
  canmsg_t *pCanMsg;
  if(1>0){
    if(bDebug)
      printf("CANDEV_nProceed:Check if send messages\n");
    nSent= nMsgsInTxDBSend(3);
    if(nSent&&bVerbose){
      printf("CANDEV_nProceed:Sent %d messages\n",nSent);
    }
  }
  lLoop++;
  if(bDebug)
    printf("CANDEV_nProceed:Polling cnt:%ld\n",lLoop);
  //oLock.wait();
  //printf("B\n");
  /*
  nFlag = poCan->nStatusFlag();
  if(nFlag){
    printf("CANDEV:Can error:%d \n%s\n",nFlag,poCan->pStatusText(0xff));
  }
  */
  nPolled = 8;
  //printf("Pollbegin\n");
  pCanMsg=poCan->pPollMsgs(&nPolled);
  // printf("pollend\n");
  if(bDebug)
    printf("CANDEV_nProced:Polled:%d\t Total number of msgs:%d\n",nPolled, pDB->nGetFifoIndex()); 

  // oLock.post();
  if((nPolled>0) && pCanMsg){
    if(bDebug)
      printf("CANDEV_nProceed, inserting\n");
    for(int n=0;n<nPolled;n++){
      pCanMsg[n].flags=nFlag;
      int nIndex=nInsertRxMsg(&pCanMsg[n]);
      if(1>0){
	Ccanmsg oCanMsg(&pCanMsg[n],nIndex);
	if(bDebug)
	  printf( "%s\n",oCanMsg.pToText());
      }
    }
    nReleaseWaitLocks();
  }
  if(bVerbose || bDebug){
      printf("Flag:%d CAN232 %d\n",nFlag,nGetMaxMsgIndex());
  }
  return 1;
}


Ccanmsgdb * Ccandev::pGetDBPtr( void)
{
  Ccanmsgdb *p=0;
  if(bDebug)
    printf("\n\nGetDBptr enter\n");
  //oLock.wait();
  p=pDB;
  //oLock.post();
  if(bDebug)
    printf("\n\nGetDBptr %X\n",(int)p);
  return p;
}
