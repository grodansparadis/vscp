function can=can_init(host,port)
   h=java.lang.String(host);
   p=int32(port);
   can=CanClient
   can.init(h,port)

   
