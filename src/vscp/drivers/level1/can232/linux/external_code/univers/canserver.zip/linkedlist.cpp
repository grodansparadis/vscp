#include "linkedlist.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

Clinkedlist_node::Clinkedlist_node( void *pMsg, int nSize, Clinkedlist_node *pNext, Clinkedlist_node *pPrev)
{
  this->pNext = pNext;
  this->pPrev = pPrev;
  this->nSize = nSize;
  if(this->nSize){
    this->pMsg = new char[nSize];
    memcpy(this->pMsg,pMsg,nSize);
  }
  else
    this->pMsg=(char*)pMsg;
}

void * Clinkedlist_node::pFinalize( void *pMsg)
{
  if(pMsg){
    if(nSize)
      memcpy(pMsg,this->pMsg,this->nSize);
    else 
      pMsg=(void*)this->pMsg;
  }
  return pMsg;
}

Clinkedlist_node::~Clinkedlist_node()
{
  if(pMsg && nSize)
    delete pMsg;
}


/*
Clinkedlist::Clinkedlist()
{
  init(0,0);
}
*/
////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////



Clinkedlist::Clinkedlist(int nInMaxLength,int nDefaultSize)
{
  init(nDefaultSize,nInMaxLength);
}


void Clinkedlist::init(int nDefaultSize, int nInMaxLength)
{
  sem_init(&sLock,0,1);
  this->nMaxLength=nInMaxLength;
  this->nLength=0;
  this->nDefaultSize=nDefaultSize;
  this->pHead=0;
  this->pTail=0;
  this->pStepPtr=0;
}

Clinkedlist::Clinkedlist( void *psMsg,int nInMaxLength,int nDefaultSize)
{
  init(nDefaultSize,nInMaxLength);
  this->nInsertHead( psMsg, nDefaultSize);
}

Clinkedlist::~Clinkedlist()
{
  sem_wait(&sLock);
  while(nDeleteTail()!=0);
  sem_post(&sLock);
  sem_destroy(&sLock);
}

void *Clinkedlist::pGetNode( int n)
{
  sem_wait(&sLock);
  Clinkedlist_node *p=pHead;
  while(n>0 && p){
    n--;
    p = p->pNext;
  }
  sem_post(&sLock);  
  return (n==0) ? p:0;
}
 




int Clinkedlist::nInsertHead( void  *pMsg, int nSize )
{
  Clinkedlist_node *pElem = new Clinkedlist_node( pMsg, nSize ? nSize:this->nDefaultSize,pHead,0);
  if(nLength>0){
    pHead->pPrev = pElem;
    pHead = pElem;
  }
  else {
    pHead = pElem;
    pTail = pElem;
  }
  nLength++;
  if(nMaxLength && (nLength>nMaxLength))
    nDeleteTail();
  return nLength;
}


int Clinkedlist::nInsertTail(void *pMsg, int nSize)
{
  for (int n=0;n<100;n++){
    printf("LINKEDLIST:Inserttail not implemented\n");
    exit(-1);
  }
    //sleep(3);
  return nLength;
}

 
int Clinkedlist::nDeleteTail( bool bDeleteElements)
{
  char *p=(char*)pPopTail();
  if( bDeleteElements)
    delete p;
  return nLength;
}
 
int Clinkedlist::nDeleteHead( bool bDeleteElements)
{
  char *p=(char*)pPopHead();
  if( bDeleteElements)
    delete p;
  return nLength;
}
 
int Clinkedlist::nDeleteAtStepPtr( bool bDeleteElements)
{
  char *p=(char*)pPopAtStepPtr();
  if( bDeleteElements)
    delete p;
  return nLength;
}
 

void * Clinkedlist::pPopHead(void *pMsg)
{
  Clinkedlist_node *pElem=pHead;
  if(pHead){
    pHead =pHead->pNext;
    if(pHead)
      pHead->pPrev=0;
    nLength--;
  }
  if(pElem){
    pMsg = pElem->pFinalize(pMsg);
    delete pElem;
  }
  return pMsg;
}

/*
void Clinkedlist::oPopTail( void)
{
  
  //void oMsg(pPopTail);
}
*/

void * Clinkedlist::pPopTail(void *pMsg)
{
  Clinkedlist_node *pElem=pTail;
  if( nLength>0 && pMsg){
    pMsg = pElem->pFinalize(pMsg);
  }
  else
    pMsg=0;
  if(pTail==pHead){
    pTail=0;
    pHead =0;
    pStepPtr = 0;
    nLength=0;
  }
  else if(nLength>0){
    pTail = pTail->pPrev;
    pTail->pNext=0;
    nLength--;
  }
  delete pElem;
  return pMsg;
}

void * Clinkedlist::pPtrHead( void)
{
  return (void*)(pHead ? pHead->pMsg:0);
}


void * Clinkedlist::pPtrTail(void)
{
  return (void*)(pTail ? pTail->pMsg:0);
}

int Clinkedlist::nGetLength( void)
{
  return nLength;
}

void * Clinkedlist::pGetAtStepPtr(void)
{
  return (void*)(pStepPtr ? pStepPtr->pMsg:0);
}

void * Clinkedlist::pGetPtrAndStepNext(void)
{
  /*
  if(!pStepPtr && pHead){
    pStepPtr = pHead;
  }
  */
  void *p =(void*) (pStepPtr ? pStepPtr->pMsg:0);
  pStepPtrNext();
  return p;
}

void * Clinkedlist::pStepPtrNext( void)
{
  pStepPtr = pStepPtr ? pStepPtr->pNext:0;
  /*
    if(!pStepPtr && pHead){
    pStepPtr = pHead;
    }
  */
  return pStepPtr;
}


int Clinkedlist::nInsertAtStepPtr( void *pMsg,int nSize)
{
  if(pStepPtr==pHead){
    nInsertHead(pMsg,nSize);
  }
  else if(pStepPtr==pTail){
    nInsertTail(pMsg,nSize);
  }
  else {
    Clinkedlist_node *pElem = new Clinkedlist_node(pMsg,nSize,pStepPtr,pStepPtr->pPrev);
    pStepPtr->pPrev->pNext = pElem;
    pStepPtr->pNext->pPrev = pElem;
    nLength++;
  }
  return nLength;
}


void * Clinkedlist::pPopAtStepPtr( void *pMsg)
{
  if(pStepPtr==pHead)
    pMsg = pPopHead(pMsg);
  else if( pStepPtr==pTail)
    pMsg= pPopTail(pMsg);
  else if (pStepPtr!=0){
    Clinkedlist_node *pElem = pStepPtr;
    pMsg=pStepPtr->pFinalize(pMsg);
    pStepPtr->pPrev->pNext = pStepPtr->pNext;
    pStepPtr->pNext->pPrev = pStepPtr->pPrev;
    pStepPtr = pStepPtr->pNext;
    nLength--;
    delete pElem;
  }
  return pMsg;
}

void * Clinkedlist::pGetPtrAndStepPrev(void)
{
  /*
  if(!pStepPtr && pTail){
    pStepPtr = pTail;
  }
  */
  void *p =(void*)( pStepPtr ? pStepPtr->pMsg:0);
  pStepPtrPrev();
  return p;
}

void * Clinkedlist::pStepPtrPrev(void)
{
  return pStepPtr = pStepPtr ? pStepPtr->pPrev:0;
}


void * Clinkedlist::pStepPtrGotoHead(void)
{
  void *p =(void*)( pHead  ? pHead->pMsg:0);
  pStepPtr=pHead;
  return p;
}


void * Clinkedlist::pStepPtrGotoTail(void)
{
  void *p =(void*)( pTail  ? pHead->pMsg:0);
  pStepPtr=pTail;
  return p;
}
  
