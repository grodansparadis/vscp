#include <stdio.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <sys/time.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <asm/io.h>
#include <stdlib.h>
#include <string.h>
#include "master.h"
#include "emptytask.h"

struct MASTER_STR sMaster;

int z_hextoi( char c)
{
  c=toupper(c);
  return (c>='A') ? (c-'A'+10):(c-'0');
}

int z_tohex(int n)
{
  n &=0x0f;
  return ((n<10) ? ('0'+n):('A'+n-10));
}

long z_lHexToLong( char *p)
{
  bool bNeg=0;
  long l=0;
  if(p){
    while(*p && *p=='-'){
      bNeg = !bNeg;
      p++;
    }
    while(*p){
      l<<=4;
      if(isxdigit(*p))
	l+=z_hextoi(*p);
      else 
	break;
      p++;
    }
  }
  return l;
}



char *pIntToHex(char *p, unsigned int n,int nMaxNib)
{
  static char ac[10];
  //  printf("Integer to hex\n");
  p= p ? p:&ac[0];
  if(n>255){
    int nIndex=0;
    for(int nNib=0;nNib<nMaxNib;nNib++){
      int nTmp;
      nTmp =n>>(4*(nMaxNib-1-nNib));
      p[nIndex]=z_tohex(nTmp);
      if(p[0]!='0')
        nIndex++;
      p[nIndex]=0x00;
    }
  }
  else if(n>15){
    p[0]=z_tohex(n>>4);
    p[1]=z_tohex(n);
    p[2]=0x00;
  }
  else {
    p[0]=z_tohex(n);
    p[1]=0x00;
  }
  return p;
}

char *pIntToDec(char *p, unsigned int n,unsigned int nDecTal)
{
  static char ac[12];
  p= p ? p:&ac[0];
  sprintf(p,"%d",n);
  //printf("pIntToDec:%d %s\n",n,p);
  return p;
  p[0]=0;
  if(n>=10000){
    printf("Integer to dec\n");
    sleep(1);
    for(int nIndex=0;nDecTal>0;nDecTal /=10){
      int nTmp;
      nTmp = n/nDecTal;
      n -=nTmp*nDecTal;
      p[nIndex]=(nTmp&0x0f)+'0';
      if(p[0]!='0')
	nIndex++;
      p[nIndex]=0x00;			 
    }
    printf("MASTER:Integer to dec,exit\n");
  }
  else if(n>=1000){
    unsigned int nTmp;
    nTmp = n/1000;
    n -=nTmp*1000;
    p[0]=(char)nTmp+'0';

    nTmp = n/100;
    n -=nTmp*100;
    p[1]=(char)nTmp+'0';

    nTmp = n/10;
    n -=nTmp*10;
    p[2]=(char)nTmp+'0';


    p[3]=(char)n+'0';
    p[4]=0;
  }
  else if(n>=100){
    unsigned int nTmp;
    nTmp = n/100;
    n -=nTmp*100;
    p[0]=(char)nTmp+'0';

    nTmp = n/10;
    n -=nTmp*10;
    p[1]=(char)nTmp+'0';


    p[2]=(char)n+'0';
    p[3]=0;
  }
  else if(n>=10){
    unsigned int nTmp;
    nTmp = n/10;
    n -=nTmp*10;
    p[0]=(char)nTmp+'0';


    p[1]=(char)n+'0';
    p[2]=0;
  }
  else {
    p[0]=(char)n+'0';
    p[1]=0x00;
  }
  printf("Dec:%s=%d\n",p,n);
  return p;
}


double rGetStartTime( void)
{
  return (double) sMaster.lStartSec;
}


Cemptytask::Cemptytask( struct EMPTY_TASK_STR *psTask)
{
  this->psTask = psTask ? psTask:new struct EMPTY_TASK_STR;
  Init( this->psTask);
}

Cemptytask::~Cemptytask(void)
{
  if (psTask)
    delete psTask;
}

struct EMPTY_TASK_STR * Cemptytask::psGetTaskStrPtr( void)
{
  return this->psTask;
} 


void Cemptytask::Init( struct EMPTY_TASK_STR *pTask)
{
  static int nNr=0;
  Ctime oTime;
  pTask = (pTask!=0) ? pTask:this->psTask;
  if ( pTask){
    pTask->nMode=TASK_PERIODIC_MODE;
    pTask->nNr = nNr++;
    pTask->rFreq=1.0;
    pTask->rSleep=1000.0;
    pTask->nPriority=10;
    pTask->nStackSize=2048;
    pTask->nMessageSize=4096;
    pTask->nSchedPriority=99;
    pTask->pBinaryName=NULL;
    strcpy(pTask->acName,"");
    pTask->acName[6]=0;
    pTask->nVerbose=0;
    pTask->nDebug=0;
    pTask->pMe=0;
    pTask->pMaster=0;
    pTask->ulMaster=666; //nam2num("MASTER");
    pTask->unQuitSem=0;
    strcpy(pTask->acMyIpcName,"");
    pTask->pidMyIpc = 0;
    strcpy(pTask->acProxyName,"");
    pTask->pidProxy=0;
    pTask->nProxyPrio=0;
    pTask->nProxyBuffLen=0;
    pTask->pProxyBuff=0;
    pTask->nProceed = 0;
    pTask->nInitCodeInRealTime =0;
    pTask->nCleanupCodeInRealTime =0;
    pTask->nSleepBeforeTerm = 5;
    pTask->nLogSocket =0;
    pTask->pLogFileName = "";
    pTask->nTwinThreadNr=0;
    {
      for (int i=0;i<MAXARGS;i++){
	pTask->pExtraArg[i]=0;
      }
    } 
    pTask->bStartTask =1;
    pTask->nThreads=0;
    pTask->nExtraArgs=0;
    pTask->rLastTime = oTime.rToSec();
    // pTask->poClient = 0;
  }
}



int Cemptytask::nProceed( struct EMPTY_TASK_STR *pTask)
{ 
  double r;
  Ctime oTime;
  
  pTask = pTask ? pTask:this->psTask;

  pTask->ulEpoch++;
  if ( pTask->nVerbose && pTask->nDebug){
    //      printf("%s:Epoch:%ld\n",pTask->acName,pTask->ulEpoch);
  }
  switch( pTask->nMode)
    {
    case TASK_PERIODIC_MODE:
      r=pTask->rLastTime+1.0/pTask->rFreq;
      pTask->rLastTime=oTime.rToSec();
      r -=pTask->rLastTime;
      if ( r>0.0){
	usleep((unsigned int)( r*1000000.0));
      }
      break;
      
      
    case TASK_SLEEP_MODE:
      r=pTask->rLastTime+pTask->rSleep;
      pTask->rLastTime=oTime.rToSec();
      r -=pTask->rLastTime;
      if ( r>0.0){
	usleep((unsigned int)( r*1000000.0));
      }
      break;
      
    case TASK_YIELD_MODE:
      //	rt_task_yield();
      break;
      
    case TASK_SUSPEND_MODE:
      //	rt_task_suspend(pTask->pMe);
      break;
      
    case TASK_FREE_RUNNING_MODE:
      break;
    }
  {
    
#ifdef ZCLIENT_USE_SEM_TO_TERM
    if ( pTask->pQuitSem){
      if (rt_sem_wait_if(pTask->pQuitSem)){
	if ( pTask->nDebug)
	  printf("%s:Terminated by semaphore\n",pTask->acName);
	bLoop=0;
      }
    }
#endif
  }
  return 1;
}

int task_proceed( struct EMPTY_TASK_STR *pTask)
{ 
  double r;
  Ctime oTime;
  
  pTask->ulEpoch++;
  if ( pTask->nVerbose && pTask->nDebug){
    //      printf("%s:Epoch:%ld\n",pTask->acName,pTask->ulEpoch);
  }
  switch( pTask->nMode)
    {
    case TASK_PERIODIC_MODE:
      r=pTask->rLastTime+1.0/pTask->rFreq;
      pTask->rLastTime=oTime.rToSec();
      r -=pTask->rLastTime;
      if ( r>0.0){
	usleep((unsigned int)( r*1000000.0));
      }
      break;
      
      
    case TASK_SLEEP_MODE:
      r=pTask->rLastTime+pTask->rSleep;
      pTask->rLastTime=oTime.rToSec();
      r -=pTask->rLastTime;
      if ( r>0.0){
	usleep((unsigned int)( r*1000000.0));
      }
      break;
      
    case TASK_YIELD_MODE:
      //	rt_task_yield();
      break;
      
    case TASK_SUSPEND_MODE:
      //	rt_task_suspend(pTask->pMe);
      break;
      
    case TASK_FREE_RUNNING_MODE:
      break;
    }
  {
    
#ifdef ZCLIENT_USE_SEM_TO_TERM
    if ( pTask->pQuitSem){
      if (rt_sem_wait_if(pTask->pQuitSem)){
	if ( pTask->nDebug)
	  printf("%s:Terminated by semaphore\n",pTask->acName);
	bLoop=0;
      }
    }
#endif
  }
  return 1;
}












