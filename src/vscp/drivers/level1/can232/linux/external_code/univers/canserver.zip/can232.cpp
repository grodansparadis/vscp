#include "can232.h"
#include <ctype.h>
#include <string.h>

int Ccan232::hextoi( char c)
{
  c=toupper(c);
  return (c>='A') ? (c-'A'+10):(c-'0');
}

char Ccan232::tohex(int n)
{
  n &=0x0f;
  return ((n<10) ? ('0'+n):('A'+n-10));
}

bool Ccan232::bIsHex( char c)
{
  c = toupper(c);
  return ((c>='0' && c<='9')||(c>='A' && c<='F'));
}

Ccan232::Ccan232(int nPort, int nCanRate)
{
  bInit(nPort,115200,nCanRate);
}

Ccan232::Ccan232(int nPort, int nBaudRate, int nCanRate)
{
  bInit(nPort,nBaudRate,nCanRate);
}

void Ccan232::MarkErrors( int nFlag)
{
  for(int n=0;n<8;n++){
    if(nFlag&1)
      nErrorAtBit[n]++;
    nFlag>>=1;
  }
}


char * Ccan232::pGetStatusText( char *p)
{
  if(!p){
    pStatusText = new char[2000];
    p = pStatusText;
  }
  char *pBegin =p;
  sprintf(p,"CAN232 STATUS, compiled %s\n-------------------------\n",__DATE__);
  for(;*p;p++);
  sprintf(p,"CAN232 STATUS, compiled %s\n",__DATE__);
  for(;*p;p++);
  sprintf(p,"POLLED_MESSAGES %ld\n",lPolledMsgCnt);
  for(;*p;p++);
  sprintf(p,"SENT_MESSAGES   %ld\n",lSendCnt);
  for(;*p;p++);
  sprintf(p,"TOTAL_ERRORS    %ld\n",lErrorCnt);
  for(;*p;p++);
  sprintf(p,"FORMAT_ERRORS   %ld\n",lFormatError);
  for(;*p;p++);
  sprintf(p,"POLL_ERRORS     %ld\n",lErrorNoPoll);
  for(;*p;p++);
  sprintf(p,"POLL_ERRORS     %ld\n",lErrorNoPoll);
  for(;*p;p++);
  sprintf(p,"SYNC_ERRORS     %d\n",nSyncErrorCnt);
  for(;*p;p++);
  return pBegin;
};


bool Ccan232::bInit(int nPort, int nBaudRate,int nCanRate)
{
  bool bReturn = true;
  
  pStatusText =0;

  bDebug = false;
  bVerbose = false;
  if(-1>1){
    bDebug = true;
    bVerbose = true;
  }
  poSem = new Csemaphore(1,bDebug);
  if(bDebug)
    printf("CAN232_bInit:Enter\n");
  
  sPollCcanmsgStr.nPolled=0;
  bWorking =1;

  lSession=0;
  lPollCnt=0;
  lPolledMsgCnt=0;
  lSendCnt=0;

  nSyncErrorCnt=0;

  nPolled =0;
  acStatus[0]=0;

  lSendRawCnt=0;
  lErrorCnt=0;
  lErrorNoPoll=0;
  lFormatError=0;
  ucStatusFlag=0;

  /*
  for(int n=0;n<8;n++)
    nErrorAtBit[n]=0;
  */

  //pCom = new Csercom("can232.log",nPort,57600*2);
  pCom = new Csercom(nPort,nBaudRate);
  if(pCom){
    //bClose();
    
    pCom->NonBlockingMode();
    nReadAndClearBuffer();
    bSyncCan232();
    nReadAndClearBuffer();
    pCom->BlockingMode();
    
    int result = 1;
    while(1){
    	result = bClose();
    	if (result)
	   result = bSetup(nCanRate);
	if (!result)
	   printf("Problem initiating Canbus, connect the cable!\n");
    	else
	   break;
	sleep(500);   	
    }
    bReturn = result ; // bUart(9600);
    if(bVerbose)
      printf("Can232 initied\n");
  }
  else {
    printf("CAN232:Unable to open serialport, Set serialports first!\n");
    bReturn = 0;
  }
  if(bDebug)
    printf("CAN232_bInit:Exit\n");
  bInitOk = bReturn;
  return bReturn;
}

bool Ccan232::bGetIfInitOk( void)
{
  return bInitOk && bWorking;
}


bool Ccan232::bGetIsOpen( void)
{
  return bIsOpen;
}

Ccanmsg ** Ccan232::paoPollCanMsgsObjs( int *pnPolled, Ccanmsg **poMsgs)
{
  int nPolled=20;
  canmsg_t *psCanMsg = new canmsg_t[nPolled]; 
  canmsg_t *p=pPollMsgs(&nPolled, psCanMsg);
  if ( p && nPolled){
    if(!poMsgs){
      poMsgs = &sPollCcanmsgStr.poa[0];
      for (int n=0;n<sPollCcanmsgStr.nPolled;n++){
	if(sPollCcanmsgStr.poa[n]){
	  delete sPollCcanmsgStr.poa[n];
	  sPollCcanmsgStr.poa[n]=0;
	}
      }
    }
    for (int n=0;n<sPollCcanmsgStr.nPolled;n++){
      sPollCcanmsgStr.poa[n] = new Ccanmsg(&p[n]);
    }
  }
  if( psCanMsg)
    delete psCanMsg;
  return nPolled ? poMsgs:0;
}

canmsg_t *Ccan232::pPollMsgs( int *pnPolled, canmsg_t *pMsgs)
{
  bool bError=false;
  char *p=pPollAll();
  char *pBegin=p;
  nPolled=0;
  if(bDebug)
    printf("CAN232_pPollMsgs:pPollAll=%s\n",p);
  if(!p){
    lErrorCnt++;
    lErrorNoPoll++;
    printf("CAN232_pPollMsgs:Unable to poll canmsgs, No of empty poll errors=%ld\n",lErrorNoPoll);
  }
  else {
    int nMaxPoll=CAN232_POLLALL_FIFO_SIZE;
    if(!pMsgs)
      pMsgs = &sPollAllCanMsg[0];
    else {
      if(pnPolled && (*pnPolled>0))
	nMaxPoll = *pnPolled;
    }
    nPolled =0;
    int nLoop =0;
    while(nLoop < 100){
      if(bDebug)
	printf("CAN232:PollMsgs loop:%d\n",nLoop);
      switch(nLoop)
	{
	case 0:
	  nLoop =5;
	  if ((*p==0) || (nPolled>=nMaxPoll))
	    nLoop = 90;
	  else if ((*p=='A') && (p[1]==0x00))
	    nLoop = 90;
	  break;
	  
	  
	case 5:
	  pMsgs[nPolled].cob=0;
	  pMsgs[nPolled].flags=ucStatusFlag;
	  gettimeofday(&pMsgs[nPolled].timestamp,NULL);
	  pMsgs[nPolled].id=0;
	  pMsgs[nPolled].length=0;
	  nLoop=6;
	  break;
	  
	case 6:
	  for (int n=strlen(p);n;n--){
	    if((p[n-1]==0x0d) || (p[n-1]==0x0a))
	      p[n-1]=0x00;
	    else {
	      if(p[n-1]=='T'){
		printf("CAN232:Terminating 'T' found, replacing with 'A'");
		p[n-1]='A';
	      }
	      break;
	    }
	  }
	  nLoop = 10;
	  break;

	case 10:
	  if(bDebug)
	    printf("CAN232:pPollMsgs %s\n",p);
	  if((*p=='T') && (strlen(p)>=1+8+1)){
	    p++;
	    nLoop =15;
	  }
	  else {
	    nLoop = 50;
	  }
	  break;
	  
	case 15:
	  nLoop = 20;
	  for(int n=0;n<8;n++){
	    if(bIsHex(*p)){
	      pMsgs[nPolled].id <<=4;
	      pMsgs[nPolled].id +=hextoi(*(p++));
	    }
	    else {
	      nLoop=50;
	      break;
	    }
	  }
	  break;
	  
	case 20:
	  if(bIsHex(p[0])){
	    pMsgs[nPolled].length=hextoi(*(p++));
	    nLoop = 22;
	  }
	  else 
	    nLoop = 50;
	  break;
	  
	case 22:
	  nLoop = 25;
	  if((pMsgs[nPolled].length==0) && (*p>='0' && *p<='8'))
	    pMsgs[nPolled].length=hextoi(*(p++));
	  break;
	  
	case 23:
	  nLoop =25;
	  if((pMsgs[nPolled].length==0) && ((p[1]!='T') && (p[1]!='A'))){
	    int n=hextoi(*(p++));
	    pMsgs[nPolled].length=n;
	  }
	  break;

	case 25:
	  if(bDebug && (pMsgs[nPolled].length>8)){
	    nLoop = 50;
	  }
	  else {
	    nLoop = 30;
	  }
	  break;
	  
	case 30:
	  nLoop = 35;
	  for(int n=0;n<pMsgs[nPolled].length;n++){
	    if(bIsHex(p[0]) && bIsHex(p[1])){
	      pMsgs[nPolled].data[n]=(hextoi(p[0])<<4)+hextoi(p[1]);
	      p+=2;
	    }
	    else {
	      nLoop = 50;
	      break;
	    }
	  }
	  break;
	  
	case 35:
	  nLoop = 40;
	  if(*p=='A'){
	    //	    printf("termin\n");
	    if(strlen(p)>1){
	      bError = true;
	      lFormatError++;
	      nLoop = 50;
	      printf("CAN232:Format error, terminating with A, still found %s\n",&p[1]);
	    }
	  }
	  else if (*p!='T'){
	    nLoop = 50;
	  }
	  break;
	  
	  
	case 40:
	  nLoop = 0;
	  nPolled++;
	  if(nPolled>=nMaxPoll){
	    bError = true;
	    printf("CAN232:FIFO out of size nPolled=%d\n",nPolled);
	    nLoop = 90;
	  }
	  break;
	  
	case 50:
	  nLoop = 55;
	  bError = true;
	  lErrorCnt++;
	  if(*p)
	    lFormatError++;
	  if( bVerbose||1){
	    int nOffset = p-pBegin;
	    printf("CAN232:Format error at %d,%s, syncing %s, data length=%d, max 8\n",nOffset,pBegin, p,pMsgs[nPolled].length);
	    int i=0;
	    for (char *p0=pBegin;*p0;p0++){
	      putchar(*p0);
	      if(!nOffset--){
		//printf("*");
	      }
	      if(p0[1]=='T' || p0[1]==0){
		printf("\t\t%d) id=%.9X  len=%d  data=",i,(int)pMsgs[i].id,pMsgs[i].length);
		for (int n=0;n<pMsgs[i].length;n++){
		  printf("%.2X ",pMsgs[i].data[n]);
		}
		printf("\n");
		i++;
		if(nOffset<=0){
		  break;
		}
	      }
	    }
	  }
	  break;
	  
	case 55:
	  nLoop = 0;
	  while(*p && (*p!='T')){
	    p++;
	    printf("+");
	  }
	  if(*p==0){
	    printf("CAN232:Pollall error, polled %d, pollstr=%s\n", nPolled, pBegin);
	    nLoop=90;
	  }
	  break;
	  
	  
	case 90:
	  if((nPolled==0)&&(strlen(pBegin)>1)){
	    printf("CAN232:Format error %s, dropout=%s\n",pBegin,p);
	  }
	  if(bDebug || bError)
	    printf("CAN232:Polled %d from %s\n",nPolled,pBegin);
	  lPolledMsgCnt +=nPolled;
	  nLoop=100;
	  break; 

	default:
	  printf("CAN232:Error unknown state in decode loop, aborting. nLoop=%d\n",nLoop);
	  nLoop = 90;
	  break;
	}
    }
  }
  if(pnPolled){
    *pnPolled = nPolled;
  }
  return nPolled ? pMsgs:0;
}


char * Ccan232::pPoll( char *p)
{
  int nLen=0;
  poSem->wait();
  lSession++;
  lPollCnt++;
  if ( bIsOpen){
    char acHead[]={'T',7,0};
    if (!p)
      p=&acPoll[0];
    //printf("Poll\n");
    if(nCmdWaitHead(p,'P',(char*)&acHead[0],1000)){
      nLen=1+pCom->nReadLine(&p[1],59);
      if(bDebug)
	printf("CAN232_poll:length:%d\n",nLen);
      p[nLen]=0;
    }
    else if(p[0]==0x07){
      p=0;
      lErrorCnt++;
    }
  }
  else {
    lErrorCnt++;
    p=0;
  }
  poSem->post();
  return p;
}

char * Ccan232::pPollAll( char *p, int nMaxLen)
{
  char acHead[]={'T','A',7,0};
  
  if(bDebug){
    printf("CAN232:pPollAll Enter\n");
  }
  poSem->wait();
  lSession++;
  lPollCnt++;
  if (!p){
    p=&acPollAll[0];
    nMaxLen = SIZE_POLLALLBUFFER;
  }
  if(1>0){
    for (int n=0;n<nMaxLen-1;n++){
      p[n]='Q';
      p[n+1]=0x00;
    }
  }
  int nHead = nCmdWaitHead(p,'A',(char*)&acHead[0],nMaxLen);
  switch(nHead)
    {
    case 'T':
      {
	int nRead;
	int nLen=1;
	do {
	  nRead=pCom->nReadLine(&p[nLen],nMaxLen-nLen-1);
	  if(nRead>0){
	    p[nLen+nRead]=0x00;
	    if(bDebug)
	      printf("CAN232:polled:%d %s, Buffer Length=%d\n",nRead,&p[nLen], nLen);
	    //printf("PollAll loop:%d %s\n",nLen,&p[nLen]);
	    nLen +=nRead;
	  }
	} while((nRead>2) && (nLen<(nMaxLen-40)));
	if ( nLen<=2){
	  p = 0;
	  lErrorCnt++;
	  if(bDebug)
	    printf("Poll error %ld, Polled str:%s\n",lErrorCnt,p);
	}
	else {
	  lPollCnt++;
	  //printf("Polled:%s\n",p);
	  //sleep(1);
	}
      }
      break;
    
    case 0x07:
      p=0;
      if(bVerbose)
	printf("CAN232 not opened\n");
      lErrorCnt++;
      break;
      
    case 'A':
      //p=0;
      if(bVerbose)
	printf("CAN232_POLLALL:Nothing to poll, %s\n",p);
      break;
      
    default:
      p=0;
      lErrorCnt++;
      printf("CAN232_POLLALL:Unknown return nHead=%d, Errors=%ld\n",nHead, lErrorCnt); 
      break;
      
    }
  poSem->post();
  if(bDebug){
    printf("CAN232:pPollAll Exit\n");
  }
  return p;
}

int Ccan232::nReadAndClearBuffer( char *p)
{
  if(!p)
    p=&acReadAndClear[0];
  *p=0;
  int nRead=pCom->nRead(p,100);
  if(nRead>0){
    // printf("%d:%s\n",nRead,p);
  }
  return nRead;
}


bool Ccan232::bSyncCan232( void)
{
  char ac[50];
  int n;
  do {
    pCom->bSendChar(0x0d);
    n = pCom->nReadLine(&ac[0],50);
    if(n>1)
      puts(ac);
  } while (n>1);
  return 1;
}


bool Ccan232::bNrCR( int n)
{
  while ((n--)>0){
    lSession++;
    pCom->bSendChar(0x0d);
  }
  return 1;
}

int Ccan232::nCmdWaitHead(char *p,char cCmd,char *pHead, int nWaitMicroSeconds)
{
  char acCmd[2]={cCmd,0};
  return nCmdWaitHead(p,&acCmd[0],pHead,nWaitMicroSeconds);
}

int Ccan232::nCmdWaitHead(char *p,char *pCmd,char *pHead, int nWaitMicroSeconds)
{
  char *pFound=0;
  int nHead=-1;
  static char acHead[2];
  p = p ? p:&acHead[0];
  p[0]=0x00;
  p[1]=0x00;
  //  printf("enter\n");
  if(bDebug)
    printf("CAN232:Find head %s %s len:%d\n",pCmd,pHead,strlen(pHead));
  pCom->NonBlockingMode();
  for (int nTry=0;(nTry<8) && !pFound;nTry++){
    if(bDebug){
      printf("$");
      fflush(stdout);
    }
    nReadAndClearBuffer();
    pCom->nPutLine(pCmd);
    usleep( nWaitMicroSeconds ? nWaitMicroSeconds:1);
    for (int n=0;(n<30) && (!pFound);n++){
      nHead = pCom->nReadChar();
      if(nHead>0){
	//printf("|%d:%s:%d|\t",n,pCmd,nHead);
	if (p)
	  p[0] =(char) nHead;
	if((nHead<0)||(pFound=strchr(pHead,nHead)))
	  break;
	if(p){
	  //printf("+<%d:%c>",nHead,(char)*p);
	  //fflush(stdout);
	}
      }
    };
    if(nTry>0){
     nSyncErrorCnt++;
     if(bDebug)
       printf("<try %d>",nTry);
    }
  }
  pCom->BlockingMode();
  if(nHead<0){
  }
  if(bDebug){
    printf("Waitheadexit with:%d\n",nHead);
    fflush(stdout);
  }
  return nHead;
}


char *Ccan232::pStatusFlagText(int nShow)
{
  acStatus[0]=0x00;
  if ( nShow){
    int nStatus = ucStatusFlag;
    char *p=&acStatus[0];
    *p=0x00;
    if ((nStatus&nShow)&1){
      sprintf(p,"CAN receive FIFO queue full %d times\n",nErrorAtBit[0]);
    }
    if ((nStatus&nShow)&2){
      p=&p[strlen(p)];
      sprintf(p,"CAN transmit FIFO queue full %d times\n",nErrorAtBit[1]);
    }
    if ((nStatus&nShow)&4){
      p=&p[strlen(p)];
      sprintf(p,"Error warning (EI) %d times\n",nErrorAtBit[2]);
    }
    if ((nStatus&nShow)&8){
      p=&p[strlen(p)];
      sprintf(p,"Data overrun (DOI) %d times\n",nErrorAtBit[3]);
    }
    if ((nStatus&nShow)&16){
      p=&p[strlen(p)];
      sprintf(p,"Not open %d times\n",nErrorAtBit[4]);
    }
    if ((nStatus&nShow)&32){
      p=&p[strlen(p)];
      sprintf(p,"Error passive (EPI) %d times\n",nErrorAtBit[5]);
    }
    if ((nStatus&nShow)&64){
      p=&p[strlen(p)];
      sprintf(p,"Arbitration Lost (ALI) %d times\n",nErrorAtBit[6]);
    }
    if ((nStatus&nShow)&128){
      p=&p[strlen(p)];
      sprintf(p,"Bus error (BEI) %d times\n",nErrorAtBit[7]);
    }
    if(nShow&0x256){
      printf("CAN232:%s\n",acStatus);
    }
  }
  return &acStatus[0];
}

bool Ccan232::bSetCode( int nCode)
{
  if(bDebug){
    printf("CAN232:SetCode Enter\n");
  }
  poSem->wait();
  bool bOk=false;
  if(nCode>0){
    lSession++;
    pCom->bSendChar('M');
    for (int n=0;n<8;n++){
      char c;
      c=tohex(nCode>>((7-n)*4)&0x0F);
      pCom->bSendChar(c);
    }
    pCom->bSendChar(0x0d);
    bOk=pCom->nRead()==0x0d;
    //  pCom->bSendChar(0x0d);
    if(!bOk)
      lErrorCnt++;
  }
  poSem->post();
  if(bDebug){
    printf("CAN232:SetCode Exit\n");
  }
  return bOk;
}

bool Ccan232::bSetMask( int nMask)
{
  bool bOk=false;
  if(bDebug){
    printf("CAN232:SetMask Enter\n");
  }
  poSem->wait();
  if(nMask>0){
    lSession++;
    pCom->bSendChar('m');
    //printf("Mask:");
    for (int n=0;n<8;n++){
      char c=tohex(nMask>>((7-n)*4)&0x0F);
      pCom->bSendChar(c);
      //printf("%c",c);
      
    }
    //printf("\n");
    pCom->bSendChar(0x0d);
    bOk=pCom->nRead()==0x0d;
    //  pCom->bSendChar(0x0d);
    if(!bOk)
      lErrorCnt++;
  }
  poSem->post();
  if(bDebug){
    printf("CAN232:SetMask Exit\n");
  }
  return bOk;
}

int Ccan232::nVersion( void)
{
  char ac[11];
  char acHead[5]={'V',7,0};
  int nVer=0;
  if(bDebug){
    printf("CAN232:nVersion Enter\n");
  }
  poSem->wait();
  lSession++;
  if(nCmdWaitHead(&ac[0],'V',(char*)&acHead[0])){
    pCom->nReadLine(&ac[1],10);
    nVer =  atoi(&ac[1]);
    nVer =((nVer>0) && ((nVer%100)==13)) ? (nVer/100):0;
    if(!nVer)
      lErrorCnt++;
    //printf("VERSION RESPONSE:%s\n",ac);
  }
  else
    lErrorCnt++;
  poSem->post();
  if(bDebug){
    printf("CAN232:nVersion Exit\n");
  }
  return nVer;
}


int Ccan232::bSetup( int nRate)
{
  int nRates[]={10000,20000,50000,100000,125000,
		      250000,500000,800000,1000000,0};
  int n;
  bool bOk=false;
  
  lSession++;
  //if (bIsOpen)
  //  bClose();
  if(bDebug){
    printf("CAN232:Setup Enter\n");
  }
  poSem->wait();
  for (n=0;nRates[n] && nRate!=nRates[n];n++);
  if (!nRates[n])
    n=6;
  {
    char acHead[5]={0x0d,0x07,0x00};
    char acCmd[5]={'S','0'+n,0x00};
    int nHead = nCmdWaitHead(0,&acCmd[0],&acHead[0]);
    switch(nHead)
      {
      case 0x0d:
	bOk=1;
	//printf("CAN232_Setup:Canrate set to:%d\n",nRates[n]);
	break;

      case 0x07:
	//printf("CAN232_Setup:Error in setting canreate\n");
	break;
 
      default:
	bWorking = 0;
	//printf("CAN232_Setup:Unknown command setting canreate, head=%d\n",nHead);
	break;
      }
  }
  if (!bOk)
    lErrorCnt++;
  poSem->post();
  if(bDebug){
    printf("CAN232:Setup Exit\n");
  }
  return bOk;
}

bool Ccan232::bOpen( void)
{
  char acHead[]={7,10,13,0};
  if(bDebug){
    printf("CAN232:Open Enter\n");
  }
  bClose();
  poSem->wait();
  bIsOpen = 0;
  if(0){
    pCom->NonBlockingMode();
    nReadAndClearBuffer();
    pCom->BlockingMode();
  }
  lSession++;
  if(bDebug)
    printf("CAN232_bOpen:Enter\n");
  for ( int n=10;(n>0) && (!bIsOpen);n--){
    int nHead = nCmdWaitHead(0,'O',(char*)&acHead[0]);
    switch(nHead)
      {
      case 0x0d:
	bIsOpen=1;
	break;

      case 0x07:
	if(bDebug)
	  printf("Can232 already open, got head=0x07\n");
	bIsOpen=1;
	break;
  
      default:
	bWorking =0;
	printf("CAN232_bOpen:Unknown header return=%d\n",nHead);
	lErrorCnt++;
	break;

    }
  }
  if(bVerbose)
    printf("Can232_bOpen:isopen:%d\n",(int)bIsOpen);
  poSem->post();
  if(bDebug){
    printf("CAN232:Open exit\n");
  }
  return bIsOpen;
}

bool Ccan232::bClose( void)
{
  char acHead[]={7,10,13,0};
  int nHead;
  if(bDebug){
    printf("CAN232:Close Enter\n");
  }
  poSem->wait();
  lSession++;
  if(bVerbose)
     printf("CAN232_bClose:Enter\n");
  nHead=nCmdWaitHead(0,'C',(char*)&acHead[0]);
  switch(nHead)
    {
    case 0x0d:
      // printf("can232 Closed OK\n");
      break;

    case 0x07:
      //printf("Can232 already closed\n");
      lErrorCnt++;
      break;

    default:
      bWorking =0;
      //printf("CAN232_bClose:Unknown head==%d\n",nHead);
      break;
    }
  poSem->post();
  if(bDebug){
    printf("CAN232:Close Exit\n");
  }
  return nHead==0x0d;
}

int Ccan232::nStatusFlag( int nShow)
{
  int nHead, nStatus;
  char acHead[]={'F',7,0};
  if(bDebug)
    printf("CAN232:Flag Enter\n");
  poSem->wait();
  lSession++;
  nStatus=0x10;
  //  printf("Status flag\n");
  nHead=nCmdWaitHead(&acFlag[0],'F',(char*)acHead,500);
  switch(nHead)
    {
    case 'F':
      {
	int nLen;
	nLen=1+pCom->nReadLine(&acFlag[1],8);
	if ( nLen>2){
	  nStatus= (hextoi(acFlag[1])*16+hextoi(acFlag[2]));
	}
      }
      break;

    case 0x07:
      printf("Error in flag, got head %d\n",nHead);
      lErrorCnt++;
      break;

    default:
      bWorking =0;
      printf("CAN232_nStatusFlag:Error unknown head=%d\n",nHead);
      break;
  }
  ucStatusFlag=(unsigned char) nStatus;
  MarkErrors(nStatus);
  //printf("FLAG END\n");
  if ( ucStatusFlag)
    lErrorCnt++;
  poSem->post();
  if(bDebug)
    printf("CAN232:Flag Exit\n");
  return nStatus;
}


unsigned char Ccan232::ucGetStoredStatus( void)
{
  return ucStatusFlag;
}


bool Ccan232::bUart( int nBaud)
{
  int nBauds[]={230400,115200,57600,38400,19200,9600,2400,0};
  if(bDebug)
    printf("CAN232:UART Enter\n");
  poSem->wait();
  lSession++;
  int n=0;
  for (n=0;nBauds[n] && nBaud!=nBauds[n];n++);
  pCom->bSendChar('U');
  pCom->bSendChar('0'+(!nBauds[n] ? 2:n));
  pCom->bSendChar(0x0d);
  bool bOk = pCom->nRead()==0x0d;
  if(!bOk)
    lErrorCnt++;
  poSem->post();
  if(bDebug)
    printf("CAN232:UART Exit\n");
  return bOk;
}

bool Ccan232::bSendLine( char *pCmd)
{
  bool bOk=0;
  char acHead[]={7,10,13,0};
  poSem->wait();
  lSession++;
  if(pCmd){
    bOk=nCmdWaitHead(0,pCmd,(char*)&acHead[0],200);
    if(!bOk)
      lErrorCnt++;
  }
  poSem->post();
  return bOk;
}






bool Ccan232::bSend11( int id,int nLen,unsigned char *p)
{
  bool bOk=0;
  poSem->wait();
  if(p && (nLen>=0)){
    char acHead[]={7,10,13,0};
    char ac[30];
    lSession++;
    lSendCnt++;
    nLen = (nLen < 8) ? nLen:8;
    ac[0]='t';
    ac[1]=tohex((id>>8)&0x07);
    ac[2]=tohex((id>>4)&0x0F);    // id = 0-0x7ff
    ac[3]=tohex(id&0x0F);
    ac[4]=tohex(nLen);
    {
      int k=5;
      for (int n=0;n<nLen;n++){
	ac[k]=tohex(p[n]>>4);
	ac[k+1]=tohex(p[n]&0x0F);
	k +=2;
      }
      ac[k]=0;
    }
    int nHead=nCmdWaitHead(0,&ac[0],(char*)&acHead[0],100);
    bOk = (nHead == 0x0d);
    if(bVerbose){
      printf("CAN232:bSend11 %s, received <%d> %s\n",ac,nHead,bOk?"OK":"FALSE");
    }
    if(!bOk)
      lErrorCnt++;
    else 
      lSendCnt++;
  }
  poSem->post();
  return bOk;
}

bool Ccan232::bSend( int nId,int nLen,unsigned char *pData)
{
  return bSend29( nId, nLen, pData);
}

bool Ccan232::bSend( canmsg_t *psCan, int nNumbers)
{
  bool bRet=false;
  for (int n=0;psCan && (n<nNumbers);n++){
    bRet = bSendCanMsg( &psCan[n]);
    if(!bRet)
      break;
  }
  return bRet;
}

bool Ccan232::bSendCanMsg( canmsg_t *psCan)
{
  return (psCan!=0) ? bSend(psCan->id, psCan->length,&psCan->data[0]):0;
}


bool Ccan232::bSend29( int nId,int nLen,unsigned char *pData)
{
  bool bOk=0;
  if(bDebug)
    printf("CAN232:Send29 Enter\n");
  poSem->wait();
  if((pData && (nLen>0))||(!nLen && !pData)){
    char ac[30];
    char acHead[]={7,10,13,0};
    char *p=&ac[0];
    //printf("CAN232_bSend29:%X\n",nId);
    lSession++;
    nLen = (nLen <= 8) ? nLen:8;
    p[0]='T';
    for (int n=0;n<8;n++){
      int nTmp;
      nTmp = nId>>(4*(7-n));
      p[1+n]=tohex(nTmp&0x0f);   // nid = 0-0x1fffffff
    }
    p[9]=tohex(nLen);
    p=&p[10];
    for (int n=0;n<nLen;n++){
      p[0]=tohex(pData[n]>>4);
      p[1]=tohex(pData[n]&0x0F);
      //p[0]=tohex(pData[nLen-n-1]>>4);
      //p[1]=tohex(pData[nLen-n-1]&0x0F);
     p+=2;
    }
    *p=0;
    //if(bVerbose)
      //  printf("CAN232:bSend29:%s\n",ac);
    int nHead=nCmdWaitHead(0,&ac[0],(char*)&acHead[0],100);
    bOk = (nHead == 0x0d);
    if(bVerbose||bDebug){
      printf("CAN232:bSend29 %s, received <%d> %s\n",ac,nHead,bOk?"OK":"FALSE");
    }
    if(!bOk)
      lErrorCnt++;
    else 
      lSendCnt++;
  }
  poSem->post();
  if(bDebug)
    printf("CAN232:Send29 Exit\n");
  return bOk;
}

Ccan232::~Ccan232()
{
  for ( int n=0;n<10;n++){
    if(bClose())
      break;
    bNrCR(3);
  }
  if(pStatusText)
    delete pStatusText;
  if(pCom)
    delete pCom;
  if(poSem)
    delete poSem;
}


