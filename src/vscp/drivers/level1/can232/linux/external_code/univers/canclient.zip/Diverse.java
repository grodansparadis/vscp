import java.util.*;
import java.io.*;

class Diverse 
{
    public Date oDate= new Date();
    public long lStartTime=0;

    public Diverse()
    {
    }

    public double rMin( double r1, double r2){
	return r1<r2 ? r1:r2;
    }

    public double rMax( double r1, double r2){
	return r1>r2 ? r1:r2;
    }

    public int nMin( int n1, int n2){
	return n1<n2 ? n1:n2;
    }

    public int nMax( int n1, int n2){
	return n1>n2 ? n1:n2;
    }
    
    public long lTimeTenthOfSec( )
    {
	return (lTimeMilli()+50)/100;
    }

    public String sWriteFile( String sFileName,String sData)
    {
	try {
	    FileWriter file=null;
	    file = new FileWriter(sFileName);
	    file.write(sData);
	    file.close();
	}
	catch (IOException e){
	    sData=null;
	}
	return sData;
    }


    public String sReadFile( String sFileName) throws IOException
    {
	String sFile=null;
	if( sFileName!=null){
	    sFile="";
	    String inputLine=null;
	    int nCnt=0;
	    try {
		FileReader file = new FileReader(sFileName);
		if ( file !=null){
		    BufferedReader in = new BufferedReader(file);
		    while ((inputLine = in.readLine()) != null) {
			nCnt++;
			sFile+=inputLine+"\n";
		    }
		    in.close();
		    file.close();
		}
	    }
	    catch(IOException e){
		sFile=null;
	    }
	}
	return sFile;
    }
    
    public double rTime( )
    {
	double r;
	r = (double) lTimeMilli();
	r /=1000.0;
	return r;
    }


    public long lTimeSetStart( boolean b){
	lStartTime += b ? lTimeMilli():0;
	return lStartTime;
    }

    public void timeNew( )
    {
	oDate = new Date();
    }

    public long lTimeMilli()
    {
	return oDate.getTime();
    }

    public long lTimeOffsetMilli()
    {
	return oDate.getTime()-lStartTime;
    }

    public void sleepSec( double r)
    {
	r +=0.0005;
	r *=1000;
	sleepMilli((long)r);
    }

    public void sleepMilli(long n)
    {
	if(n>0){
	    try{
		Thread.sleep(n);
	    }
	    catch( InterruptedException e ){
		System.err.println("Sleep error...");
		System.exit(-1);
	    }
	}
    }

    public long lSleepUntilTime( long l)
    {
	timeNew();
	l-=lTimeMilli();
	sleepMilli(l);
	return l;
    }

    public String sMaxDecimals( String s, int nDec)
    {
	int n;
       	n=s.indexOf('.');
	if(n>0 && nDec>0){
	    n=nMin(n+=nDec+1,s.length());
	}
	else 
	    n=s.length();
	s=s.substring(0,n);
	return s;
    }
}
