function b=can_setcode(can,code)
     nCode=int64(mask);
     b=can.bSetCode(nCode);
