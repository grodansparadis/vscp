#include "semaphore.h"
#include <stdio.h>
#include <string.h>

Csemaphore::Csemaphore( int nValue, bool bDebug, bool bInUse, char *pName)
{
  static int nNumber=0;
  this->acName[0]=0x00;
  this->nIndex = nNumber++;
  this->nWait =0;
  this->nPost =0;
  this->nUseCnt=0;
  this->nMaxDiff = 1000;
  this->nBeginValue = nValue;
  this->bInUse = bInUse;
  this->bDebug=bDebug;
  setName(pName);
  sem_init(&sLock,0,nValue);
}

Csemaphore::~Csemaphore( void)
{
  if(bDebug){
    printf("SEMAPHORE%d: Number:%d Value=%d Wait=%d Post=%d BeginValue=%d\n",nIndex, nIndex, nGetValue(), nWait, nPost, nBeginValue);
  }
  for(int n=0;(sem_destroy(&sLock)<0) && (n<10);n++){
    if(bDebug)
      printf("SEMAPHORE%d:Client blocked and waiting, try to release\n",nIndex);
    post();
  }
}

void Csemaphore::setMaxDiff( int n)
{
  nMaxDiff = n;
}

void Csemaphore::setName( char *p)
{
  acName[0]=0;
  if(p){
    strncpy(acName,p,20);
  }
  acName[20]=0;
}

void Csemaphore::off( void)
{
  bInUse = false;
}

void Csemaphore::on(void)
{
  bInUse = true;
}

void Csemaphore::Wait( void)
{
  wait();
}

void Csemaphore::Post( void)
{
  post();
}
 
void Csemaphore::lock( void)
{
  wait();
}

void Csemaphore::Lock( void)
{
  wait();
}

void Csemaphore::Unlock( void)
{
  post();
}

void Csemaphore::unlock( void)
{
  post();
}


void Csemaphore::wait(void)
{
  nUseCnt++;
  nWait++;
  if(bDebug)
    printf("SEMAPHORE%d:Wait Enter, value=%d\n",nIndex,nGetValue());
  if(bInUse)
    sem_wait(&sLock);
}

void Csemaphore::post(void)
{
  if(bDebug)
    printf("SEMAPHORE%d:Post Enter, value=%d\n",nIndex,nGetValue());
 if( bInUse)
    sem_post(&sLock);
  int nDiff = (nPost++) - nWait;
  nDiff = (nDiff<0) ? -nDiff:nDiff;
  if(nDiff>nMaxDiff){
    printf("SEMAPHORE%d: ERROR, post-wait=%d\tValue=%d nMaxDiff=%d\n",nIndex,nDiff,nGetValue(),nMaxDiff);
  }
}

bool Csemaphore::bTryWait( void)
{
  nUseCnt++;
  nWait++;
  if(bDebug)
    printf("SEMAPHORE%d:TryWait Enter, value=%d\n",nIndex,nGetValue());
  return bInUse ? sem_trywait(&sLock)==0:true;
}

int Csemaphore::nGetValue( void)
{
  int nValue= nPost-nWait;
  if(bInUse)
    sem_getvalue(&sLock,&nValue);
  return nValue;
}
