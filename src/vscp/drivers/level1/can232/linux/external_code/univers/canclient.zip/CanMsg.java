import java.lang.*;
import java.util.*;

public class CanMsg
{
    int nId=0x0;
    short nLength=0;
    int nIndex=0;
    long lMicroSeconds;
    long lSeconds;
    byte abData[] ={0,0,0,0,0,0,0,0};
    int nDBLength=0;
    int nDBIndex =0;
    boolean bSet = false;

    
    public CanMsg(String s)
    {
	init(s);
    }
    
    
    public CanMsg(StringTokenizer st)
    {
	init(st);
    }
 

    public CanMsg(double rId, double ar[])
    {
	byte ab[]=new byte[ar.length];
	for (int n=0;n<ar.length;n++)
	    ab[n]=(byte) ar[n];
	init((int) rId,ab);
    }

    public CanMsg(int nId, int an[])
    {
	byte ab[]=new byte[an.length];
	for (int n=0;n<an.length;n++)
	    ab[n]=(byte) an[n];
	init(nId,ab);
    }

    public CanMsg(int an[])
    {
	byte ab[]=new byte[an.length-1];
	for (int n=0;n<an.length-1;n++)
	    ab[n]=(byte) an[n+1];
	init(an[0],ab);
    }
   
 
    public CanMsg( int nId, byte[] ab)
    {
	init(nId, ab);
    }


    void init (int nInId,byte[] abInData)
    {
	nId=nInId;
	nLength=(short)abInData.length;
	for (int n=0;n<8;n++){
	    abData[n]=0;
	}
 	for (int n=0;n<abInData.length;n++){
	    abData[n]=abInData[n];
	}
	bSet = true;
    }

  
    public boolean bIsSet( )
    {
	return bSet;
    }

    public int nGetDBIndex()
    {
	return nDBIndex;
    }

    public int nGetDBLength()
    {
	return nDBLength;
    }

    public double rGetTime()
    {
	double r =((double) lMicroSeconds)*(1.0/1000000.0);
	r +=(double) lSeconds;
	return r;
    }


    public long lGetSeconds()
    {
	return lSeconds;
    }

    public long lGetMicroSeconds()
    {
	return lMicroSeconds;
    }


    void init(String s)
    {
	//System.out.println("CANMSG_init:"+s);
	if(s!=null){
	    if(s.length()>0){
		StringTokenizer st = new StringTokenizer(s);
		init(st);
	    }
	}
    }

    void init(StringTokenizer st)
    {
	if(st!=null){
	    String s=st.nextToken();
	    if(!s.equals("HEX")){
		System.out.println("CANINIT_ERROR\n");
	    }
	    else {
		Hex2Dec oH2I = new Hex2Dec();
		while(st.hasMoreTokens()){
		    s=st.nextToken();
		    if(s.equals("ID")){
			nId=(int)oH2I.lHexStr2Dec( st.nextToken());
			bSet = true;
		    }
		    else if(s.equals("DBL")){
			nDBLength=(int)oH2I.lHexStr2Dec( st.nextToken());
		    }
		    else if(s.equals("DBI")){
			nDBIndex=(int)oH2I.lHexStr2Dec( st.nextToken());
		    }
		    else if(s.equals("I")){
			nIndex=(int)oH2I.lHexStr2Dec( st.nextToken());
		    }
		    else if(s.equals("T")){
			lSeconds= oH2I.lHexStr2Dec( st.nextToken());
			lMicroSeconds=oH2I.lHexStr2Dec( st.nextToken());
		    }
		    else if (s.equals("L")){
			nLength=(short) oH2I.lHexStr2Dec( st.nextToken());
			nLength = nLength<=8 ? nLength:8;
		    }
		    else if( s.equals("DA")){
			for (int n=0;n<nLength && st.hasMoreTokens();n++)
			    abData[n]=(byte) oH2I.lHexStr2Dec( st.nextToken());
		    }
		    else if( s.equals("FALSE")){
			bSet =false;
		    }
		    else {
			System.out.println("CANMSG:Unknown token:"+s+"in InitHexWithTime, aborting");
			break;
		    }
		}
	    }
	}
	//System.out.println(toText());
    }

    public int [] toIntArray()
    {
	int n=0;
	int an[]=new int[2+8+2];
	an[n++]=nId;
	an[n++]=nLength;
	for (int i=0;i<8;i++)
	    an[n++]=((int)abData[i])&0xff;
	an[n++]=(int) lSeconds;
	an[n++]=(int) lMicroSeconds;
	return an;
    }

    public double [] toDoubleArray()
    {
	int n=0;
	double ar[]=new double[2+8+1];
	ar[n++]=nId;
	ar[n++]=nLength;
	for (int i=0;i<8;i++)
	    ar[n++]=(double)(((int)abData[i])&0xff);
	ar[n] =((double) lMicroSeconds)*(1.0/1000000.0);
	ar[n] +=(double) lSeconds;
	return ar;
    }

    public int nGetIndex()
    {
	return nIndex;
    }

    public int nGetId()
    {
	return nId;
    }
    
    public int nGetLength()
    {
	return nLength;
    }
    
    public byte[] abGetData()
    {
	return abData;
    }
    

    
    public String toText()
    {
	String s=" T "+rGetTime() +" I "+nIndex;
	Hex2Dec o = new Hex2Dec();
	s +=" ID "+o.sToHexStr(nId,8)+" L "+nLength+ " D ";
	for ( int n=0;n<nLength;n++)
	    s +=" "+o.sToHexStr((abData[n])&0xff,2); //+":"+n;
	return s;
    }

     	
    public String toServerString()
    {
	Hex2Dec o = new Hex2Dec();
	String s="";
	if((lSeconds!=0)||(lMicroSeconds!=0)){
	    s +="T "+o.sToHexStr(lSeconds,8);
	    s +=" "+o.sToHexStr(lMicroSeconds,5);
	}
	s +=" ID "+o.sToHexStr(nId,8)+" L "+o.sToHexStr(nLength,1) + " DA";
	for ( int n=0;n<nLength;n++)
	    s +=" "+o.sToHexStr(((abData[n])&0xff),2);
	return s;
    }
    
    int hextoi( char c)
    {
	if((c>='a') && (c<='f'))
	    c -='a'-'A';
	return c>='A' ? (int)(c-65+10):(int)(c-48);
    }
 }
