#ifndef __CANMSGDB_H
#define __CANMSGDB_H
#include <semaphore.h>
#include "canmsglist.h"

#define MAX_CANRXMSGS 8192
#define MAX_CANTXMSGS 128


struct Scan_send
{
  long lMicroSecStep;
  long lMicroSecDuration;
  canmsg_t sMsg;
};


class Ccantxdb
{
  bool bDebug;
  bool bVerbose;

  sem_t sLock;
  int nTxMsgs;
  struct Scan_send sTxMsgs[MAX_CANTXMSGS];
  int nLoopCnt;

 public:
  Ccantxdb();
  ~Ccantxdb();
  int nInsert(Ccanmsg *poMsg, long lMicroSecDuration, long lMicroSecStep);
  int nInsert(canmsg_t *pMsg, long lMicroSecDuration, long lMicroSecStep);
  canmsg_t *pCheckIfSend(canmsg_t *pMsg=0);
};

class Ccanmsgdb
{
  bool bDebug;
  bool bVerbose;
  char *pStatusText;

  sem_t sLock;
  char *pMsgIdListTxt;
  int nIdLists;
  Ccanmsglist *apIdLists[200];
  //int nMaxIndex;

  int nFifoIndex;
  canmsg_t asCanRxFifo[MAX_CANRXMSGS];
  
  // char *pMsgIdListTxt;

 public:
  Ccanmsgdb(int nMaxIds=200, bool bVerbose=true,bool bDebug=false);
  ~Ccanmsgdb();
  
  int nGetIds(void);
  int nInsert( Ccanmsg *pMsg);
  int nInsert( canmsg_t *pMsg, int nLen=1);
  char * pMsgIdList( char *pTxt=0);
  int nGetIdIndex( int nId);
  Ccanmsgdb *pWaitLock( void);
  Ccanmsgdb *pUnlock( void);
  Ccanmsglist *pGetListPtrById(int nId);
  Ccanmsglist *pGetListPtr(int nListNr);
  canmsg_t *pGetCanMsgByIndex(int nIndex, canmsg_t *pMsg);
  Ccanmsg oGetCanMsgByIndex(int nIndex=0);
  Ccanmsg *poGetCanMsgByIndex(int nIndex=0);
  Ccanmsg oGetById( int nId,int nIndex=0);
  Ccanmsg *poGetById( int nId,int nListIndex=0);
  int nGetFifoIndex( void);
  int nGetFifoCanIdByIndex( int nIndex);
  int nGetIndex( void);
  char *pGetStatusText( char *pStatusTxt=0);
};




#endif
