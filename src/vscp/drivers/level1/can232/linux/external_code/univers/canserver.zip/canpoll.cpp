#include <stdio.h>
#include <stdlib.h>
#include "can232.h"
#include <time.h>
#include <string.h>
#include "tokenizer.h"


int main( int argc, char *argv[])
{
  if(argc>1){
    Ctokenizer *poToken = new Ctokenizer(argc, argv);
    canmsg_t asCanMsg[20];
    int nToken = poToken->nFindToken("-s");
    int nSerialDevice = nToken>=0 ? poToken->nToInt(nToken+1):0;
    nToken = poToken->nFindToken("-b");
    int nBaud =  nToken>=0 ? poToken->nToInt(nToken+1):115200;
    nToken = poToken->nFindToken("-c");
    int nSpeed =  nToken>=0 ? poToken->nToInt(nToken+1):250000;
    nToken = poToken->nFindToken("-n");
    int nToPoll =  nToken>=0 ? poToken->nToInt(nToken+1):1;
    int nHost = poToken->nFindToken("-h");
    if(nHost<0){
      if(poToken->nFindToken("-v")>=0)
	printf("Polling /dev/ttyS%d Baudrate=%d Speed=%d\n",nSerialDevice,nBaud,nSpeed);
      class Ccan232 *pCan = new Ccan232(nSerialDevice,nBaud,nSpeed);
      if (pCan && pCan->bOpen()){
	int nIndex=0;
	while(nIndex<nToPoll){
	  int nPolled=8;
	  canmsg_t *ps=pCan->pPollMsgs(&nPolled,&asCanMsg[0]);
	  for (int n=0;ps && (n<nPolled) && (nIndex<nToPoll);n++){
	    Ccanmsg *po= new Ccanmsg(&ps[n]);
	    puts(po->pToText());
	    nIndex++;
	    delete po;
	  }
      	}
	pCan->bClose();
	delete pCan;
      }
    }
  }
  else {
    printf("Use, canpoll -s <serialdevice> -b <baudrate> -c <canbusspeed>\nExample canpoll -s 0 -b 115200 -c 250000\n");
  }
  return 1;
}
