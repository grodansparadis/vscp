function b=can_send(can,msg)
%  
%    can_send(can, can identifier, [d0 d1 ... d7])
%    returns 1 if send succesful
%
     o =CanMsg(msg);
     r=can.bSend(o);


