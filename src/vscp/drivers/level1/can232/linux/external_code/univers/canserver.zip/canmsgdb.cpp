#include "canmsgdb.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


Ccantxdb::Ccantxdb( )
{
  nTxMsgs=0;
  sem_init(&sLock,0,1);
  nLoopCnt=0;
  bDebug = 1>0;
}
Ccantxdb::~Ccantxdb()
{
  sem_destroy(&sLock);
}

int Ccantxdb::nInsert(Ccanmsg *poMsg, long lMicroSecDuration, long lMicroSecStep)
{
  canmsg_t s;
  poMsg->CopyTo(&s);
  return nInsert( &s, lMicroSecDuration, lMicroSecStep);
}


int Ccantxdb::nInsert(canmsg_t *pMsg, long lMicroSecDuration, long lMicroSecStep)
{
  int nRet=-1;
  sem_wait(&sLock);
  if((nTxMsgs<MAX_CANTXMSGS) && pMsg){
    gettimeofday(&sTxMsgs[nTxMsgs].sMsg.timestamp,0);
    memcpy(&sTxMsgs[nTxMsgs].sMsg,pMsg,sizeof(canmsg_t));
    sTxMsgs[nTxMsgs].lMicroSecDuration = lMicroSecDuration;
    sTxMsgs[nTxMsgs].lMicroSecStep = lMicroSecStep;
    nRet=++nTxMsgs;
  }
  sem_post(&sLock);
  return nRet;
}

/*

if pMsg argument is pMsg a new object is creadted must be deleted.

*/


canmsg_t *Ccantxdb::pCheckIfSend(canmsg_t *pMsg)
{
  long lNowSec, lNowUsec;
  {
    struct timeval sTime;
    gettimeofday(&sTime,0);
    lNowSec = sTime.tv_sec;
    lNowUsec = sTime.tv_usec;
  }
  canmsg_t *pRet=0;
  sem_wait(&sLock);
  for (int n=0;n<nTxMsgs;n++){
    int nIndex = nLoopCnt%nTxMsgs;
    long lMsgSec = sTxMsgs[nIndex].sMsg.timestamp.tv_sec;
    long lMsgUsec =  sTxMsgs[nIndex].sMsg.timestamp.tv_usec;
    if( sTxMsgs[nIndex].lMicroSecDuration<0){
      sem_post(&sLock);
      if(nIndex<nTxMsgs){
	memcpy(&sTxMsgs[nIndex],&sTxMsgs[nIndex+1],sizeof(canmsg_t)*(nTxMsgs-nIndex));
	if(nLoopCnt>nIndex)
	  nLoopCnt--;
	nTxMsgs--;
      }
    }
    else {
      nLoopCnt++;
      if((lNowSec>lMsgSec)||
	 ((lNowSec==lMsgSec)&&(lNowUsec>lMsgUsec))){
	lMsgUsec +=sTxMsgs[nIndex].lMicroSecStep;
	if(lMsgUsec >= 1000000){
	  lMsgSec++;
	  lMsgUsec -=1000000;
	}
	sTxMsgs[nIndex].sMsg.timestamp.tv_sec=lMsgSec;
	sTxMsgs[nIndex].sMsg.timestamp.tv_usec=lMsgUsec;
	sTxMsgs[nIndex].lMicroSecDuration -=sTxMsgs[nIndex].lMicroSecStep;
	if(!pMsg)
	  pMsg = new canmsg_t;
	pRet=pMsg;
	memcpy(pRet,&sTxMsgs[nIndex].sMsg,sizeof(canmsg_t));
	//	printf("Found message:%X\n",(unsigned)pRet);
	break;
      }
    }
  }
  sem_post(&sLock);
  return pRet;
}


//---------------------------------------------------------------

Ccanmsgdb::Ccanmsgdb(int nMaxIds, bool bVerbose, bool bDebug)
{
  sem_init(&this->sLock,0,1);
  this->nIdLists=0;
  this->pMsgIdListTxt=0;
  this->pStatusText = 0;
  this->bDebug = bDebug;
  this->bVerbose = bVerbose;
}


Ccanmsgdb::~Ccanmsgdb()
{
  sem_wait(&sLock);
  for(int n=0;n<nIdLists;n++){
    delete apIdLists[n];
  }
  if (pStatusText)
    delete pStatusText;
  if (pMsgIdListTxt)
    delete pMsgIdListTxt;
  sem_post(&sLock);
  sem_destroy(&sLock);
} 

int Ccanmsgdb::nGetIds( void)
{
  sem_wait(&sLock);
  int n=nIdLists;
  sem_post(&sLock);
  return n;
}




int Ccanmsgdb::nGetIndex( void)
{
  return nGetFifoIndex();
}


int Ccanmsgdb::nGetFifoCanIdByIndex( int nIndex)
{
  int nArrayIndex = (nIndex-1)&(MAX_CANRXMSGS-1);
  sem_wait(&sLock);
  canmsg_t *p=&asCanRxFifo[ nArrayIndex];
  sem_post(&sLock);
  return p ? (int)p->id:-1;
}


int Ccanmsgdb::nGetFifoIndex( void)
{
  sem_wait(&sLock);
  int n=nFifoIndex;
  sem_post(&sLock);
  return n;
}
 
Ccanmsg *Ccanmsgdb::poGetCanMsgByIndex(int nIndex)
{
  Ccanmsg *poCanMsg=0;
  canmsg_t sCanMsg;
  if(pGetCanMsgByIndex(nIndex,&sCanMsg)){
    poCanMsg = new Ccanmsg(&sCanMsg,nIndex);
  }
  return poCanMsg;
}

canmsg_t *Ccanmsgdb::pGetCanMsgByIndex( int nIndex, canmsg_t *pMsg)
{
  int nArrayIndex = (nIndex-1)&(MAX_CANRXMSGS-1);
  sem_wait(&sLock);
  canmsg_t *p=&asCanRxFifo[ nArrayIndex];
  if(!pMsg)
    pMsg = new canmsg_t;
  if(pMsg){
    memcpy(pMsg,p,sizeof(canmsg_t));
  }
  sem_post(&sLock);
  return p ? pMsg:0;
}

/*
int Ccanmsgdb::nInsert( Ccanmsg *pMsg)
{
}
*/

Ccanmsgdb * Ccanmsgdb::pWaitLock( void)
{
  sem_wait(&sLock);
  return this;
}

Ccanmsgdb * Ccanmsgdb::pUnlock( void)
{
  sem_post(&sLock);
  return this;
}


int Ccanmsgdb::nInsert( canmsg_t *pMsg, int nLen)
{
  int nRetIndex=0;

  if(pMsg){
    sem_wait(&sLock);
    for (int i=0;i<nLen;i++){
      int nIndex = nFifoIndex&(MAX_CANRXMSGS-1);
      memcpy(&asCanRxFifo[nIndex],&pMsg[i],sizeof(canmsg_t));
      nRetIndex=++nFifoIndex;
      int n;
      for (n=0;n<=nIdLists;n++){
	//printf("Searching %d\n",n);
	if((n==nIdLists)||(pMsg[i].id<(unsigned)apIdLists[n]->pPtrHead()->nGetId())){
	  for (int j=nIdLists;j>n;j--){
	    apIdLists[j]=apIdLists[j-1];
	  }
	  apIdLists[n] = new Ccanmsglist(&pMsg[i],1000);
	  nIdLists++;
	  break;
	}
	else if((unsigned)apIdLists[n]->pPtrHead()->nGetId()==pMsg[i].id){
	  apIdLists[n]->nInsertHead(&pMsg[i]);      
	  break;
	}
      }
    }
    sem_post(&sLock);
    if(bVerbose){
      if((nFifoIndex % 100)==0)
	printf("CANMSGDB:Received %d can messages\n",nFifoIndex);
      if((nFifoIndex%1000)==0){
	printf(pGetStatusText());
	printf(pMsgIdList());
      }
    }
  }
  return nRetIndex;
}

Ccanmsg Ccanmsgdb::oGetById( int nId,int nIndex)
{
  Ccanmsg oCanMsg(poGetById(nId,nIndex));
  return oCanMsg;
}

Ccanmsg * Ccanmsgdb::poGetById( int nId,int nIndex)
{
  Ccanmsglist *pList = pGetListPtrById(nId);
  sem_wait(&sLock);
  Ccanmsg *poCanMsg=pList->pPtrHead()->poClone();
  sem_post(&sLock);
  return poCanMsg;
}


Ccanmsglist * Ccanmsgdb::pGetListPtrById( int nId)
{
  Ccanmsglist *pList=0;
  sem_wait(&sLock);
  for (int n=0;(n<nIdLists) && apIdLists[n];n++){
    //printf("CanMsgDB|ListId %X==%X\n",(unsigned)apIdLists[n]->pPtrHead()->nGetId(),(unsigned)nId);
    int nListId =apIdLists[n]->pPtrHead()->nGetId();
    if( nListId==nId){
      if( bDebug)
	printf("CanMsgDB|ListId list no:%d found nId=%X\n",n,nId);
      pList=apIdLists[n];
      break;
    }
    else if(nListId>nId){
      break;
    }
  }
  sem_post(&sLock);
  return pList;
}

int Ccanmsgdb::nGetIdIndex( int nId)
{
  int nRet=0;
  Ccanmsglist *pList= pGetListPtrById(nId);
  if(pList){
    nRet = pList->pPtrHead()->nGetIndex();
  }
  return nRet;
}  


char * Ccanmsgdb::pGetStatusText( char *p)
{
  if(!p){
    if(!pStatusText)
      pStatusText = new char[32768];
    p = pStatusText;
  }
  char *pBeg=p;
  sem_wait(&sLock);
  if(p){
    sprintf(p,"RECEIVED_CAN_MESSAGES: %d\n",nFifoIndex);
    p=&p[strlen(p)];
    sprintf(p,"DIFFERENT_MESSAGE_IDS: %d\n",nIdLists);
  }
  sem_post(&sLock);
  return pBeg;
}


char * Ccanmsgdb::pMsgIdList( char *pTxt)
{
  sem_wait(&sLock);
  if(!pTxt){
    if(pMsgIdListTxt){
      delete pMsgIdListTxt;
    }
    pMsgIdListTxt = new char[100*nIdLists];
    pTxt = pMsgIdListTxt;
  }
  char *pTxtBegin = pTxt;
  pTxt[0]=0;
  //  printf("DB_pMsgIdList, lists=%d\n",nIdLists);
  //sprintf(pTxt,"DATABASE_LIST %d\n",nIdLists);
  //for(;*pTxt;pTxt++);
  for (int n=0;n<nIdLists;n++){
    int nLen=apIdLists[n]->nGetLength();
    int nIndex = apIdLists[n]->nGetIndex();
    sprintf(pTxt,"B DBC %6X DBL %.5X ",nIndex,nLen);
    for(;*pTxt;pTxt++);
    char *pMsgTxt=apIdLists[n]->pPtrHead()->pToClientText();
    if(pMsgTxt){
      strcpy(pTxt,pMsgTxt);
      for(;*pTxt;pTxt++);
      *(pTxt++)=0x0a;
      /*
      if(n<nIdLists){
	*(pTxt++)=0x0a;
      }
      */
    }
    *pTxt=0;
  }
  //printf("\n\nCANMSGDB:-----------\n%s\n",pMsgIdListTxt);
  sem_post(&sLock);
  return pTxtBegin;
}

