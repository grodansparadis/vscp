#ifndef __CANMSGLIST_H
#define __CANMSGLIST_H

#include "canmsg.h"

class Scanmsglist
{
 public:
  Ccanmsg *pMsg;
  struct Scanmsglist *pNext;
  struct Scanmsglist *pPrev;  
  
  Scanmsglist( Ccanmsg & oMsg,struct Scanmsglist *pNext,struct Scanmsglist *pPrev );
  ~Scanmsglist();
  Scanmsglist( canmsg_t *pMsg,struct Scanmsglist *pNext,struct Scanmsglist *pPrev, int nIndex=0);
};


class Ccanmsglist
{
  int nMaxLength;
  int nLength;
  int nIndex;
  Scanmsglist *pHead, *pTail;
  struct Scanmsglist *pPtr;

 public:
  Ccanmsglist();
  Ccanmsglist(Ccanmsg & oMsg,int nMaxLength=0);
  Ccanmsglist(canmsg_t *pMsg,int nMaxLength=0, int nIndex=0);
  ~Ccanmsglist();
  int nGetIndex( void);
  int nInsertHead(Ccanmsg & oMsg);
  int nInsertTail(Ccanmsg & oMsg);
  int nInsertHead(canmsg_t *poMsg, int nIndex=0);
  int nInsertTail(canmsg_t *poMsg, int nIndex=0);
  Ccanmsg *pPtrHead( void);
  Ccanmsg *pPtrTail(void);
  Ccanmsg oPopHead( void);
  Ccanmsg oPopTail( void);

  Ccanmsg *pPtrAndNext(void);
  Ccanmsg *pPtrAndPrev(void);
  Ccanmsg *pPtrGotoHead(void);
  Ccanmsg *pPtrGotoTail(void);
  Ccanmsg *pGetPtr(void);

  canmsg_t *pPopTail( canmsg_t *pMsg=0);
  canmsg_t *pPopHead( canmsg_t *pMsg=0);
  int nDeleteTail( void);
  int nGetLength( void);
};



#endif
