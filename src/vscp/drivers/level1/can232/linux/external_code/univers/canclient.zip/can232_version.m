function v=can232_version(c)
     v=c.getVersion;
