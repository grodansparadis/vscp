#include <ctype.h>
#include "Cinteger.h"
#include <stdio.h>
#include <stdlib.h>

Cinteger::Cinteger()
{
  pcToHex =0;
  pcToDec =0;
  set(0,64);
  bLeadingZeros =true;
}

Cinteger::Cinteger(char *p)
{
  pcToHex =0;
  pcToDec =0;
  set((int)lHexStrToLong(p),64);
  bLeadingZeros = 1;
}

Cinteger::Cinteger( int n, int nNumOfBits)
{
  pcToHex =0;
  pcToDec =0;
  set(n,nNumOfBits);
  bLeadingZeros = 1;
}

Cinteger::~Cinteger()
{
  if(pcToHex)
    delete pcToHex;
  if(pcToDec)
    delete pcToDec;
}

void Cinteger::set( long int n, int nNumOfBits)
{
  nLocal = n;
  nBits = nNumOfBits;
}

Cinteger *Cinteger::pSet(long int n, int nNumOfBits)
{
  nLocal = n;
  nBits = nNumOfBits;
  return this;
}

int Cinteger::nHexAscToInt( char c)
{
  c=toupper(c);
  return (c>='A') ? (c-'A'+10):(c-'0');
}

char Cinteger::cIntToHexAsc(int n)
{
  n &=0x0f;
  return ((n<10) ? ('0'+n):('A'+n-10));
}

char * Cinteger::pToHex(int nMaxNib, char *p)
{
  if(!p){
    pcToHex = new char[30];
    p = pcToHex;
  }
  //sprintf(p,"%.15lX",nLocal);
  //return p;
  int nIndex=0;
  for(int nNib=0;nNib<nMaxNib;nNib++){
    long int n= nLocal;
    n>>=((nMaxNib-1-nNib)*4);
    p[nIndex]=cIntToHexAsc((int)n);
    if((p[0]!='0') || bLeadingZeros)
      nIndex++;
    p[nIndex]=0x00;
  }
  return p;
}

char * Cinteger::pToDec(int nDecTal, char *p)
{
  long n= nLocal;
  if(!p){
    pcToDec = new char[30];
    p = pcToDec;
  }
  sprintf(p,"%ld",nLocal);
  //printf("pIntToDec:%d %s\n",n,p);
  return p;
  p[0]=0;
  if(n>=10000){
    //printf("Integer to dec\n");
    //sleep(1);
    for(int nIndex=0;nDecTal>0;nDecTal /=10){
      int nTmp;
      nTmp = n/nDecTal;
      n -=nTmp*nDecTal;
      p[nIndex]=(nTmp&0x0f)+'0';
      if(p[0]!='0')
	nIndex++;
      p[nIndex]=0x00;			 
    }
    printf("MASTER:Integer to dec,exit\n");
  }
  else if(n>=1000){
    unsigned int nTmp;
    nTmp = n/1000;
    n -=nTmp*1000;
    p[0]=(char)nTmp+'0';

    nTmp = n/100;
    n -=nTmp*100;
    p[1]=(char)nTmp+'0';

    nTmp = n/10;
    n -=nTmp*10;
    p[2]=(char)nTmp+'0';


    p[3]=(char)n+'0';
    p[4]=0;
  }
  else if(n>=100){
    unsigned int nTmp;
    nTmp = n/100;
    n -=nTmp*100;
    p[0]=(char)nTmp+'0';

    nTmp = n/10;
    n -=nTmp*10;
    p[1]=(char)nTmp+'0';


    p[2]=(char)n+'0';
    p[3]=0;
  }
  else if(n>=10){
    unsigned int nTmp;
    nTmp = n/10;
    n -=nTmp*10;
    p[0]=(char)nTmp+'0';


    p[1]=(char)n+'0';
    p[2]=0;
  }
  else {
    p[0]=(char)n+'0';
    p[1]=0x00;
  }
  printf("Dec:%s=%lX\n",p,(unsigned long)n);
  return p;
}

int Cinteger::nGetValue( void)
{
  return nLocal;
}


long Cinteger::lHexStrToLong( char *p)
{
  bool bNeg=0;
  long l=0;
  if(p){
    while(*p && *p=='-'){
      bNeg = !bNeg;
      p++;
    }
    while(*p){
      l<<=4;
      if(isxdigit(*p))
	l+=nHexAscToInt(*p);
      else 
	break;
      p++;
    }
    l = bNeg ? -l:l;
  }
  nLocal=(int)l;
  return l;
}

long Cinteger::lDecStrToLong( char *p)
{
  bool bNeg=0;
  long l=0;
  if(p){
    while(*p && *p=='-'){
      bNeg = !bNeg;
      p++;
    }
    while(*p){
      l*=10;
      if(isxdigit(*p))
	l+=nHexAscToInt(*p);
      else 
	break;
      p++;
    }
    l = bNeg ? -l:l;
  }
  nLocal=(int)l;
  return l;
}
