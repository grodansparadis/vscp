function v=can_version(c)
     v=c.getVersion;
