/////////////////////////////////////////////////////////////////////////////////////
//  CANSRVTSK.C
//
//
//
//
//
//
//
//
//
//
//
//////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sched.h>
#include <pthread.h> 
#include <semaphore.h>
#include <string.h>
#include "canmsg.h"
#include "canmsglist.h"

#include "master.h"
#include "tokenizer.h"
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "threadedserver.h"


const int nCanSrvSocket[]={SOCKET_FOR_CANSRVTSK_1,
			   SOCKET_FOR_CANSRVTSK_2,
			   SOCKET_FOR_CANSRVTSK_3,
			   SOCKET_FOR_CANSRVTSK_4};


struct SHARED_CANSRV_DATA 
{
  sem_t *sSocketLock; //VERY IMPORTANT, Use this semaphore before reaching the other
                      //data in this struct
  sem_t *sImTheBoss;  //Deciding which client that are driving 
  int nMsgList;
  Ccanmsglist apMsgList[300]; 
  Ccandev *pCan; 
  Ccanmsgdb *pDB;
};

class Ccansrv
{
  bool bPasswordOk;
  Ctokenizer oTok;

 public:
  CClientHandler *poClient;  // Client handler object
  int bImTheBoss;           //Do I have the controll?
  char acBuff[200];          // Used when reading from socket
  struct SHARED_CANSRV_DATA *pCanSrvStr;
  struct EMPTY_TASK_STR *pTask;

 public:
  Ccansrv(struct EMPTY_TASK_STR *pTask, 
  	  struct SHARED_CANSRV_DATA *sSharedData, 
          CClientHandler *poClienthandler, int nr);
  ~Ccansrv();
  bool bSendHexCanMsg( int nTokenOffset);
  int nProceed( void);
  struct EMPTY_TASK_STR *psGetTaskStr();
  int nNr;
};

Ccansrv::Ccansrv( struct EMPTY_TASK_STR *pTask, 
		  struct SHARED_CANSRV_DATA *sSharedData,
                  CClientHandler *poClienthandler, int nr)
{
  bPasswordOk = 0;
  bImTheBoss  = 0;
  poClient    = poClienthandler;
  pCanSrvStr  = sSharedData;
  this->pTask = pTask;
  pCanSrvStr->pCan = CAN_pGetDevicePtr(0);
  nNr = nr;
  pCanSrvStr->pDB =  pCanSrvStr->pCan->pGetDBPtr();
  if(1>0){
    pTask->nDebug = 1;
    printf("CANSRVTSK:pCan=%X\n",(int)pCanSrvStr->pCan);
  }
  //pCanSrvStr->pDB = pCanSrvStr->;
} 

struct EMPTY_TASK_STR * Ccansrv::psGetTaskStr()
{
  return pTask;
}

Ccansrv::~Ccansrv() //Destructor
{
  delete poClient;	
} 


bool Ccansrv::bSendHexCanMsg( int nTokenOffset)
{
  Ccanmsg oCanMsg( &oTok, nTokenOffset);
  int nResult=pCanSrvStr->pCan->bSend(&oCanMsg);
  if((pTask->nDebug&&0) ||1){
    printf("CANSRVTSK:Sendhex=%s Result=%d\n",oCanMsg.pToText(),(int)nResult);
    printf("CANSRVTSK:Sendhex=%s Result=%d\n",oCanMsg.pToClientText(),(int)nResult);
  }
  return nResult;
}

int Ccansrv::nProceed( void)
{
  static struct SHARED_CANSRV_DATA *pStr;
  int nReturn = 1;
  int nRead;
  pStr = pCanSrvStr;
  if (pTask->nDebug&&0){
    printf("Waiting for command\n");
  }
  nRead=poClient->nGetLine(acBuff,0);
  //printf("CANSRVTSK:%s pStr->pCan=%X\n",acBuff,(unsigned) pStr->pCan);
  sem_wait(pStr->sSocketLock);
  if (nRead>0){
    int nTokens;
    oTok.Tokenize(acBuff);
    nTokens = oTok.nGetTokens();
    if (pTask->nDebug&&0){
      printf("CANSRVTSK|Received Command:%s Length %d, %d tokens\n",acBuff,strlen(acBuff), nTokens);
    
      if(pTask->nDebug){
	printf("CANSRVTSK:Tokens ");
	for(int n=0;n<oTok.nGetTokens();n++)
	  printf("%d:%s|",n,oTok.pGetToken(n));
	printf("\n");
      }
    }
    if(!strcmp(oTok.pGetToken(0),"?")){
      poClient->nWrite("CANSERVER MODEL_IN_USE CAN232\n");
    }
    else if(!strcasecmp(oTok.pGetToken(0),"SENDSTR")&&0){
      if(pTask->nDebug)
	printf("CANSRV sending:%s\n",oTok.pGetToken(1));
      //      strcpy(acBuff,pStr->pCan->bSendLine(oTok.pGetToken(1)) ? "OK":"FALSE");
      poClient->nWriteLine(acBuff);
    }
    else if(!strcasecmp(oTok.pGetToken(0),"CLOSE")){
      if(pTask->nDebug)
	printf("CANSRV sending:%s\n",oTok.pGetToken(1));
      strcpy(acBuff,(char*)pStr->pCan->bClose() ? "TRUE":"FALSE");
      poClient->nWriteLine(acBuff);
    }
    else if(!strcasecmp(oTok.pGetToken(0),"OPEN")){
      if(pTask->nDebug)
	printf("CANSRV sending:%s\n",oTok.pGetToken(1));
      strcpy(acBuff,(char*)pStr->pCan->bOpen() ? "TRUE":"FALSE");
      poClient->nWriteLine(acBuff);
    }
    /*
    else if(!strcasecmp(oTok.pGetToken(0),"SENDDEC") && (nTokens>=3)){
      unsigned char aData[8];
      int nLen;
      int nId;
       nId =(int) oTok.nToInt(1);
      nLen =(int) oTok.nToInt(2);
      for (int n=0;(n+3<oTok.nGetTokens()) && (n<nLen);n++){
	aData[n]=(unsigned char)oTok.nToInt(n+3);
      }
      strcpy(acBuff,pStr->pCan->bSend(nId,nLen,&aData[0]) ? "TRUE":"FALSE");
      poClient->nWriteLine(acBuff);
    }
    */
    else if(!strcasecmp(oTok.pGetToken(0),"SENDHEX") && (nTokens>=3)){
      int nSemValue;
      sem_getvalue(pStr->sImTheBoss,&nSemValue);
      if ((nSemValue > 0) || bImTheBoss){
	strcpy(acBuff,bSendHexCanMsg(1) ? "TRUE":"FALSE");
	poClient->nWriteLine( acBuff);
      }	
      else{
	poClient->nWriteLine("FALSE");
      }
    }
    else if(!strcasecmp(oTok.pGetToken(0),"SENDHEX_NOACK") && (nTokens>=3)){
      int nSemValue;
      sem_getvalue(pStr->sImTheBoss,&nSemValue);
      if ((nSemValue > 0) || bImTheBoss){
	bSendHexCanMsg(1);
      }
    }
    else if(!strcasecmp(oTok.pGetToken(0),"SENDHEXDB") && (nTokens>=5)){
      unsigned char aucData[8];
      int nId =(int) oTok.lHexToLong(3);
      int nLen =(int) oTok.lHexToLong(4);
      for (int n=0;(n+5<oTok.nGetTokens()) && (n<nLen);n++){
	aucData[n]=(unsigned char)oTok.lHexToLong(n+5);
      }
      {
	int nMilliDuration =(int) oTok.lHexToLong(1);
	int nMilliStep =(int) oTok.lHexToLong(2);
	Ccanmsg oMsg(nId,nLen,&aucData[0]);
	int nMsgs=pStr->pCan->nCanMsgTxDBInsert(oMsg.pGetMsgPtr(),nMilliDuration,nMilliStep);  
	poClient->nWriteLine((char*) (nMsgs ? "TRUE":"FALSE"));
      }
    }
    else if(!strcasecmp(oTok.pGetToken(0),"SENDHEXDB_NOACK") && (nTokens>=5)){
      unsigned char aucData[8];
      int nId =(int) oTok.lHexToLong(3);
      int nLen =(int) oTok.lHexToLong(4);
      for (int n=0;(n+5<oTok.nGetTokens()) && (n<nLen);n++){
	aucData[n]=(unsigned char)oTok.lHexToLong(n+5);
      }
      {
	int nMilliDuration =(int) oTok.lHexToLong(1);
	int nMilliStep =(int) oTok.lHexToLong(2);
	Ccanmsg oMsg(nId,nLen,&aucData[0]);
	pStr->pCan->nCanMsgTxDBInsert(oMsg.pGetMsgPtr(),nMilliDuration,nMilliStep);  
      }
    }
    else if(!strcasecmp(oTok.pGetToken(0),"CODEMASK") && (nTokens==3)){
      int nCode = atoi(oTok.pGetToken(1));
      int nMask = atoi(oTok.pGetToken(2));
      bool bRet = pStr->pCan->bSetCodeMask( nCode, nMask);
      poClient->nWriteLine((char*) (bRet ? "TRUE":"FALSE"));
    }
    /*
    else if(!strcasecmp(oTok.pGetToken(0),"CODE") && (nTokens==2)){
      int nCode = atoi(oTok.pGetToken(1));
      bool bRet = pStr->pCan->bSetCode( nCode);
      poClient->nWriteLine((char*) (bRet ? "TRUE":"FALSE"));
    }
    else if(!strcasecmp(oTok.pGetToken(0),"MASK") && (nTokens==2)){
      int nMask = atoi(oTok.pGetToken(1));
      bool bRet = pStr->pCan->bSetMask( nMask);
      poClient->nWriteLine((char*) (bRet ? "TRUE":"FALSE"));
    }
    */
    else if(!strcasecmp("GIVE_ME_THE_WHEELCHAIR",oTok.pGetToken(0))){
      int test;
      sem_getvalue(pStr->sImTheBoss,&test);
      if (test > 0){
       	printf("Nr %d is the BOSS!\n",nNr);
    	sem_wait(pStr->sImTheBoss);
      	bImTheBoss = 1;
	poClient->nWriteLine("TRUE");
      }	
      else if (bImTheBoss){
      	poClient->nWriteLine("TRUE");
      }
      else {
      	poClient->nWriteLine("FALSE");
      }
    }
    else if(!strcasecmp("I_DONT_WANT_IT",oTok.pGetToken(0))){
      int test;
      sem_getvalue(pStr->sImTheBoss,&test);
      if ((test == 0) & bImTheBoss){
       	printf("Nr %d have been relieved of his command!\n",nNr);
    	sem_post(pStr->sImTheBoss);
      	bImTheBoss = 0;
	poClient->nWriteLine("TRUE");
      }	
      else {
      	bImTheBoss = 0;
	poClient->nWriteLine("TRUE");
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"GET_MAX_INDEX")){
      if(pTask->nDebug)
	printf("MAX_INDEX pStr->pCan=%X\n",(unsigned)pStr->pCan);
      sprintf(acBuff,"MAXINDEX %d",pStr->pCan->nGetMaxMsgIndex());
      puts(acBuff);
      poClient->nWriteLine(acBuff);
      if(pTask->nDebug)
	puts(acBuff);
    }
    else if( !strcasecmp(oTok.pGetToken(0),"GET_ID_LIST")){   // get_id_list hex_id max_length index
      bool bOk=0;
      if(pStr->pDB && (oTok.nGetTokens()>=2)){
	int nId=oTok.lHexToLong(1);
	int nMaxLength=oTok.nGetTokens()>=3 ? oTok.lHexToLong(2):0;
	int nStartPos = oTok.nGetTokens()>=4 ? oTok.lHexToLong(3):0;
	if(pTask->nDebug)
	  printf("CANSRV:GET_ID_LIST nId=%X nLength=%d nStartPos=%d\n",nId,nMaxLength,nStartPos);
	Ccanmsglist *pList = pStr->pDB->pGetListPtrById(nId);
	if(pList){
	  pStr->pDB->pWaitLock();
	  if(!nMaxLength)
	    nMaxLength = pList->nGetLength();
	  Ccanmsg *pMsg=pList->pPtrGotoHead();
	  for (int n=1;n<nStartPos;n++)
	    pList->pPtrAndNext();
	  for (int n=0;((n<nMaxLength)||(!nMaxLength)) && (pMsg!=0);n++){
	    pMsg->pToClientText(acBuff);
	    //puts(acBuff);
	    poClient->nWriteLine(acBuff);
	    if(pMsg->nGetIndex()==nStartPos)
	      break;
	    else
	      pMsg=pList->pPtrAndNext();
	  }
	  poClient->nWriteLine("GET_ID_LIST_END");
	  pStr->pDB->pUnlock();
	  bOk=1;
	}
      }
      if(!bOk){
	strcpy(acBuff,"FALSE");
	poClient->nWriteLine(acBuff);
	puts(acBuff);
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"GET_ID")){
      if(!pStr->pDB){
	printf("CANSRVTSK:No databars ptr\n");
	exit(0);
      }
      for (int n=1;n<oTok.nGetTokens();n++){
	bool bOk=0;
	int nId=oTok.lHexToLong(n);
	//	printf("CANSRVTSK:%d,GET_ID=%X\n",n,(unsigned)nId);
	Ccanmsglist *pList = pStr->pDB->pGetListPtrById(nId);
	if(pList){
	  //printf("CANSRVTSK:Found id=%X list\n",(unsigned) nId);
	  pStr->pDB->pWaitLock();
	  Ccanmsg *pMsg=pList->pPtrHead();
	  if(pMsg){
	    pMsg->pToClientText(acBuff);
	    printf("SENDING:%s TO CLIENT\n",acBuff);
	    poClient->nWriteLine(acBuff);
	    bOk=1;
	  }
	  pStr->pDB->pUnlock();
	}
	else if(pTask->nDebug||1){
	  //printf("CANSRVTSK:No list with id=%X\n",(unsigned)nId);
	}
	if(!bOk){
	  strcpy(acBuff,"FALSE");
	  poClient->nWriteLine(acBuff);
	  puts(acBuff);
	}
	} // for
    }
    else if( !strcasecmp(oTok.pGetToken(0),"SENDHEX_WAIT_ID")){
      bool bOk=0;
      if(oTok.nGetTokens()>=2){
	int nId=oTok.lHexToLong(1);
	int nStartIndex = pStr->pCan->nGetMaxMsgIndex();
	int nMilliSecToTimeOut = oTok.lHexToLong(2);
	bool bSendOk = bSendHexCanMsg( 3);  // 3 is tokenoffset
	if(pTask->nDebug)
	  printf("CANSRVTSK:SendWait id=%X begin, FIFO=%d  SendOk==%d\n",(unsigned)nId, nStartIndex,(int)bSendOk);
	if(bSendOk){
	  int nIndex = pStr->pCan->nWaitCanId(nId,nStartIndex, nMilliSecToTimeOut);
	  if(pTask->nDebug){
	    printf("CANSRVTSK:SendWait id=%X end, index=%d, FIFO=%d\n",(unsigned)nId,nIndex,pStr->pCan->nGetMaxMsgIndex());
	    sleep(10);
	  }
	  if(nIndex>0){           // received responce
	    Ccanmsg oMsg;
	    oMsg = pStr->pCan->oGetCanMsg(nIndex);
	    oMsg.pToClientText(&acBuff[0]);
	    poClient->nWriteLine(acBuff);
	    bOk = true;
	  }
	}
      }
      if(!bOk){
	poClient->nWriteLine("FALSE");
      }
      else if( pTask->nDebug){
	printf("CANSRVTSK:Wait released\n");
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"WAIT_ID")){
      bool bOk=0;
      if(oTok.nGetTokens()>=2){
	int nId=oTok.lHexToLong(1);
	int nStartIndex = oTok.nGetTokens()>2 ? oTok.lHexToLong(2):0;
	int nMilliSecToTimeOut = oTok.nGetTokens()>3 ? oTok.lHexToLong(3):500;
	if(pTask->nDebug)
	  printf("CANSRVTSK:Wait id=%X begin, FIFO=%d\n",(unsigned)nId,pStr->pCan->nGetMaxMsgIndex());
	int nIndex = pStr->pCan->nWaitCanId(nId,nStartIndex, nMilliSecToTimeOut);
	if(pTask->nDebug)
	  printf("CANSRVTSK:Wait id=%X end, index=%d, FIFO=%d\n",(unsigned)nId,nIndex,pStr->pCan->nGetMaxMsgIndex());
	if(nIndex>0){
	  Ccanmsg oMsg;
	  oMsg = pStr->pCan->oGetCanMsg(nIndex);
	  oMsg.pToClientText(&acBuff[0]);
	  poClient->nWriteLine(acBuff);
	  bOk = 1;
	}
      }
      if(!bOk){
	poClient->nWriteLine("FALSE");
      }
      else if( pTask->nDebug){
	printf("CANSRVTSK:Wait released\n");
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"PASSWORD")){
      if(!strcmp(oTok.pGetToken(1),"CANsrvPASSWD")){
	bPasswordOk = 1>0;
      }
      else {
	if( pTask->nVerbose){
	  printf("CANSRV:Connected client did send a wrong password:%s\n",oTok.pGetToken(1));
	}
	bPasswordOk = 1<0;
      }
      if(!bPasswordOk){
	poClient->nWriteLine((char*)(bPasswordOk ? "TRUE":"FALSE"));
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"WAIT_CODE_MASK")){
      bool bOk=0;
      if(oTok.nGetTokens()==3){
	int nCode = oTok.lHexToLong(2);
	int nMask = oTok.lHexToLong(3);
	int nIndex = pStr->pCan->nWaitCanCodeMask(nCode,nMask);
	if(nIndex>0){  
	  Ccanmsg oMsg;
	  oMsg = pStr->pCan->oGetCanMsg(nIndex);
	  oMsg.pToClientText(&acBuff[0]);
	  poClient->nWriteLine(acBuff);
	  bOk = 1;
	}
      }
      if(!bOk){
	poClient->nWriteLine("FALSE");
      }
    }
    else if( !strcasecmp(oTok.pGetToken(0),"GET_DATABASE_ID_LIST")){
      if(pStr->pDB){
	//	printf("CANSRVTSK Database begin\n");
	char *pTxt = pStr->pDB->pMsgIdList();
	//printf("CANSRVTSK Database end\n");
	if(pTxt){
	  sprintf(acBuff,"DATABASE_ID_BEGIN %X",pStr->pDB->nGetIds());
	  poClient->nWriteLine(acBuff);
	  poClient->nWriteLine( pTxt);
	  printf("SENDING:%s TO CLIENT",pTxt);
	  poClient->nWriteLine("DATABASE_ID_END");
	}
	else {
	  strcpy(acBuff,"FALSE");
	  poClient->nWriteLine(acBuff);
	}
      }
      else {
	strcpy(acBuff,"FALSE");
	poClient->nWriteLine(acBuff);
      }
      if(pTask->nDebug)
	printf("Ccansrv::cmd:databaselist, list=%s\n",acBuff);
    }
    else if( !strcasecmp(oTok.pGetToken(0),"GET_DATABASE_STATUS")){
      if(pStr->pDB){
	sprintf(acBuff,"%s %d","DATABASE_STATUS_BEGIN", pStr->pDB->nGetIds());
	poClient->nWriteLine(acBuff);

	puts(pStr->pDB->pGetStatusText(acBuff));
	poClient->nWriteLine(acBuff);
	poClient->nWriteLine("DATABASE_STATUS_END");
      }
      else {
	strcpy(acBuff,"FALSE");
	poClient->nWriteLine(acBuff);
      }
      if(pTask->nDebug)
	printf("Ccansrv::cmd:databaselist, list=%s\n",acBuff);
    }
    else if( !strcasecmp(oTok.pGetToken(0),"FIFO_POLL_INTERVAL")){
      int nBeg = oTok.nToInt(1);
      int nNumbers = oTok.nToInt(2);
      if(nBeg<=0)
	nBeg += pStr->pDB->nGetFifoIndex();
    
       sprintf(acBuff,"FIFO_POLL_INTERVAL %d %d",nBeg, nNumbers);
       poClient->nWriteLine(acBuff);
       puts(acBuff);
       for (int n=0;n<nNumbers;n++){
	Ccanmsg oMsg;
	oMsg=pStr->pCan->oGetCanMsg(n+nBeg);
	oMsg.pToClientText(&acBuff[0]);
	poClient->nWriteLine(acBuff);
	//printf("%d:%s\n",n,oMsg.pToText());
      }
    }
    else if( oTok.bEqual(0,"FIFO_POLL")){
      int nBeg=pStr->pDB->nGetFifoIndex();
      for (int n=1;n<oTok.nGetTokens();n++){
	int nMsg = oTok.nToInt(n);
	if(nMsg<=0){
	  nMsg +=nBeg;
	}
	Ccanmsg oMsg;
	oMsg=pStr->pCan->oGetCanMsg(nMsg);
	oMsg.pToClientText(&acBuff[0]);
	poClient->nWriteLine(acBuff);
	//printf("%d:%s\n",nMsg,oMsg.pToText());
      }
    }
    else {
	printf("%s:Unknown command %s\n",pTask->acName, acBuff);
	poClient->nWrite("CANSERVER| Unknown command :");
	poClient->nWriteLine(acBuff);
    }
  }
  else if( nRead<0){
    nReturn =0;
  }
  sem_post(pStr->sSocketLock);
  return nReturn;
}


//////////////////////////////////////////////////////////////////////////
// NAME: CANSRV_CLIENT_TASK
//
// A thread that are running and serving one client!
//
// INPUT: Ccansrv*
/////////////////////////////////////////////////////////////////////////
void cansrv_client_task(void  *p) 
{
  Ccansrv *poCanSrv;
  poCanSrv= (Ccansrv*) p;
  short nStatus=1;
  printf("A new client has connected (nr: %d)\n",poCanSrv->nNr);
  while (nStatus){
    nStatus &=poCanSrv->nProceed()!=0;
    nStatus &=task_proceed(poCanSrv->psGetTaskStr())!=0;
  };
  if (poCanSrv->bImTheBoss){ //Release control
    sem_post(poCanSrv->pCanSrvStr->sImTheBoss);	
    printf("Nr %d have been relieved of his command!\n",poCanSrv->nNr);
  }
  printf("Client disconnected. (nr %d)\n",poCanSrv->nNr);
  delete poCanSrv;
  pthread_exit(0);
  return;
}

struct SHARED_CANSRV_DATA *getCanServer(struct SHARED_CANSRV_DATA *pStr)
{
  return pStr;
} 


//////////////////////////////////////////////////////////////////////////
// NAME:  InitCodeBeforeRealTime
//
// Initialize the SHARED_CANSRV_DATA struct that is shared by all client threads
// (Keeps pointers to several shared objects and semaphores).
// It also init the Task data in the EMPTY_TASK_STR
//
//sem_wait(pStr->sSocketLock);
  
// INPUT: EMPTY_TASK_STR*
//
// OUTPUT: SHARED_CANSRV_DATA
/////////////////////////////////////////////////////////////////////////
struct SHARED_CANSRV_DATA *CAN_InitCodeBeforeRealTime(struct EMPTY_TASK_STR *pTask)
{
  //////////////////
  //First the pTask
  //////////////////
  strcpy(pTask->acName,"CANSRVTSK");
  if(1){
    pTask->nVerbose =1;
    pTask->nDebug = 0;
  }
  pTask->nMode = TASK_FREE_RUNNING_MODE;
  
  ///////////////////////
  //Then the Shared data
  ///////////////////////
  struct SHARED_CANSRV_DATA *pStr = new struct SHARED_CANSRV_DATA;
  pStr->nMsgList=0;
  pStr->sSocketLock = new sem_t;
  pStr->sImTheBoss  = new sem_t;
  sem_init(pStr->sSocketLock,0,1);
  sem_init(pStr->sImTheBoss,0,1);
  
  pStr->pCan = NULL;
  while (pStr->pCan == NULL){
    usleep(10000);
    pStr->pCan=CAN_pGetDevicePtr(pTask->nTwinThreadNr);
  }     
  pStr->pDB = NULL;
  while (pStr->pDB == NULL){
    usleep(10000);
    pStr->pDB = pStr->pCan->pGetDBPtr();
  }
  return pStr;
}


//////////////////////////////////////////////////////////////////////////
// NAME: CANSRV_TASK
//
// Main void in this file that start a socket and listening to that one
// until a client is connected. It thens start a "ClientThread" for that
// connection and continous with listening for new sockets..
//
// INPUT: EMPTY_TASK_STR*
/////////////////////////////////////////////////////////////////////////
void cansrv_task( void *p)
{
  pthread_t *cansrv_thread;
  int nThread=1;
  struct EMPTY_TASK_STR  *pTask;
  pTask = (struct EMPTY_TASK_STR *) p;
  
  struct SHARED_CANSRV_DATA *pSharedData = CAN_InitCodeBeforeRealTime(pTask);
   
  CServer *poServer;
  CClientHandler *poClient;
  sleep(1);
  poServer = new CServer(pTask->nSocketPort>0 ? pTask->nSocketPort:nCanSrvSocket[pTask->nTwinThreadNr&0x03], pTask->acName);
  while((poClient = poServer->bAccept()) != NULL){
    Ccansrv *poCan = new Ccansrv(pTask, pSharedData, poClient, nThread++);
    cansrv_thread = new pthread_t;
    if (pthread_create(cansrv_thread, NULL,(void *(*) (void *))cansrv_client_task,(void*)poCan)){ 
    	printf("Error creating thread for new client!");
	nThread--;
	delete poClient;
    }
  }
  delete poServer;
};
