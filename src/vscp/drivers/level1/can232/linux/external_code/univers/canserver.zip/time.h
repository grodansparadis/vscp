#ifndef __CTIME_H
#define __CTIME_H
#include <sys/time.h>
#include <stdint.h>

class Ctime
{
  struct timeval sTime;
  int nMicroSec( void);
  int nGetMicroSeconds( void);

 public:
  Ctime( struct timeval *psTime=0);
  ~Ctime();
  
  Ctime *poClone(void);
  void CopyTimeval( struct timeval *psTime=0);
  void Set( struct timeval *psTime=0);
  void setAlarmOffset( long lOffset);
  long lToMilliSec(void);
  bool bAlarmMilli( int nMilliAlarmOffset=0);
  long lSec( void);
  long lGetSeconds( void);
  double rTime( void);
  double rGetTime( void);
  double rToSec( void);
  double rGetSystemTime( void);
  int64_t int64Time( void);
  long lNowAndMicroSecStep( void);
  void now( void);
  void Minus(Ctime & oTime);
  void Minus(Ctime *poTime);
  void Add(Ctime *poTime);
};


#endif


