function index=can_setmask(can)
     index=can.nGetFifoIndex;
