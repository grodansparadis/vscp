#ifndef __SEMAPHORE_H
#define __SEMAPHORE_H
#include <semaphore.h>

class Csemaphore 
{
  char acName[21];
  int nIndex;
  int nPost;
  int nWait;
  int nBeginValue;
  sem_t sLock;
  bool bInUse;
  bool bDebug;
  int nUseCnt;
  int nMaxDiff;
  
 public:
  Csemaphore( int nValue=1,bool bDebug=false, bool bInUse=true, char *pName=0);
  ~Csemaphore( void);
  void on(void);
  void off(void);
  void wait(void);
  void lock( void);
  void unlock( void);
  void Lock( void);
  void Unlock( void);
  void post(void);
  void Post( void);
  void Wait( void);
  void setName( char *p);
  void setMaxDiff( int nMaxDIff);
  bool bTryWait( void);
  int nGetValue( void);
};



#endif
