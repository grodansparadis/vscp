#ifndef __THREADEDSERVER_H
#define __THREADEDSERVER_H
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <iostream.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>




////////////////////////////////////////////////////////////
// CLIENT HANDLER CLASS
//
// Class to read and write data from a socket that already
// is connected! IT CLOSES THE SOCKET ON DESTRUCT!!!!!
////////////////////////////////////////////////////////////
class CClientHandler
{
  int nPort;
  int client_sockfd; 
  socklen_t client_len;
  struct sockaddr_in client_address;

 public:
  CClientHandler(int sockfd);           //create client with socket sockfd
  ~CClientHandler();                  //destructor
  
  int nReadChar( void);            //read a byte from server socket
  int nRead( void);
  int nRead( char *p);
  int nRead( char *pMessage, int nMsglenght);//read a string from server socket
  int nWrite( char *pMessage, int nMsglenght);//write a string to server socket
  int nWriteChar( char c);//write a byte to the server socket
  int nWrite( char c);
  int nWrite( char *p);
  int nWriteStr( char *p);
  int nWriteLine(char *p);
  int nPutLine(char *p);
  int nGetUntil( char *p, int nMax=0, int cEnd=0);
  int nGetStr( char *p, int nMax=0);
  int nGetLine( char *p, int nMax=0);
  bool bIsValid( void);
  int nGetNetAddr( void);
  unsigned short int nGetPort( void);
  void PrintAddrPort( void);
  void SetData(struct sockaddr_in addr, socklen_t len)
    {client_address=addr;client_len = len;}              
};

////////////////////////////////////////////////////////////
// SERVER CLASS
//
// Starts and listening to a socket. bAccept creates a
// client class with the new connection and returns a pointer to it.
////////////////////////////////////////////////////////////
class CServer
{
  char *pText;
  int nPort;
  int server_sockfd;
  int server_len;
  bool bVerbose;
  struct sockaddr_in server_address;

 public:
  CServer(int port, char *pText="",bool bVerbose=true);           //start server at port 
  ~CServer();                  //destructor
  
  void init(int nPort);
  CClientHandler *bAccept( void);
  CClientHandler oAccept( void);
 };


#endif
































