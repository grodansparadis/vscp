function r=sleep(MilliSeconds)
% sleep( MilliSeconds)
%
o=Diverse;
o.sleepMilli(MilliSeconds);
