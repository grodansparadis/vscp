#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "tokenizer.h"

Ctokenizer::Ctokenizer(void)
{
  init();
}

Ctokenizer::Ctokenizer( char *p)
{
  init();
  Tokenize(p);
}

bool Ctokenizer::bEqual( int n, char *p)
{
  bool bReturn = false;
  if((n<nTokens) && p){
    bReturn = !strcmp(pGetToken(n),p);
  }
  return bReturn;
}


Ctokenizer::Ctokenizer( int nArgs, char *pArgv[])
{
  int nLen = 0;
  for (int n=0;n<nArgs;n++){
    nLen += strlen(pArgv[n])+2;
  }
  char *p =new char[nLen+128];
  char *pBegin = p;
  for (int n=0;n<nArgs;n++){
    strcpy(p, pArgv[n]);
    p = &p[strlen(p)];
    *(p++)=' ';
    *p=0;
  }
  init();
  Tokenize(pBegin);
  delete pBegin;
}

void  Ctokenizer::init( void)
{
  pText = 0;
  apToken = 0;
  pnLineArg = 0;
  nLines = 0;
  nTokens =0;
  nTokenAllocSize = 0;
  nTextSize = 0;
  nTextAllocSize = 0;
  nLineArgAllocSize =0;
}

int Ctokenizer::hextoi( char c)
{
  c=toupper(c);
  return (c>='A') ? (c-'A'+10):(c-'0');
}

int Ctokenizer::nToInt(int nToken)
{
  return ((nToken>=0) && (nToken<nTokens)) ? atoi(pGetToken(nToken)):0;
}

bool Ctokenizer::bToBool( int nToken)
{
  return nToInt( nToken)!=0;
}


long Ctokenizer::lToLong(int nToken)
{
  return ((nToken>=0) && (nToken<nTokens)) ? atol(pGetToken(nToken)):0;
}


long Ctokenizer::lHexToLong( int nToken)
{
  return lHexToLong(pGetToken(nToken));
}


long Ctokenizer::lHexToLong( char *p)
{
  bool bNeg=false;
  long l=0;
  if(p){
    while(*p && (*p=='-')){
      bNeg = !bNeg;
      p++;
    }
    while(*p){
      l<<=4;
      if(isxdigit(*p))
	l+=hextoi(*p);
      else 
	break;
      p++;
    }
  }
  return bNeg ? -l:l;
}


int Ctokenizer::nGetLines( void)
{
  return (signed)nLines;
}

int Ctokenizer::nGetTokens( void)
{
  return (signed)nTokens;
}

int Ctokenizer::nGetLineTokens( int nLine)
{
  return nLine < nLines ? (pnLineArg[nLine+1]-pnLineArg[nLine]):0;
}

char * Ctokenizer::pGetToken( int nToken)
{
  return (nToken < nTokens) ? apToken[nToken]:0;
}

char * Ctokenizer::pGetLineToken(int nLine,int nToken)
{
  char *p=0;
  if(nLine<nLines){
    int n;
    n=pnLineArg[nLine];
    n +=nToken;
    if(n<nTokens && (n < pnLineArg[nLine+1]))
      p=apToken[n];
  }
  return p;
}

bool Ctokenizer::bIsSpace(char c)
{
  return (c==' ')||(c==0x0d)||(c=='\t')||(c==0x0a);
}


void Ctokenizer::TokenizeFile( char *pFile)
{
#define BSIZE 50000
  if(pFile){
    char *pMyText = (char *) new char[BSIZE+1];
    if ( pMyText){
      FILE *f;
      f = fopen(pFile,"r");
      if(f){
	pMyText[0]=0x00;
      	fread(pMyText,BSIZE,1,f);
	fclose(f);
	//printf("Read %d bytes from %s\n",strlen(pMyText),pFile);
	pMyText[BSIZE]=0x00;
	if(strlen(pMyText)>0){
	  Tokenize(pMyText);
	}
	//	puts(pMyText);
	delete pMyText;
	//    puts(pText);
      }
    }
  }
}


int Ctokenizer::nFindToken( char *pToken, int nOffset)
{
  int nRetToken=-1;
  if((pToken!=0) && (nTokens>0)){
    int n=0;
    while(nOffset<0)
      nOffset +=nTokens;
    for (n=nOffset;n<nTokens;n++)
      if(!strcmp( pToken, apToken[n]))
	break;
    nRetToken = (n == nTokens) ? -1:n;
  }
  return nRetToken;
}


void Ctokenizer::Tokenize( char *pInText)
{
  nLines = 0;
  nTokens = 0;
  nTextSize = 0;
  if(pInText){
    nTextSize = strlen(pInText)+1;
    if (nTextSize > nTextAllocSize){
      if(pText)
	delete pText;
      nTextAllocSize = nTextSize;
      pText = (char *) new char[ nTextAllocSize];
    }
    if(pText){
      memcpy(pText,pInText,nTextSize);
      nLines=0;
      for (char *p=pText;*p;p++){
	if(*p==0x0a)
	  nLines++;
      } 
      // printf("Tokenizing:");
      for (int n=0;n<2;n++){
	//	printf("Entering loop:%d\n",n);
	nLines =0;
	nTokens=0;
	for (char *p=pText;*p;){
	  //printf("+");
	  for(;*p && bIsSpace(*p);p++){
	    if(!n && *p==0x0a){
	      nLines++;
	    }
	    else if(n==1){
	      if(*p==0x0a)
		pnLineArg[nLines++]=nTokens;
	      *p=0x00;
	    }
	  }
	  if(n==1)
	    apToken[nTokens]=p;
	  nTokens++;
	  for(;*p && !bIsSpace(*p);p++);
	}
	//printf("loop %d\n",n);
	if(n==0){
	   int unAllocSize;
	  unAllocSize = (nLines+10);
	  if( unAllocSize > nLineArgAllocSize){
	    if(pnLineArg)
	      delete pnLineArg;
	    nLineArgAllocSize = unAllocSize;
	    pnLineArg = ( int *) new int[ nLineArgAllocSize];
	  }  
	  unAllocSize = (nTokens+10);
	  if(unAllocSize > nTokenAllocSize){
	    if(apToken)
	      delete apToken;
	    nTokenAllocSize = unAllocSize;
	    apToken = (char**) new char *[ nTokenAllocSize];
	  }
	  if(!apToken || !pnLineArg){
	    printf("Error allocating in tokenizer\n");
	    exit(0);
	  }
	}
      }
      pnLineArg[nLines]=nTokens;
    }
  }
}

double Ctokenizer::rToDouble(int n )
{
  double rNumber=0.0;
  if((n>=0) && (n<nTokens)){
    rNumber = atof(apToken[n]);
    /*
    char *p=strchr(apToken[n],'E');
    if(!p)
      p=strchr(apToken[n],'e');
    if(p){
      double rExp=atof(&p[1]);
      printf("TOKENIZER_rToDouble: Exp:%f  rNumber:%f\n",rExp,rNumber);
      rNumber *=pow(10.0,rExp);
    }
    */
  }
  return rNumber;
}

void Ctokenizer::Show()
{
  printf("TOKENS:");
  for(int n =0;n<nTokens;n++){
    printf("<%.2d|%s>",n,pGetToken(n));
  }
  printf("\n");
}


Ctokenizer::~Ctokenizer(void)
{
  if(apToken)
    delete apToken;
  if(pText)
    delete pText;
  if(pnLineArg)
    delete pnLineArg;
}
