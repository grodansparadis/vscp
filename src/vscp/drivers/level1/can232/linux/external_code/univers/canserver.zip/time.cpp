#include "time.h"
#include <string.h>

Ctime::Ctime( struct timeval *psTimeVal)
{
  Set( psTimeVal);
}

 
void Ctime::Set( struct timeval *psTimeVal)
{
  if (!psTimeVal)
    now();
  else 
    memcpy(&sTime,psTimeVal,sizeof(struct timeval));
}

Ctime::~Ctime()
{
}

void Ctime::CopyTimeval( struct timeval *psTime)
{
  if(psTime){
    memcpy(psTime,&sTime,sizeof(struct timeval));
  }
}


Ctime * Ctime::poClone( void)
{
  return new Ctime(&sTime);
}

void Ctime::now( void)
{
  gettimeofday(&sTime,0);
}

long Ctime::lNowAndMicroSecStep( void)
{
  int nSec =-sTime.tv_sec; 
  int nMicroSec =-sTime.tv_usec;
  now();
  nSec +=sTime.tv_sec; 
  nMicroSec +=sTime.tv_usec;
  if(nMicroSec<0){
    nSec--;
    nMicroSec +=1000000;
  }
  return ((long)nSec)*1000000+nMicroSec;
}

long Ctime::lToMilliSec( void)
{
  return  sTime.tv_sec*1000+(sTime.tv_usec+500)/1000; 
}

int64_t Ctime::int64Time( void)
{
  int64_t n64=sTime.tv_sec;
  n64 *=1000000;
  n64 +=sTime.tv_usec;
  return n64;
}

bool Ctime::bAlarmMilli( int nMilliSecOffset)
{
  struct timeval sTimeNow;
  gettimeofday(&sTimeNow,0);
  long lMicroSec = (sTimeNow.tv_sec-sTime.tv_sec)*1000000;
  lMicroSec +=sTimeNow.tv_usec-sTime.tv_usec;
  return ((lMicroSec+500)/1000) > nMilliSecOffset;
}

long Ctime::lSec( void)
{
  return sTime.tv_sec;
}

long Ctime::lGetSeconds( void)
{
  return sTime.tv_sec;
}

double Ctime::rGetSystemTime( void)
{
  now();
  return rToSec();
}

double Ctime::rTime( void)
{
  return rToSec();
}

double Ctime::rGetTime( void)
{
  return rToSec();
}


double Ctime::rToSec( void)
{
  double r = sTime.tv_usec;
  r *=(1.0/1000000.0);
  r +=(double)sTime.tv_sec;
  return r;
}

#include <stdint.h>
int Ctime::nMicroSec( void)
{
  return (int)sTime.tv_usec;
}

int Ctime::nGetMicroSeconds( void)
{
  return (int)sTime.tv_usec;
}

void Ctime::Minus( Ctime & oTime)
{
  sTime.tv_sec -= oTime.lSec();
  sTime.tv_usec -= oTime.nMicroSec();
  if(sTime.tv_usec<0){
    sTime.tv_usec +=1000000;
    sTime.tv_sec--;
  }
  return;
}

void Ctime::Minus( Ctime *poTime)
{
  if(poTime){
    sTime.tv_sec -= poTime->lSec();
    sTime.tv_usec -= poTime->nMicroSec();
    if(sTime.tv_usec<0){
      sTime.tv_usec +=1000000;
      sTime.tv_sec--;
    }
  }
  return;
}

void Ctime::Add( Ctime *poTime)
{
  if(poTime){
    sTime.tv_sec += poTime->lSec();
    sTime.tv_usec += poTime->nMicroSec();
    if(sTime.tv_usec>=1000000){
      sTime.tv_usec -=1000000;
      sTime.tv_sec++;
    }
  }
  return;
}
/*
void main( void)
{
  double r;
  struct timeval tm;
  gettimeofday( &tm, NULL); 
  r = tm.tv_sec+tm.tv_usec/1000000.0;
  return r;
}
*/
