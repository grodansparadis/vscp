#include "canmsg.h"
#include <stdio.h>
#include <stdlib.h>
#include "Cinteger.h"
#include <string.h>
//#include "tokenizer.h"

#define C_max(a,b) (a)>(b) ? (a):(b)
#define C_min(a,b) (a)<(b) ? (a):(b)

extern char *pIntToHex(char *p, unsigned int n,unsigned int nDecTal);
extern char *pIntToDec(char *p, unsigned int n,unsigned int nDecTal);

Ccanmsg::Ccanmsg( Ccanmsg & oMsg)
{
  pTxt=0;
  init( &oMsg.sMsg,oMsg.nIndex);
}

Ccanmsg::Ccanmsg( Ccanmsg *poMsg)
{
  pTxt=0;
  if(poMsg)
    init( &poMsg->sMsg,poMsg->nIndex);
  else 
    init(0,0);
}


Ccanmsg::Ccanmsg()
{
  pTxt=0;
  init(0,0);
}

Ccanmsg::Ccanmsg( Ctokenizer *poTok, int nTokenOffset)
{
  pTxt =0;
  init(0,0);
  if(poTok!=0){
    poTok->Show();
    bSet = true;
    for (int i=nTokenOffset;i<poTok->nGetTokens();){
      if(poTok->bEqual(i,"ID")){
	sMsg.id =(int) poTok->lHexToLong( i+1);
	i+=2;
      }
      else if(poTok->bEqual(i,"I")){
	nIndex=(int) poTok->lHexToLong( i+1);
	i+=2;
      }
      else if(poTok->bEqual(i,"L")){
	sMsg.length=poTok->lHexToLong( i+1);
	i +=2;
      }
      else if(poTok->bEqual(i,"T")){
	sMsg.timestamp.tv_sec=poTok->lHexToLong( i+1);
	sMsg.timestamp.tv_usec=poTok->lHexToLong( i+2);
	i +=3;
      }
      else if(poTok->bEqual(i,"DA")){
	i++;
	for (int n=0;(n<sMsg.length);n++){
	  sMsg.data[n]=(unsigned char)poTok->lHexToLong( i++);
	}
      }
      else {
	printf("CANMSG:Unknown token %s",poTok->pGetToken(i++));
     }
    }
  }
}

/*
Ccanmsg::Ccanmsg(char *p)
{
}
*/

Ccanmsg::Ccanmsg(int nId, int nLen, unsigned char *p, int nIndex)
{
  pTxt=0;
  init(nId,nLen,p,nIndex);
}
/*
Ccanmsg::Ccanmsg(Ccanmsg oCanMsg)
{
  oCanMsg.copyTo(&sMsg);
  nIndex = oCanMsg.nGetIndex();
}
*/
Ccanmsg::Ccanmsg(canmsg_t *pMsg,  int nIndex)
{
  pTxt=0;
  init(pMsg,nIndex);
}

Ccanmsg Ccanmsg::oClone( void)
{
  Ccanmsg oCanMsg(&sMsg,nIndex);
  return oCanMsg;
}

Ccanmsg * Ccanmsg::poClone( void)
{
  return new Ccanmsg( &sMsg, nIndex);
}


bool Ccanmsg::bIsSet( void)
{
  return bSet;
}

int Ccanmsg::nGetId( void)
{
  return sMsg.id;
}

int Ccanmsg::nGetIndex( void)
{
  return nIndex;
}

void Ccanmsg::CopyTo( canmsg_t *p)
{
  if(p){
    memcpy(p,&sMsg,sizeof(sMsg));
  }
}

canmsg_t * Ccanmsg::pGetMsgPtr( void)
{
  return &sMsg;
}


void Ccanmsg::init(int nId, int nLen, unsigned char *p, int nIndex)
{
  bDebug =1>0;
  pTxt =0;
  gettimeofday(&sMsg.timestamp,0);
  sMsg.id = nId;
  sMsg.length = nLen<8 ? nLen:8;
  if(bDebug && (nLen>8)){
    printf("CANMSG:Error len=%d, id=%X\n",nLen,nId);
  }
  this->nIndex = nIndex;
  for (int n=0;n<sMsg.length;n++)
    sMsg.data[n]=p[n];
  bSet = true;
}

void Ccanmsg::init( canmsg_t *pMsg, int nIndex)
{
  bSet = false;
  if(pMsg){
    bSet = true;
    memcpy(&sMsg,pMsg,sizeof(canmsg_t));
  }
  this->nIndex = nIndex;
}

Ccanmsg::~Ccanmsg()
{
  if(pTxt)
    delete pTxt;
}

/*
char * Ccanmsg::pToHexStr()
{
  return pToHexStr(p,&sMsg,nIndex);
}
*/


void Ccanmsg::SetIndex( int n)
{
  nIndex = n;
}



char * Ccanmsg::pToText(char *p)
{
  char *pBeg=0;
  canmsg_t *pMsg = &sMsg;
  if(!p){
    if(!pTxt)
      pTxt=new char[200];
    p=pTxt;
  }
  if(p){
    pBeg = p;
    p[0]=0;
    if(bSet){
      sprintf(p,"T=%.4f I=%.7d ID=%.8X L=%d  D=",rGetTimeStamp(), (int)nIndex, (int)pMsg->id,(int) pMsg->length);
      for(;*p;p++);
      int nLen = ( pMsg->length<=8) ? pMsg->length:0;
      for (int n=0;n<nLen;n++){
	oInt.set(pMsg->data[n]);
	oInt.pToHex(2,&p[0]);
	p+=2;
	*(p++)=' ';
	*p=0;
      }
    }
    else
      sprintf(p,"FALSE");
    // printf("CANMSG_ptText:%s\n",pBeg);
  }
  else 
    strcpy(p,"canmsg error");
  return pBeg;
}



char * Ccanmsg::pToClientText(char *p)
{
  char *pBeg=0;
  canmsg_t *pMsg = &sMsg;
  if(!p){
    if(!pTxt)
      pTxt=new char[200];
    p=pTxt;
  }
  if(p){
    char cSep=' ';
    pBeg = p;
    p[0]=0;

    strcpy(p,"HEX");
    for(;*p;p++);
    *(p++)=cSep;
    *(p++)='T';
    *(p++)=' ';
    *p=0;
    oInt.set(pMsg->timestamp.tv_sec);
    oInt.pToHex(8,&p[0]);
    p+=8;
    for(;*p;p++);
    *(p++)=' ';
    *p=0;
    oInt.set(pMsg->timestamp.tv_usec);
    oInt.pToHex(5,&p[0]);
    for(;*p;p++);
    *(p++)=cSep;
    *p=0;
    
    strcpy(p,"I ");
    for(;*p;p++);
    oInt.set(nIndex);
    oInt.pToHex(8,p);
    for(;*p;p++);
    *(p++)=cSep;
    *p=0;
    strcpy(p,"ID ");
    for(;*p;p++);
    oInt.set(pMsg->id);
    oInt.pToHex(8,&p[strlen(p)]);
    for(;*p;p++);
    *(p++)=cSep;
    *p=0;
    //    printf("Length:%d\n",pMsg->length);
    int nLen = ( pMsg->length<=8) ? pMsg->length:0;
    strcpy(p,"L ");
    for(;*p;p++);
    *(p++)=nLen+'0';
    *(p++)=cSep;
    *p=0;
    //printf("Message:%s\n",pBeg);
    
    strcpy(p,"DA");
    for(;*p;p++);
    for (int n=0;n<nLen;n++){
      *(p++)=' ';
      oInt.set(pMsg->data[n]);
      oInt.pToHex(2,&p[0]);
      p+=2;
      *p=0;
    }
    *p=0;
   }
  else 
    strcpy(p,"canmsg error");
  return pBeg;
}

int Ccanmsg::nData( int nIndex)
{
  return (nIndex <= sMsg.length) ? ((int)sMsg.data[ nIndex])&0xff:-1;
}

long Ccanmsg::lGetSeconds( void)
{
  return bSet ? sMsg.timestamp.tv_sec:0;
}

long Ccanmsg::lGetMicroSeconds( void)
{
  return bSet ? sMsg.timestamp.tv_usec:-1;
}

double Ccanmsg::rGetTimeStamp( void)
{
  double r = -1.0;
  if(bSet){
    r=(double) lGetMicroSeconds();
    r *=(1.0/1000000.0);
    r +=(double)lGetSeconds();
  }
  return r;
}


long Ccanmsg::lDiffMilliSeconds( Ccanmsg *poCan)
{
  long lSec = lGetSeconds()-(poCan ? poCan->lGetSeconds():0);
  long lMicroSec = lGetMicroSeconds()-(poCan ? poCan->lGetMicroSeconds():0);
  if(lMicroSec>=1000000){
    lSec++;
    lMicroSec -= 1000000;
  }
  if(lMicroSec<=-1000000){
    lSec--;
    lMicroSec += 1000000;
  }
  return lSec*1000+(lMicroSec+500)/1000; 
}

