function can232=can232_init(host,port)
   h=java.lang.String(host);
   p=java.lang.Integer(port);
   can232=Can232Class
   can232.init(h,p)
   
