#ifndef __SERVER_H
#define __SERVER_H
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <iostream.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAX_CLIENTS 50

class Cserver
{
  int nPort;
  int nConnectedClients;
  int client_sockfd;
  int server_sockfd; // client_sockfd;
  int server_len;
  socklen_t client_len;
  struct sockaddr_in server_address;
  struct sockaddr_in client_address;

 public:
  Cserver(int port);           //start server at port 
  ~Cserver();                  //destructor
  
  void init(int nPort);
  bool bAccept( void);
  int nReadChar( void);            //read a byte from server socket
  int nRead( void);
  int nRead( char *p);
  int nRead( char *pMessage, int nMsglenght);//read a string from server socket
  int nWrite( char *pMessage, int nMsglenght);//write a string to server socket
  int nWriteChar( char c);//write a byte to the server socket
  int nWrite( char c);
  int nWrite( char *p);
  int nWriteStr( char *p);
  int nWriteLine(char *p);
  int nPutLine(char *p);
  int nGetUntil( char *p, int nMax=0, int cEnd=0);
  int nGetStr( char *p, int nMax=0);
  int nGetLine( char *p, int nMax=0);
  bool bConnected( void);
  void Close( void);                 //Close the socket  
};

#endif
































