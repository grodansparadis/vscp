/*  Make the necessary includes and set up the variables.  */
//testserver.cpp
#include <string.h>
#include "server.h"


Cserver::Cserver(int nPort)
{ 
  init(nPort);
}

void Cserver::init( int nPort)
{

  printf("\nOpens port socket:%d\n", nPort);
  this->nPort = nPort;

  /*  Remove any old socket and create an unnamed socket for the server.  */
  
  server_sockfd = socket(AF_INET, SOCK_STREAM, 0);

  /*  Name the socket.  */
  
  server_address.sin_family = AF_INET;
  server_address.sin_addr.s_addr = htonl(INADDR_ANY);
  server_address.sin_port = htons(nPort);
  server_len = sizeof(server_address);
  bind(server_sockfd, (struct sockaddr *)&server_address, server_len);
  
  /*  Create a connection queue and wait for clients.  */
  
  listen(server_sockfd, 5);
}


bool Cserver::bAccept( void)
{
  
  printf("server waiting for connection\n");
  client_len = sizeof(client_address);
  client_sockfd = accept(server_sockfd, 
			 (struct sockaddr *)&client_address, &client_len);
  
  /*  We can now read/write to client on client_sockfd.  */
  printf("Client connected\n");
  return client_sockfd >=0;
}

Cserver::~Cserver() //destructor
{
  Close();
}

int Cserver::nRead( void)
{
  return nReadChar();
}

int Cserver::nReadChar(void) //read byte form socket
{
  unsigned char inmessage;
  int n;
  n=read(client_sockfd, &inmessage, 1);
  return (n>0)? ((int)inmessage)&0xff:-1;
}

int Cserver::nGetLine( char *p, int nMax)
{
  int n=0;
  for (n=0;p && ((n< nMax) || (nMax==0));n++){
    int c;
    p[n]=0x00;
    c = nReadChar();
    if((c==0x0d)||(c==0x0a)){
      break;
    }
    else if (c<0){
      n=-1;
      break;
    }
    p[n]=c;
  }
  //  printf("Break");
  return n;
}


bool Cserver::bConnected( void)
{
  return client_sockfd>=0;
}


int Cserver::nGetStr( char *p, int nMax)
{
  return p ? nGetUntil(p,nMax,0x00):0;
}


int Cserver::nGetUntil( char *p, int nMax,int cEnd)
{
  int n=0;
  for (n=0;p && ((n< nMax) || (nMax==0));n++){
    int c;
    p[n]=0x00;
    c = nReadChar();
    if(c==cEnd){
      break;
    }
    else if (c<0){
      n=-1;
      break;
    }
    p[n]=c;
  }
  return n;
}

int Cserver::nRead(char *pMessage, int nMsglenght) //read string from socket
{
  int n=0;
  if(pMessage){
    char c;
    if (nMsglenght==0)
      while((read(client_sockfd, &c, 1)==1)&&(c != '\0'))
	{
	  pMessage[n++]=c;
	  pMessage[n]=0x00;
	}
    else 
      n=read(client_sockfd, pMessage, nMsglenght);
  }
  return n;  

}


int Cserver::nWriteStr( char *p)
{
  return p ? nWrite(p,strlen(p)+1):0;
}


int Cserver::nWriteLine( char *p)
{
  int nRet=0;
  if(p){
    nRet =nWrite(p);
    if(nRet>=0){
      nRet+=nWrite("\n",1);
    }
  }
  return nRet;
}

int Cserver::nWrite(char *p)
{
  return p ? nWrite(p,strlen(p)):0;
}


int Cserver::nPutLine( char *p)
{
  return nWriteLine(p);
}


int Cserver::nWrite( char c)
{
  return write(client_sockfd, &c, 1);
}


int Cserver::nWriteChar(char message) //write a byte to socket
{
  return write(client_sockfd, &message, 1);
}

int Cserver::nWrite(char *pMessage, int nMsglenght) //write a string to socket
{ 
  return pMessage ? write(client_sockfd, pMessage, nMsglenght):0;
}

void Cserver::Close( void)          //close the socket
{
  if(client_sockfd>=0){
    close(client_sockfd);
    client_sockfd =-1;
  }
  printf("Client disconnected, closing socket:%d\n",nPort);
}
















