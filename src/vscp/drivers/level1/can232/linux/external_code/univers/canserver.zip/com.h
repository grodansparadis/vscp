#ifndef defCsercom
#define defCsercom
#include <stdio.h>
#include <stdlib.h>
#include "semaphore.h"

/*

Verson 0.79


*/


#define SERIAL_TIMEOUT 20 /* timeout in 10ths of seconds */
#define STX 0x02           /* start text */
#define ETX 0x03           /* end text */
#define ACK 0x06

#define SERCOM_MAXSIZEOFARRAY 1024



class Csercom
{
  Csemaphore oLock232;

  double rLogOpenTime;
  struct LOGSTR { 
    double rTime;
    int nSize; } sLog;
  int nArrayIndex;
  char cArray[SERCOM_MAXSIZEOFARRAY];


  int nInBaud;
  int nOutBaud;
  int nBits;
  int nStopBits;
  int nPort;
  int nFileDes;
  bool bPortIsOpen;
  bool bLog;
  bool bReadLog;
  bool bWaitAccordingToLog;
  FILE *pfLog, *pfReadLog;
  
  double rGetSystemTime();


 public:
  Csercom( int nPort, int nInputBaudRate, int nOutputBaudRate=-1);
  Csercom( char *pLogFileName,int nPort, int nInputBaudRate, int nOutputBaudRate=-1);
  Csercom( char *pcReadFromLog);
  ~Csercom(); 

  bool bInit( void);
  bool bClose(void);
  int nReadByte( void);
  bool bSendByte( char cByte);
  bool bSendChar( char cByte);
  bool bWaitByte( char cByte);
  void vWaitAccordingToLog(void);
  void vWaitAccordingToLogOn( void);
  void vWaitAccordingToLogOff( void);
  int  nWrite( char c);
  int  nWrite( char *pcArr, int n=0);
  char cRead( void);
  int  nRead( void);
  int  nReadChar(void);
  int  nRead( char *pcArr, int n);
  int  nReadLine( char *p, int n);
  int  nReadNextLineFromLog( void);
  int  nReadDataFromLog( char *pcArr, int n);
  void NonBlockingMode( void);
  void BlockingMode( void);
  bool bSetBaudrate( int nIn, int nOut=-1);
  bool bSetStopBits( int n);
  bool bSetBits( int n);
  int nGets( char *p, int nMax);
  int nPutLine( char *p);
  int nPuts( char *p);
  int nGetByteArr( char *p, int nMax, int nTermByte);
  int nGetDes( void);
  void vLoggingOn( char *pc);
  void vLoggingOff( void);
  bool bReadFromLogOn( char *pc);
  void vReadFromLogOff( void);
  void vStoreLogData( char *pc, int nLength);
  int nReadLogData( char *pc);
};

#endif



