function [ids,len,t,msgs]=can_listcanids(can)
     a=double(can.aanListCanIds);
     msgs=(a(:,[5:14]));
     ids=(a(:,[1]));
     t=(a(:,[3]))+(a(:,[4]))/1000000.0;
     len=(a(:,[2]));
   
