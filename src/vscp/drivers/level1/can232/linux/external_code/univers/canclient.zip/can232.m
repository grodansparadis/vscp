function c=can232(host,port);
c=can232_init(host,port);
v=can232_version(c); 
can232_close(c);
