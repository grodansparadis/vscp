//***********************************************************************
//**
//** File:			CanClient.java
//**
//** Description:   Includes the class CanClient that is a wrapper
//**                for the SerialClientclass and includes function
//**                to send and recieve specific data from the
//**                canserver. 
//**
//** Author:		Sven R�nnb�ck and a Robotic project group
//**                (EISLAB, LULE� UNIVERISTY OF TECHNOLOGY)
//**
//**
//**
//**
//**
//** Created:	 2003-??-??
//**
//** Modified:   * 2003-03-08 David R, Created this header, implemented a 
//** 						  isConnected function, fixed some minor bugs. 
//**
//**             * 2003-03-11 David R, implemented connect functions instead
//**                          of having init on create.  
//**
//***********************************************************************
import java.io.*;
import java.net.*;
import java.util.*;


public class CanClient
{
    SerialClientClass pCom = new SerialClientClass();

    long lPollCnt=0;
    int nElements=0;
    int nHead=0;
    int nTail=0;
    int nId[]=new int[200];
    int nLen[]=new int[200];
    byte aabFifo[][]=new byte[200][13];
    ////////////////////////////////////////////
    // Standard constructor and connect functions
    // Do NOT touch! 
    //////////////////////////////////////////// 
    public CanClient()
    {
    }
    
    public CanClient(String sHost, int nPort)
    {
	init(sHost,nPort);
    }
  
    public boolean connect()
    {
	return pCom.init("rullstol.sm.luth.se",9009);
    }

    public boolean bConnect()
    {
	return connect();
    }
    
    public boolean connect(int nPort)
    {
	return pCom.init("rullstol.sm.luth.se",nPort);
    }
    
    public boolean connect(String sHost,int nPort)
    {
	return pCom.init(sHost,nPort);
    }
    
    public boolean isConnected()
    {
	return pCom.isConnected();	
    }

    public boolean bIsConnected()
    {
	return pCom.isConnected();	
    }

    public void disconnect( )
    {
	pCom.disconnect();
    }
    ////////////////////////////////////////////
    // END Standard functions
    ////////////////////////////////////////////   
    
    
  
    public boolean init(String sHost,int nPort)
    {
	return pCom.init(sHost,nPort);
    }
        
    
    public int nGetFifoIndex()
    {
	int nIndex =0;
	if(bIsConnected()){
	    pCom.putLine("GET_MAX_INDEX");
	    String s=pCom.getLine();
	    //System.out.println(s);
	    s=s.substring(s.indexOf(' ')+1);
	    nIndex=Integer.valueOf(s).intValue();
	}
	return nIndex;
    }
    
    
    public boolean bSetAcceptanceMask( int nMask)
    {
	
	boolean bReturn = false;
	if(bIsConnected()){
	    pCom.putLine("SET_MASK "+nMask);
	    String s=pCom.getLine();
	    //System.out.println(s);
	    bReturn = s.equals("TRUE");
	}
	return bReturn;
    }
    
    public boolean bSetAcceptanceCode( int nMask)
    {
	boolean bReturn = false;
	if(bIsConnected()){
	    pCom.putLine("SET_CODE "+nMask);
	    String s=pCom.getLine();
	    //System.out.println(s);
	    bReturn = s.equals("TRUE");
	}
	return bReturn;
    }
    
    


    public int[][] aanGetIdList(int nId, int nElements, int nStartPos)
    {
	int aan[][]=null;
	if(bIsConnected()){
	    CanMsg ao[] = aoGetIdList( nId, nElements, nStartPos);
	    if(ao!=null){
		aan=new int[ao.length][12];
		for (int n=0;n<ao.length;n++){
		    aan[n] = ao[n].toIntArray();
		}
	    }
	}
	return aan;
    }

    public CanMsg[] aoGetIdList(int nId,int nElements,int nStartPos)
    {
 	CanMsg aCan[] = null;
	if(bIsConnected()){
	    aCan=new CanMsg[ nElements];
	    String s=null;
	    Hex2Dec oId = new Hex2Dec( nId);
	    Hex2Dec oElements = new Hex2Dec( nElements);
	    Hex2Dec oStartPos = new Hex2Dec( nStartPos);
	    s="GET_ID_LIST "+oId.sToHexStr(8)+" "+oElements.sToHexStr(4)+" "+oStartPos.sToHexStr(5);
	    pCom.putLine(s);
	    int n=0;
	    do {
		s=pCom.getLine();
		if(s.equals("FALSE")){
		    aCan=null;
		    break;
		}
		else if(!s.equals("GET_ID_LIST_END")){
		    //System.out.println(n+"|GOT LINE:"+s);
		    if(n<nElements)
			aCan[n++] = new CanMsg(s);
		}
	    } while(!s.equals("GET_ID_LIST_END"));
	    if(n<nElements){
		CanMsg aNewCan[]=new CanMsg[n];
		for (int i=0;i<n;i++){
		aNewCan[i] = aCan[i];
		}
		aCan = aNewCan;
	    }
	    //s=s.substring(s.indexOf(' ')+1);
	    //int nIndex=Integer.valueOf(s).intValue();
	}
	return aCan;
    }

    public int[] anGetById( int nId)
    {
	int an[]=null;
	if(bIsConnected()){
	    CanMsg oCan=null;
	    oCan=oGetById( nId);
	    if(oCan!=null)
		an = oCan.toIntArray();
	}
	return an;
    }

    //public int[] wait //To be implemented





    public CanMsg oGetById(int nId)
    {
 	CanMsg oCan=null;
	if(bIsConnected()){
	    String s=null;
	    Hex2Dec oH2I = new Hex2Dec(nId);
	    //	System.out.println("CanId-----------:");
	
	    pCom.putLine("GET_ID "+oH2I.sToHexStr(8));
	    s=pCom.getLine();
	    //System.out.println("oGetById|Server Responce:"+s);
	    if(!s.equals("FALSE")){
	    oCan=new CanMsg(s);
	    }
	    else {
		System.out.println("oGetById|error Id not found"+s);
	    }
	}
	return oCan;
    }


    public int[][] aanListCanIds()
    {
   	CanMsg ao[] = aoListCanIds();
	int aan[][]=new int[ao.length][14];
	for (int n=0;n<ao.length;n++){
	    int an[] =ao[n].toIntArray();
	    aan[n][0]=ao[n].nGetId();
	    aan[n][1]=ao[n].nGetDBLength();
	    for (int i=0;i<12;i++){
		aan[n][i+2]=an[i];
	    }
	}
	return aan;
    }




    public CanMsg[] aoListCanIds()
    {
	CanMsg aoCan[]=null;
	String s=null;
	//	System.out.println("CanId-----------:");
	pCom.putLine("GET_DATABASE_ID_LIST");
	int nMaxElements=0;
	int n=0;
	do {
	    s=pCom.getLine();
	    //System.out.println("aoListCanIds:"+s);
	    if(s==null)
		break;
	    if(s.length()>0){
		StringTokenizer oTok = new StringTokenizer(s);
		String sFirst=oTok.nextToken();
		if(sFirst.equals("DATABASE_ID_BEGIN")){
		    nMaxElements=0;
		    if(oTok.hasMoreTokens()){
			Hex2Dec oH2I = new Hex2Dec(oTok.nextToken());
			nMaxElements=(int)oH2I.lGetValue();
			System.out.println("RESULT"+s+", and got elements:"+nMaxElements);
		    }
		    if(nMaxElements>0){
			aoCan = new CanMsg[nMaxElements];
		    }
		}
		else if(!sFirst.equals("DATABASE_ID_END")&&(n<nMaxElements)&&(aoCan!=null)){
		    aoCan[n++] = new CanMsg(s);
		}
		else {
		    System.out.println("oiListCanIds|format error:"+s);
		    aoCan=null;
		    break;
		}
	    }
	} while(!s.equals("DATABASE_ID_END")&&(n<nMaxElements));
       
	while(!s.equals("DATABASE_ID_END")){
	    //System.out.println(s);
	    s=pCom.getLine();
      	}
	
	    //s=s.substring(s.indexOf(' ')+1);
	//int nIndex=Integer.valueOf(s).intValue();
	if(true){
	    if((aoCan!=null)){
		//System.out.println("Received ids:"+nMaxElements);
		for (int i=0;i<nMaxElements;i++){
		    System.out.println(i+"|"+aoCan[i].toText());
		}
		for (int i=0;i<nMaxElements;i++){
		    int an[]=aoCan[i].toIntArray();
		    for(int j=0;j<an.length;j++){
			System.out.print(an[j]+"\t");
		    }
		    System.out.println();
		}
	    }
	}
	return (n==nMaxElements) ? aoCan:null;
    }

    public int [] anGetDataBaseStatus()
    {
	int anStatus[]=new int[10];
	String s=null;
	pCom.putLine("GET_DATABASE_STATUS");
	int n=0;
	do {
	    s=pCom.getLine();
	    if(s.equals("FALSE")){
		break;
	    }
	    else if(!s.equals("DATABASE_STATUS_BEGIN")&&
	       !s.equals("DATABASE_STATUS_END")){
		StringTokenizer Tok = new StringTokenizer(s);
		//System.out.println(s+" "+n);
		anStatus[n++] +=n;
	    }
	} while(!s.equals("DATABASE_STATUS_END"));
	    //s=s.substring(s.indexOf(' ')+1);
	//int nIndex=Integer.valueOf(s).intValue();
	return anStatus;
    }

    public CanMsg oPoll()
    {
	return oPoll(0);
    }

    public CanMsg oPoll( int nIndex)
    {
	int an[]={nIndex};
	CanMsg ao[]=aoPoll(an);
	return ao[0];
    }

    public CanMsg[] aoPoll( int anIndex[])
    {
	CanMsg aoCan[] = null;
	if(anIndex!=null){
	    aoCan = new CanMsg[anIndex.length]; 
	    String s = "FIFO_POLL";
	    for (int n=0;n<anIndex.length;n++)
		s +=" "+anIndex[n];
	    pCom.putLine( s);
	    for (int n=0;n<anIndex.length;n++){
		aoCan[n] = new CanMsg(pCom.getLine());
	    }
	}
	return aoCan;
    }

    public CanMsg[] aoPoll( int nIndex, int nNumbers)
    {
	CanMsg aoCan[]=null;
	if(nNumbers>0){
	    String s=null;
	    //  System.out.println("oPollMany: message ");
	    pCom.putLine("FIFO_POLL_INTERVAL "+nIndex+" "+nNumbers);
	    if(nNumbers < 0) 
		nNumbers=-nNumbers;
	    s=pCom.getLine();
	    if(1>0){
		StringTokenizer st = new StringTokenizer(s);
		st.nextToken();
		nIndex = Integer.valueOf(st.nextToken()).intValue();
		nNumbers = Integer.valueOf(st.nextToken()).intValue();
	    }
	    aoCan= new CanMsg[nNumbers];
	    for (int n=0;n<nNumbers;n++){
		aoCan[n] = new CanMsg(pCom.getLine());
	    }
	}
	return aoCan;
    }


    public boolean bSend( int nId,byte abData[])
    {
	CanMsg oMsg = new CanMsg(nId,abData);
	return bSend( oMsg);
    }

    public boolean bSend( CanMsg oMsg)
    {
	boolean bReturn = false;
	if(bIsConnected()){
	    String s="SENDHEX " + oMsg.toServerString();
	    System.out.println(s);
	    pCom.putLine(s);
	    //System.out.println(s);
	    s=pCom.getLine();
	    //System.out.println("ANSWER:"+s);
	    bReturn =s.equals("TRUE");
	}
	return bReturn;
    }
 
    public void send( CanMsg oMsg)
    {
	if(bIsConnected()){
	    String s="SENDHEX_NOACK " + oMsg.toServerString();
	    pCom.putLine(s);
	}
	return;
    }

    public void sendDB(int nMilliDuration, int nMilliStep, CanMsg oMsg)
    {
	if(bIsConnected()){
	    String s="SENDHEXDB_NOACK "+nMilliDuration+" "+nMilliStep+" "+oMsg.toServerString();
	    pCom.putLine(s);
	}
    }
    
    public boolean bSendDB(int nMilliDuration, int nMilliStep, CanMsg oMsg)
    {
	String s="SENDHEXDB "+nMilliDuration+" "+nMilliStep+" "+oMsg.toServerString();
	pCom.putLine(s);
	//System.out.println(s);
	s=pCom.getLine();
	
	//System.out.println("bSendHexDB:"+s);
	return s.equals("TRUE");
    }



    public CanMsg oSendHexWaitId( CanMsg oCan, int nId)
    {
	return oSendWaitId( oCan, nId, 100);
    }
    
    public CanMsg oSendWaitId( CanMsg oCan, int nId, int nTimeOut)
    {
	if(oCan!=null){
	    Hex2Dec oId = new Hex2Dec( nId);
	    Hex2Dec oTimeOut = new Hex2Dec( nTimeOut);
	    String s="SENDHEX_WAIT_ID "+oId.sToHexStr(8)+" "+oTimeOut.sToHexStr(4) + " "+oCan.toServerString();
	    pCom.putLine(s);
	    s=pCom.getLine();
	    System.out.println("CanClient:Received "+s);
	    if(!s.equals("FALSE")){
		System.out.println(s);
	    oCan = new CanMsg(s);
	    }
	    else {
		oCan = null;
	    }
	}
	return oCan;
    }

  
}
