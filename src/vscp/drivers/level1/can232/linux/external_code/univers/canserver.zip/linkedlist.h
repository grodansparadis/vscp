#ifndef __LINKEDLIST_H
#define __LINKEDLIST_H
#include <sys/time.h>
#include <semaphore.h>

class Clinkedlist_node
{
 public:
  struct timeval sTime;
  int nSize;
  char *pMsg;
  Clinkedlist_node *pNext;
  Clinkedlist_node *pPrev;  
  
  ~Clinkedlist_node();
  Clinkedlist_node( void *pMsg,int nSize, Clinkedlist_node *pNext, Clinkedlist_node *pPrev);
  void *pFinalize( void *pMsg);
};


class Clinkedlist
{
  sem_t sLock;
  int nDefaultSize;
  int nMaxLength;
  int nLength;
  Clinkedlist_node *pHead, *pTail;
  Clinkedlist_node *pStepPtr;

  void init(int nDefaultSize=0,int nMaxLength=0);

 public:
  Clinkedlist(int nMaxLength=0,int nDefaultSize=0);
  Clinkedlist(void *pMsg,int nMaxLength=0,int nDefaultSize=0);
  ~Clinkedlist();
  int nInsertHead(void *poMsg, int nSize=0);
  int nInsertTail(void *poMsg, int nSize=0);
  void *pGetNode( int n=0);
  void *pPtrHead( void);
  void *pPtrTail(void);

  void *pGetPtrAndStepNext(void);
  void *pGetPtrAndStepPrev(void);
  void *pStepPtrGotoHead(void);
  void *pStepPtrGotoTail(void);
  void *pGetAtStepPtr(void);
  void *pPopAtStepPtr( void *pMsg=0);
  void *pStepPtrNext(void);
  void *pStepPtrPrev(void);
  int nInsertAtStepPtr( void *pMsg,int nSize=0);

  void *pPopTail( void *pMsg=0);
  void *pPopHead( void *pMsg=0);
  
  int nDeleteTail(bool bDeleteElement=1);
  int nDeleteHead(bool bDeleteElement=1);
  int nDeleteAtStepPtr(bool bDeleteElement=1);
  int nGetLength( void);
};



#endif
