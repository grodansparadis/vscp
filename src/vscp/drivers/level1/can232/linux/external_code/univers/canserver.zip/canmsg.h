#ifndef __CANMSG_H
#define __CANMSG_H

#define CAN_DRIVEID 0x21010B


#define CAN_MSG_LENGTH 8
#include <sys/time.h>
#include <unistd.h>
#include "Cinteger.h"
#include "can4linux.h"
#include "tokenizer.h"
/*
typedef struct {
 
  int             flags;
  int             cob;	
  unsigned   long id;	
  //double rSystemTime;
  struct timeval  timestamp;	 
  
  short      int  length;	
  unsigned   char data[CAN_MSG_LENGTH]; 
} canmsg_t;
*/


class Ccanmsg
{
  bool bDebug;
  Cinteger oInt;
  char *pTxt;
  int nIndex;
  canmsg_t sMsg;
  bool bSet;

  void init(int nId, int nLen, unsigned char auc[],int nIndex);
  void init(canmsg_t *pMsg,int nIndex);

public:
  //  Ccanmsg(Ccanmsg o);
  Ccanmsg();
  Ccanmsg( Ccanmsg *poMsg);
  Ccanmsg( Ccanmsg & oMsg);
  Ccanmsg(int nId, int nLen, unsigned char auc[],int nIndex=0);
  Ccanmsg(canmsg_t *pMsg,int nIndex=0);
  Ccanmsg( Ctokenizer * poTok, int nTokenOffset=0);
  Ccanmsg(char *p);
  ~Ccanmsg();
  void SetIndex( int n=0);
  char *pToClientText(char *p=0);
  char *pToText(char *p=0);
  int nGetId( void);
  int nGetIndex( void);
  int nData(int nIndex);
  long lDiffMilliSeconds( Ccanmsg *poCanMsg);
  long lGetSeconds( void);
  long lGetMicroSeconds( void);
  double rGetTimeStamp( void);
  bool bIsSet( void); 
  Ccanmsg *poClone( void);
  Ccanmsg oClone( void);
  void CopyTo( canmsg_t *p);
  canmsg_t *pGetMsgPtr( void);
};

//typedef class Ccanmsg Ccanmsg_t;

#endif
