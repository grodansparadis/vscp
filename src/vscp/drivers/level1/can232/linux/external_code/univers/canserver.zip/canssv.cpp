#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "canssv.h"
#include <unistd.h>
#include <sys/ioctl.h>


Ccanssv::Ccanssv( char *pDeviceName, int nCanRate)
{
  fd=-1;
  bool bOk=bInit( pDeviceName, nCanRate);
  if(bOk)
    printf("Device %s opened : %s\n",pDeviceName,bOk ? "TRUE":"FALSE");
}

Ccanssv::Ccanssv( int nDeviceNumber, int nCanRate)
{
  char acDeviceName[30];
  sprintf( acDeviceName,"/dev/can%d",nDeviceNumber);
  fd=-1;
  bool bOk=bInit( acDeviceName, nCanRate);
  if(bOk)
    printf("Device %s opened : %s\n",acDeviceName,bOk ? "TRUE":"FALSE");
}

bool Ccanssv::bOpen( void)
{
  //  Command_par sCmd={CMD_START,0,0};
  //ioctl(fd,COMMAND,&sCmd);
  return true;
}

bool Ccanssv::bClose(void)
{
  //Command_par sCmd={CMD_STOP,0,0};
  //ioctl(fd,COMMAND,&sCmd);
  return true;
}

bool Ccanssv::bInit( char *pDeviceName, int nCanRate)
{
  sem_init(&sLock,0,1);
  sem_wait(&sLock);
  fd = open(pDeviceName,O_RDWR);
  printf("Opened canbus device %s, with return value %d==%s\n",pDeviceName, fd, (fd>=0) ? "OK":"FALSE");
  sem_post(&sLock);
  return fd>=0;
}

bool Ccanssv::bGetIfInitOk(void)
{
  return (fd>=0);
}


bool Ccanssv::bSetCode(int nCode)
{
  //Config_par_t sConfig={CONF_ACCC,nCode,0,0,0};
  //ioctl(fd,CONFIG,&sConfig);
  return false;
}

bool Ccanssv::bSetMask(int nMask)
{
  //Config_par_t sConfig={CONF_ACCM,nMask,0,0,0};
  //ioctl(fd,CONFIG,&sConfig);
  return false;
}

canmsg_t *Ccanssv::pPollMsg(canmsg_t *paMsgs)
{
  int nToPoll = 1;
  return pPollMsgs(&nToPoll,paMsgs ? paMsgs:&sPollCanMsg);
  
}

canmsg_t *Ccanssv::pPollMsgs(int *pnMsgs, canmsg_t *paMsgs)
{
  canmsg_ssv_t sReadMsg;
  int nMsgToPoll = pnMsgs ? *pnMsgs:1;
  int nPolled=0;
  if(!paMsgs){
    paMsgs= &sPollAllCanMsg[0];
  }
  for (int n=0;n<nMsgToPoll;n++){
    sReadMsg.flags=0;
    sReadMsg.cob=0;
    sReadMsg.timestamp=0;
    int nRet =read(fd,&sReadMsg,sizeof(struct canmsg_ssv_t));
    if(nRet>0){
      canmsg_t *p = &paMsgs[n];
      nPolled++;
      gettimeofday(&p->timestamp,0);
      p->id = sReadMsg.id;
      p->cob = sReadMsg.cob;
      p->flags = sReadMsg.flags;
      p->length = sReadMsg.length;
      p->data[0] = sReadMsg.data[0];
      p->data[1] = sReadMsg.data[1];
      p->data[2] = sReadMsg.data[2];
      p->data[3] = sReadMsg.data[3];
      p->data[4] = sReadMsg.data[4];
      p->data[5] = sReadMsg.data[5];
      p->data[6] = sReadMsg.data[6];
      p->data[7] = sReadMsg.data[7]; 
    }
    else {
      printf("Ccanssv::read timeout!!!\n");
      break;
    }
  }
  if( pnMsgs)
    *pnMsgs = nPolled;
  return  nPolled ? paMsgs:0;
}


bool Ccanssv::bSetCodeMask(int nCode, int nMask)
{
  //Config_par_t sConfig={CONF_ACC,nCode,nMask,0,0};
  //ioctl(fd,CONFIG,&sConfig);
  return true;
}


bool Ccanssv::bSend(int nId, int nLen, unsigned char *puacData)
{
  int nWrote =0;
  canmsg_ssv_t sCanMsg;
  sem_wait(&sLock);
  sCanMsg.flags = SSV_MSG_EXT;
  sCanMsg.cob = 0;
  sCanMsg.timestamp = 0;
  sCanMsg.length = puacData ? nLen:0;
  sCanMsg.id = nId;
  if(puacData){
    for (int n=0;n<nLen;n++)
      sCanMsg.data[n]=puacData[n];
  }
  printf("Ccanssv::bSend 1\n");
  nWrote=write(fd,&sCanMsg,sizeof(struct canmsg_ssv_t));
  sem_post(&sLock);
  return nWrote > 0;
}

bool Ccanssv::bSendCanMsg(canmsg_t *psCanMsg)
{
  //Send_par_t sSend ={psCanMsg,0,0};
  //ioctl(fd,SEND,&sSend);
  int nWrote=0;
  if(psCanMsg){
    sem_wait(&sLock);
    canmsg_ssv_t sSSVMsg = {SSV_MSG_EXT,0,psCanMsg->id,0,psCanMsg->length,
			 {psCanMsg->data[0],
			  psCanMsg->data[1],
			  psCanMsg->data[2],
			  psCanMsg->data[3],
			  psCanMsg->data[4],
			  psCanMsg->data[5],
			  psCanMsg->data[6],
			  psCanMsg->data[7]}};
    printf("Ccanssv::bSendCanMsg 1\n");
    nWrote=write(fd,&sSSVMsg,sizeof(struct canmsg_ssv_t));
    sem_post(&sLock);
  }
  return nWrote>0;
}


char * Ccanssv::pStatusText( int nStatusMasks)
{
  char *pText = "STATUS";
  return pText;
} 

int Ccanssv::nStatusFlag( int nFlag)
{
  //CanSja1000Status_par_t sStatus;
  //ioctl(fd,STATUS,&sStatus);
  return 1;
}

Ccanssv::~Ccanssv()
{
  sem_wait(&sLock);
  if(fd>=0)
    close(fd);
  sem_post(&sLock);
  sem_destroy(&sLock);
}
