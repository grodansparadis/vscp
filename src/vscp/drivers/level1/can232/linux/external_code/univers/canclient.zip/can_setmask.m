function b=can_setmask(can,mask)
     nMask=int64(mask);
     b=can.bSetMask(nMask);
