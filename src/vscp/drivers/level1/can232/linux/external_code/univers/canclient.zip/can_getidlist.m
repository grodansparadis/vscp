function [m,t] = can_getid(can, id,maxlength,startpos)
     r=double(can.aanGetIdList(int32(id),int32(maxlength),int32(startpos)));
     m=[];
     t=[];
     if size(r,1)>0 
       m=r(:,[3:12]);
       t=(r(:,[1]))+(r(:,[2]))/1000000.0;
     end

