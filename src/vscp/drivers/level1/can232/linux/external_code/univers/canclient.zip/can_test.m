format long;
can=can_init('rullstol.sm.luth.se',9009);
fifo_index=can_fifoindex(can)
[idlist,len,t,msgs]=can_listcanids(can);
[idlist,len,msgs]
    

fwd_msg=[135198,32,0,3,0,0,0,7,255];
bwd_msg=[135198,32,0,3,0,0,0,128,24];
for n=1:100
can_send(can,fwd_msg);
end
can_getid(can,144)
can_getid(can,145)
     [a_msgs,a_t]=can_getidlist(can,144,10,1);
     [a_t,a_msgs]
[b_msgs,b_t]=can_getidlist(can,145,3,1);


ao1=can.aoPoll(-100,200)
o=can.oPoll(-100)
ao2=can.aoPoll([800 123 34])

%can_disconnect(can);
dec2hex(idlist)
