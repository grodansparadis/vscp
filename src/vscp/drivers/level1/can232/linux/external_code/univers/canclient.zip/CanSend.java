import java.lang.*;
import java.util.*;

public class CanSend
{


    public static void main(String asArgs[])
    {
	if (asArgs.length<2){
	    System.out.println("Usage: java CanSend <hostname> id <d0 .. d7>");
	}
	else {		
	    int nId=(int)(new Hex2Dec( asArgs[1])).lGetValue();
	    byte ab[]=new byte[asArgs.length-2];
	    for (int n=0;n<asArgs.length-2;n++){
		ab[n]=(byte)(new Hex2Dec( asArgs[2+n])).lGetValue();
	    }
	    CanMsg oCanMsg = new CanMsg((int)nId, ab);
	    CanClient oCanClient = new CanClient( asArgs[0],9009);
	    if(oCanClient.bIsConnected()){
		if(oCanClient.bSend(oCanMsg)){
		    System.out.println("CAN message sent successfully to server "+asArgs[0]);
		}
		else {
		    System.out.println("Sent failed!!!!\n");
		}	    
		oCanClient.disconnect();
	    }
	    else{
		System.out.println("Unable to connect to server "+asArgs[0]);
	    }
	}

	return;
    }
}
