function [m,t] = can_getid(can, id)
     r=double(can.anGetById(int32(id)));
     m=[];
     t=[];
     if(size(r,1)>0)
       m=r([3:12]);
       t=(r(1))+(r(2))/1000000.0; 
     end
