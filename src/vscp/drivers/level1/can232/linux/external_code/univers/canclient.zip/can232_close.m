function v=can232_close(s)
     version=java.lang.String('C');
     %s.putLine(version);
     %line=s.readLine
     v=10
