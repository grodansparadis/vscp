#ifndef __CANDEV_H
#define __CANDEV_H




#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sched.h>
#include <pthread.h> 
#include <semaphore.h>
#include "canmsg.h"
#include "canmsgdb.h"
#include "can232.h"
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "canssv.h"
#include "linkedlist.h"
#include "semaphore.h"
#include "time.h"

#define MAX_WAITID 11



class Ccanwait_node
{
  Csemaphore *poSemClient;
  bool bDebug;
  bool bInUse;
  int nId;
  int nIndex;
  int nStartIndex;
  int nMilliSecToTimeOut;
  long lMilliSec;

  int nCode;
  int nMask;
  short nMode;

  Ctime oTime;

 public:
  Ccanwait_node(int nId, int nStartIndex=0, int nMilliSecToTimeOut=0, bool bDebug=false);
  ~Ccanwait_node();
  bool bWait( bool bByTime=false);
  bool bRelease( bool b=true);
  bool bActive( void);
  bool bCheck( int nId, int nIndex);
  int nGetId( void);
  int nGetIndex(void);
  int nIncIndex( void);
  bool bTimeOut( void);
  //int nTimeLeft( void);
};


class Ccanwait
{
  int nWaitIndex;
  Csemaphore *poWaitFunLock;
  Csemaphore *poWaitLock;
  Csemaphore *poLock;

  Ccanmsgdb *pDB;

  //Ctime oTime;

  Clinkedlist *pIdList;
  Clinkedlist *pIndexList;

  bool bDebug;
  bool bVerbose;

 public:
  Ccanwait(Ccanmsgdb *pDB, bool bDebug=false);
  ~Ccanwait();
  int nReleaseIdLock( int nIndex);
  int nReleaseIndexLock(int nIndex);
  int nWaitCanIndex( int nIndex);
  int nWaitCanId(int nId, int nStartIndex, int nMilliSecTimeOut);
};



class Ccandev
{
  bool bDebug;
  bool bVerbose;
  long lLoop;

  Ccanmsgdb *pDB;
  Ccantxdb *pTxDB;

  //sem_t sLock;
  unsigned int unErrors;

  //Ccanssv *poCan;
  Ccan232 *poCan;
  Ccanwait *pWait;

 public:
 Ccandev(int nDevice, int nCanRate=250000, bool bDebug=false);
 Ccandev();
 ~Ccandev();
 char *pGetStatusText( char *p=0);
  

  int nProceed();
  int nInit( int nDevice=-1, int nCanRate=250000);
  
  
  Ccanmsgdb *pGetMsgDB(void);
  int nGetMaxMsgIndex(  int *punErrors=0);
  int nGetCanMsg( canmsg_t  *pCanMsg,int nIndex=0);
  Ccanmsg oGetCanMsg( int nIndex=0);
  Ccanmsg *poGetCanMsg( int nIndex=0);
  int nInsertRxMsg( canmsg_t *pMsg);
  int nReleaseIdLock( int nIndex);
  int nSearchId( int nId, int nLowerIndex=0);
  int nWaitCanIndex( int nIndex);
  int nReleaseWaitIndexLock( int nIndex=0);
  int nReleaseWaitLocks( void);
  int nWaitCanId(int nId, int nStartIndex=0, int nMilliSecToTimeOut=0);
  int nWaitCanCodeMask(int nCode, int nMask=-1);
  bool bWorking( void);


  bool bSetCodeMask( int nCode, int nMask);
  bool bSend(int nId, int nLen=0, unsigned char *p=0);
  bool bSend( char *pStr);
  bool bSend(canmsg_t *pMsg);
  bool bSend( Ccanmsg *poMsg);
  int nSend( canmsg_t *pMsg,int nId);
  Ccanmsg oSendCanMsgWaitId( canmsg_t *pMsg,int nId);
  char * pCanMsgToStr(char *pStr,canmsg_t *pMsg);
  char * pCanMsgToHexStr( char *pStr,canmsg_t *pMsg);
  bool bOpen( void);
  bool bClose( void);
  Ccanmsgdb *pGetDBPtr( void);

  //int nCanMsgTxDBInsert();
  int nCanMsgTxDBInsert(canmsg_t *pMsg,long lMilliSecDuration, long lMilliSecStep);
  int nMsgsInTxDBSend( int nLoop=3);
};

extern Ccandev * CAN_pGetDevicePtr(int nDevice);

#endif

