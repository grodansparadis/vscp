function c=can(host,port);
c=can_init(host,port);
v=can_version(c); 
can232_close(c);
