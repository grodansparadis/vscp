#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sched.h>
#include <pthread.h> 
#include <semaphore.h>
#include <string.h>
#include "canmsg.h"
#include "canmsgdb.h"


#include "master.h"
#include "candev.h"

const int nCan232Ports[]={SERIALPORT_CAN232_1,
			  SERIALPORT_CAN232_2,
			  SERIALPORT_CAN232_3,
			  SERIALPORT_CAN232_4};

struct YOUR_DATA_STR 
{
  sem_t sCanCreated;
  int nSerialPort;
  int nCanBusSpeed;
  Ccandev *poCan;
};

struct YOUR_DATA_STR sCanDataStr[4];



Ccandev *CAN_pGetDevicePtr( int n)
{
  Ccandev *p;
  for(int n=0;!(p=sCanDataStr[n&0x0].poCan) && (n<10);n++){
    usleep(10000);
  }
  return p;
}

int CAN_nInitCodeBeforeRealTime( struct EMPTY_TASK_STR *pTask, void *pYourDataStr)
{
  struct YOUR_DATA_STR *pStr;
  pStr = (struct YOUR_DATA_STR *) pYourDataStr;
  sem_init(&pStr->sCanCreated,0,1);
  strcpy(pTask->acName,"CANTSK");
  if (!strlen(pTask->acMyIpcName)){
    strcpy(pTask->acMyIpcName, pTask->acName);
  }
  pTask->nMode = TASK_FREE_RUNNING_MODE;
  pStr->nSerialPort = nCan232Ports[pTask->nTwinThreadNr&0x03];
  pStr->nSerialPort = pTask->pExtraArg[0] ? atoi(pTask->pExtraArg[0]):pStr->nSerialPort;
  pStr->nCanBusSpeed =  pTask->pExtraArg[1] ? atoi(pTask->pExtraArg[1]):250000;
  if(2>1){
    pTask->nDebug = 0;
    pTask->nVerbose = 0>0;
  }
  printf("CANTSK:Opening candevice on /dev/ttyS%d  CANBUSRATE=%d\n",pStr->nSerialPort, pStr->nCanBusSpeed);
  pStr->poCan = new Ccandev(pStr->nSerialPort, pStr->nCanBusSpeed,pTask->nDebug!=0);
  return pStr->poCan->bWorking();
}
 
int CAN_nInitCodeInRealTime( struct EMPTY_TASK_STR *pTask, void *pYourDataStr)
{
  int nRet=0;
  struct YOUR_DATA_STR *pStr;
  pStr = (struct YOUR_DATA_STR *) pYourDataStr;
  if( pTask->nVerbose){
    printf("CANTSK%d:Open Candevice on %s%d, CanBusSpeed=%d\n",pTask->nTwinThreadNr,pStr->nSerialPort<8 ? "/dev/ttyS":"/dev/can",pStr->nSerialPort, pStr->nCanBusSpeed);
  }
  for (int n=0;n<1;n++){
    nRet=pStr->poCan->bOpen();
    if(nRet)
      break;
    else {
      printf("CANTSK%d:Failed to open Candevice, try %d\n",pTask->nTwinThreadNr,n);
    }
  }
  if( pTask->nVerbose)
    printf("CANTSK:Initrealtime\n");
  return nRet;
}


int CAN_nProceed( struct EMPTY_TASK_STR *pTask, void *pYourDataStr)
{
  int nRet=0;
  struct YOUR_DATA_STR *pStr;
  pStr=(struct YOUR_DATA_STR *) pYourDataStr;
  nRet=pStr->poCan->nProceed();
  /*
  if((pStr->poCan->nGetMaxMsgIndex()%200)==0){
    
  }
  */
  return nRet;
}


int CAN_nCleanUpCodeInRealTime( struct EMPTY_TASK_STR *pTask, void *pYourDataStr)
{
  struct YOUR_DATA_STR *pStr;
  pStr =(struct YOUR_DATA_STR *) pYourDataStr;
  return 1;
}

 
int CAN_nCleanUpCodeAfterRealTime( struct EMPTY_TASK_STR *pTask, void *pYourDataStr)
{
  struct YOUR_DATA_STR *pStr;
  pStr =(struct YOUR_DATA_STR *) pYourDataStr;
  if ( pStr->poCan)
    delete pStr->poCan;
  return 1;
}


void can_task(void  *p) 
{
  struct EMPTY_TASK_STR  *pTask;
  short nStatus=1;
  pTask = (struct EMPTY_TASK_STR *) p;
  pTask->pYourPtr = &sCanDataStr[pTask->nTwinThreadNr];
  if(0>1){
    printf("CANTASK:Entering thread, Twinthreadnr=%d pTask=%.8X pYourPtr=%.8X\n",pTask->nTwinThreadNr,(unsigned)pTask,(unsigned)pTask->pYourPtr);
  }
  nStatus =CAN_nInitCodeBeforeRealTime(pTask,pTask->pYourPtr)!=0;
  nStatus &=CAN_nInitCodeInRealTime(pTask,pTask->pYourPtr)!=0;
  while (nStatus){
    nStatus &=CAN_nProceed(pTask,pTask->pYourPtr)!=0;
    nStatus &=task_proceed(pTask)!=0;
  };
  nStatus &=CAN_nCleanUpCodeInRealTime(pTask,pTask->pYourPtr)!=0;
  nStatus &=CAN_nCleanUpCodeAfterRealTime(pTask,pTask->pYourPtr)!=0;
 
  return;
}




